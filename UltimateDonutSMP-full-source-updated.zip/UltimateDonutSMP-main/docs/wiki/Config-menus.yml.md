# Detailed Configuration & Setup Guide: `menus.yml`

This is the official, 100% complete technical setup guide for `menus.yml` in **UltimateDonutSMP**.
Each section details the exact commented setup code block, allowed option values, data types, default values, and in-depth functional behavior.

---

## Text Formatting

Every title, button name and lore line on this page runs through the same formatter, so you can
write them with `&` codes, hex colours, or MiniMessage tags:

```yaml
RANKS-MENU:
  TITLE: '<gradient:#FF7A00:#FFD400>Ranks</gradient>'
  BUTTONS:
    DONUT_PLUS:
      DISPLAY-NAME: '<white>Donut<#00A4FC>+'
      LORE:
      - '<gray>9 Homes'
      - '<bold><rainbow>Best value</rainbow>'
```

Named colours (`<red>`, `<gray>`, `<dark_purple>` and the rest of the sixteen), decorations
(`<bold>`, `<italic>`, `<underlined>`, `<strikethrough>`, `<obfuscated>`), `<reset>`,
`<gradient:...>` with two or more stops, and `<rainbow>` are all understood. Closing tags such as
`</bold>` put the surrounding style back rather than wiping it. Tags that carry click or hover
behaviour are ignored, because an item name sitting in a chest menu has nowhere to put them.

Anything the formatter doesn't recognise stays on screen exactly as you typed it. That is why
`<player>` and `<amount>` in the message files still come through as placeholders instead of
vanishing.

One more thing it does, less obviously: a title, button name or lore line whose visible letters
are all uppercase comes back in Title Case, so `'&cDONUT SMP'` reads `Donut Smp`. Mixed case is
left alone. [FAQ entry 16](FAQ) covers when the rule applies and the unicode small caps trick
that keeps a line shouting.

---

## Section: `GLOBAL`

### 1. Commented Setup Code Example

```yaml
GLOBAL:
  PAGE-MENU:
    MATERIAL: ARROW
    NEXT-BUTTON: '&aNEXT'
    BACK-BUTTON: '&aBACK'
    FIRST-PAGE-BUTTON: '&aFIRST PAGE'
    LAST-PAGE-BUTTON: '&aLAST PAGE'
    NEXT-LORE:
    - '&fClick to go to the next page'
    BACK-LORE:
    - '&fClick to go to the previous page'
    FIRST-PAGE-LORE:
    - '&fJump to the first page'
    LAST-PAGE-LORE:
    - '&fJump to the last page'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `GLOBAL.PAGE-MENU.MATERIAL` | `str` | Any string text | `'ARROW'` | Configures the technical `MATERIAL` parameter for `GLOBAL.PAGE-MENU.MATERIAL` in `menus.yml`. |
| `GLOBAL.PAGE-MENU.NEXT-BUTTON` | `str` | Any string text | `'&aNEXT'` | Configures the technical `NEXT-BUTTON` parameter for `GLOBAL.PAGE-MENU.NEXT-BUTTON` in `menus.yml`. |
| `GLOBAL.PAGE-MENU.BACK-BUTTON` | `str` | Any string text | `'&aBACK'` | Configures the technical `BACK-BUTTON` parameter for `GLOBAL.PAGE-MENU.BACK-BUTTON` in `menus.yml`. |
| `GLOBAL.PAGE-MENU.FIRST-PAGE-BUTTON` | `str` | Any string text | `'&aFIRST PAGE'` | Configures the technical `FIRST-PAGE-BUTTON` parameter for `GLOBAL.PAGE-MENU.FIRST-PAGE-BUTTON` in `menus.yml`. |
| `GLOBAL.PAGE-MENU.LAST-PAGE-BUTTON` | `str` | Any string text | `'&aLAST PAGE'` | Configures the technical `LAST-PAGE-BUTTON` parameter for `GLOBAL.PAGE-MENU.LAST-PAGE-BUTTON` in `menus.yml`. |
| `GLOBAL.PAGE-MENU.NEXT-LORE` | `list` | List of configured items/strings | `['&fClick to go to the next page']` | Configures the technical `NEXT-LORE` parameter for `GLOBAL.PAGE-MENU.NEXT-LORE` in `menus.yml`. |
| `GLOBAL.PAGE-MENU.BACK-LORE` | `list` | List of configured items/strings | `['&fClick to go to the previous page']` | Configures the technical `BACK-LORE` parameter for `GLOBAL.PAGE-MENU.BACK-LORE` in `menus.yml`. |
| `GLOBAL.PAGE-MENU.FIRST-PAGE-LORE` | `list` | List of configured items/strings | `['&fJump to the first page']` | Configures the technical `FIRST-PAGE-LORE` parameter for `GLOBAL.PAGE-MENU.FIRST-PAGE-LORE` in `menus.yml`. |
| `GLOBAL.PAGE-MENU.LAST-PAGE-LORE` | `list` | List of configured items/strings | `['&fJump to the last page']` | Configures the technical `LAST-PAGE-LORE` parameter for `GLOBAL.PAGE-MENU.LAST-PAGE-LORE` in `menus.yml`. |

### 3. Practical Setup Example

```yaml
GLOBAL:
  PAGE-MENU:
    MATERIAL: ARROW
    NEXT-BUTTON: '&aNEXT'
    BACK-BUTTON: '&aBACK'
    FIRST-PAGE-BUTTON: '&aFIRST PAGE'
    LAST-PAGE-BUTTON: '&aLAST PAGE'
    NEXT-LORE:
    - '&fClick to go to the next page'
    BACK-LORE:
    - '&fClick to go to the previous page'
    FIRST-PAGE-LORE:
    - '&fJump to the first page'
    LAST-PAGE-LORE:
    - '&fJump to the last page'
```

---

## Section: `TEAM-MENUS`

### 1. Commented Setup Code Example

```yaml
TEAM-MENUS:
  TEAM:
    TITLE: '&8Team'
    SIZE: 54
    MAX-ITEMS-PER-PAGE: 45
    PLAYER-BUTTON:
      ONLINE-SYMBOL: "&a■"
      OFFLINE-SYMBOL: "&4■"
      LORE: '&fClick to edit'
    SEARCH-BUTTON:
      TITLE: '&#6BF18DSearch'
      MATERIAL: OAK_SIGN
      SLOT: 45
      LORE:
      - '&fSearch for team members'
    SEARCH_SIGN:
      lines:
      - ''
      - ↑↑↑↑↑↑↑↑↑↑↑↑↑
      - Search
      - ''
      input-line: 0
    SORT-BUTTON:
      TITLE: '&aSort'
      MATERIAL: HOPPER
      SLOT: 46
      SELECTED-PREFIX: '&a'
      UNSELECTED-PREFIX: '&f'
      SYMBOL: "▪"
    REFRESH-BUTTON:
      TITLE: '&#6BF18DTeam {team_name}'
      MATERIAL: IRON_HELMET
      SLOT: 49
      LORE:
      - '&fClick to refresh'
      - '&7Add up to {max_members} members'
    HOME-BUTTON:
      TITLE: '&#6BF18DTeam Home'
      MATERIAL: WHITE_BANNER
      SLOT: 52
      HOME-LORE: '&fClick to teleport to your team''s home'
      NO-HOME-LORE: '&fSet the team home with /home'
    PVP-BUTTON:
      TITLE: '&#6BF18DPVP'
      MATERIAL: IRON_SWORD
      SLOT: 53
      ON-STATE: '&a&lON'
      OFF-STATE: '&c&lOFF'
      LORE: '&fCurrently: {state}'
    MESSAGES:
      NOT-IN-TEAM: '&cYou are not part of the team.'
      NO-PERMISSION: '&cYou don''t have permissions to do this.'
      CANT-EDIT-SELF: '&cYou can''t do this yourself!'
  TEAM-INFO:
    TITLE: '&8Team {team_name}'
    SIZE: 54
    MAX-ITEMS-PER-PAGE: 45
    PLAYER-BUTTON:
      ONLINE-SYMBOL: "&a■"
      OFFLINE-SYMBOL: "&4■"
      LEADER-LORE: '&6Leader'
    SUMMARY-BUTTON:
      TITLE: '&#6BF18DTeam {team_name}'
      MATERIAL: IRON_HELMET
      SLOT: 49
      ON-STATE: '&a&lON'
      OFF-STATE: '&c&lOFF'
      LORE:
      - '&7Leader: &f{leader}'
      - '&7Members: &f{members}&7/&f{max_members}'
      - '&7PvP: {state}'
    PAGE-BUTTON:
      TITLE: '&fPage {page}&7/&f{total_pages}'
      MATERIAL: PAPER
      SLOT: 50
      LORE:
      - '&7Browse team members.'
  TEAM-EDIT-MEMBER:
    TITLE: '&8Edit {player}'
    SIZE: 27
    PLACEHOLDER: false
    PLACEHOLDER-MATERIAL: BLACK_STAINED_GLASS_PANE
    EDIT-HOME-BUTTON:
      TITLE: '&#6BF18DEdit Home'
      MATERIAL: WHITE_BANNER
      SLOT: 10
      ON-STATE: '&a&lON'
      OFF-STATE: '&c&lOFF'
      LORE:
      - '&fLet {player} set and remove the team home'
      - '&fCurrently: {state}'
    KICK-BUTTON:
      TITLE: '&#6BF18DKick'
      MATERIAL: OAK_DOOR
      SLOT: 11
      LORE:
      - '&fClick to kick {player}'
    MANAGE-TEAMMATES-BUTTON:
      TITLE: '&#6BF18DManage Teammates'
      MATERIAL: IRON_HELMET
      SLOT: 12
      ON-STATE: '&a&lON'
      OFF-STATE: '&c&lOFF'
      LORE:
      - '&fLet {player} invite and kick teammates'
      - '&fCurrently: {state}'
    PVP-BUTTON:
      TITLE: '&#6BF18DPVP'
      MATERIAL: IRON_SWORD
      SLOT: 13
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `TEAM-MENUS.TEAM.TITLE` | `str` | Any string text | `'&8Team'` | Configures the technical `TITLE` parameter for `TEAM-MENUS.TEAM.TITLE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.SIZE` | `int` | Any valid integer number | `'54'` | Configures the technical `SIZE` parameter for `TEAM-MENUS.TEAM.SIZE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.MAX-ITEMS-PER-PAGE` | `int` | Any valid integer number | `'45'` | Configures the technical `MAX-ITEMS-PER-PAGE` parameter for `TEAM-MENUS.TEAM.MAX-ITEMS-PER-PAGE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.PLAYER-BUTTON.ONLINE-SYMBOL` | `str` | Any string text | `'&a■'` | Configures the technical `ONLINE-SYMBOL` parameter for `TEAM-MENUS.TEAM.PLAYER-BUTTON.ONLINE-SYMBOL` in `menus.yml`. |
| `TEAM-MENUS.TEAM.PLAYER-BUTTON.OFFLINE-SYMBOL` | `str` | Any string text | `'&4■'` | Configures the technical `OFFLINE-SYMBOL` parameter for `TEAM-MENUS.TEAM.PLAYER-BUTTON.OFFLINE-SYMBOL` in `menus.yml`. |
| `TEAM-MENUS.TEAM.PLAYER-BUTTON.LORE` | `str` | Any string text | `'&fClick to edit'` | Configures the technical `LORE` parameter for `TEAM-MENUS.TEAM.PLAYER-BUTTON.LORE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.SEARCH-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DSearch'` | Configures the technical `TITLE` parameter for `TEAM-MENUS.TEAM.SEARCH-BUTTON.TITLE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.SEARCH-BUTTON.MATERIAL` | `str` | Any string text | `'OAK_SIGN'` | Configures the technical `MATERIAL` parameter for `TEAM-MENUS.TEAM.SEARCH-BUTTON.MATERIAL` in `menus.yml`. |
| `TEAM-MENUS.TEAM.SEARCH-BUTTON.SLOT` | `int` | Any valid integer number | `'45'` | Configures the technical `SLOT` parameter for `TEAM-MENUS.TEAM.SEARCH-BUTTON.SLOT` in `menus.yml`. |
| `TEAM-MENUS.TEAM.SEARCH-BUTTON.LORE` | `list` | List of configured items/strings | `['&fSearch for team members']` | Extra lore on the search sign. The plugin appends the current filter and the left-click / right-click hints on top of this. |
| `TEAM-MENUS.TEAM.SEARCH_SIGN.lines` | `list` | Up to four lines of text | `['', '↑↑↑↑↑↑↑↑↑↑↑↑↑', 'Search', '']` | The four lines the sign shows when someone left-clicks search. A shorter list is padded with blanks and anything past the fourth line is dropped. Colour codes are translated and then stripped, so `&c` and friends change nothing on these signs. Leave all four blank and the plugin falls back to `^^^^^^^^^^^^^^` on the second line and `Enter Value` on the third. |
| `TEAM-MENUS.TEAM.SEARCH_SIGN.input-line` | `int` | `0` to `3` | `0` | Which line the typed name is read back from, counting from zero. Anything outside that range is clamped into it. At the default of `0` the player types on the top line and the arrows underneath point up at it. |
| `TEAM-MENUS.TEAM.SORT-BUTTON.TITLE` | `str` | Any string text | `'&aSort'` | Configures the technical `TITLE` parameter for `TEAM-MENUS.TEAM.SORT-BUTTON.TITLE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.SORT-BUTTON.MATERIAL` | `str` | Any string text | `'HOPPER'` | Configures the technical `MATERIAL` parameter for `TEAM-MENUS.TEAM.SORT-BUTTON.MATERIAL` in `menus.yml`. |
| `TEAM-MENUS.TEAM.SORT-BUTTON.SLOT` | `int` | Any valid integer number | `'46'` | Configures the technical `SLOT` parameter for `TEAM-MENUS.TEAM.SORT-BUTTON.SLOT` in `menus.yml`. |
| `TEAM-MENUS.TEAM.SORT-BUTTON.SELECTED-PREFIX` | `str` | Any string text | `'&a'` | Configures the technical `SELECTED-PREFIX` parameter for `TEAM-MENUS.TEAM.SORT-BUTTON.SELECTED-PREFIX` in `menus.yml`. |
| `TEAM-MENUS.TEAM.SORT-BUTTON.UNSELECTED-PREFIX` | `str` | Any string text | `'&f'` | Configures the technical `UNSELECTED-PREFIX` parameter for `TEAM-MENUS.TEAM.SORT-BUTTON.UNSELECTED-PREFIX` in `menus.yml`. |
| `TEAM-MENUS.TEAM.SORT-BUTTON.SYMBOL` | `str` | Any string text | `'▪'` | Configures the technical `SYMBOL` parameter for `TEAM-MENUS.TEAM.SORT-BUTTON.SYMBOL` in `menus.yml`. |
| `TEAM-MENUS.TEAM.REFRESH-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DTeam {team_name}'` | Configures the technical `TITLE` parameter for `TEAM-MENUS.TEAM.REFRESH-BUTTON.TITLE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.REFRESH-BUTTON.MATERIAL` | `str` | Any string text | `'IRON_HELMET'` | Configures the technical `MATERIAL` parameter for `TEAM-MENUS.TEAM.REFRESH-BUTTON.MATERIAL` in `menus.yml`. |
| `TEAM-MENUS.TEAM.REFRESH-BUTTON.SLOT` | `int` | Any valid integer number | `'49'` | Configures the technical `SLOT` parameter for `TEAM-MENUS.TEAM.REFRESH-BUTTON.SLOT` in `menus.yml`. |
| `TEAM-MENUS.TEAM.REFRESH-BUTTON.LORE` | `list` | List of configured items/strings | `['&fClick to refresh', '&7Add up to {max_members} members']` | Configures the technical `LORE` parameter for `TEAM-MENUS.TEAM.REFRESH-BUTTON.LORE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.HOME-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DTeam Home'` | Configures the technical `TITLE` parameter for `TEAM-MENUS.TEAM.HOME-BUTTON.TITLE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.HOME-BUTTON.MATERIAL` | `str` | Any string text | `'WHITE_BANNER'` | Configures the technical `MATERIAL` parameter for `TEAM-MENUS.TEAM.HOME-BUTTON.MATERIAL` in `menus.yml`. |
| `TEAM-MENUS.TEAM.HOME-BUTTON.SLOT` | `int` | Any valid integer number | `'52'` | Configures the technical `SLOT` parameter for `TEAM-MENUS.TEAM.HOME-BUTTON.SLOT` in `menus.yml`. |
| `TEAM-MENUS.TEAM.HOME-BUTTON.HOME-LORE` | `str` | Any string text | `'&fClick to teleport to your team's ...'` | Configures the technical `HOME-LORE` parameter for `TEAM-MENUS.TEAM.HOME-BUTTON.HOME-LORE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.HOME-BUTTON.NO-HOME-LORE` | `str` | Any string text | `'&fSet the team home with /home'` | Configures the technical `NO-HOME-LORE` parameter for `TEAM-MENUS.TEAM.HOME-BUTTON.NO-HOME-LORE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.PVP-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DPVP'` | Configures the technical `TITLE` parameter for `TEAM-MENUS.TEAM.PVP-BUTTON.TITLE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.PVP-BUTTON.MATERIAL` | `str` | Any string text | `'IRON_SWORD'` | Configures the technical `MATERIAL` parameter for `TEAM-MENUS.TEAM.PVP-BUTTON.MATERIAL` in `menus.yml`. |
| `TEAM-MENUS.TEAM.PVP-BUTTON.SLOT` | `int` | Any valid integer number | `'53'` | Configures the technical `SLOT` parameter for `TEAM-MENUS.TEAM.PVP-BUTTON.SLOT` in `menus.yml`. |
| `TEAM-MENUS.TEAM.PVP-BUTTON.ON-STATE` | `str` | Any string text | `'&a&lON'` | Configures the technical `ON-STATE` parameter for `TEAM-MENUS.TEAM.PVP-BUTTON.ON-STATE` in `menus.yml`. |
| `TEAM-MENUS.TEAM.PVP-BUTTON.OFF-STATE` | `str` | Any string text | `'&c&lOFF'` | Configures the technical `OFF-STATE` parameter for `TEAM-MENUS.TEAM.PVP-BUTTON.OFF-STATE` in `menus.yml`. |
| `TEAM-MENUS.TEAM-INFO.TITLE` | `str` | Any string text | `'&8Team {team_name}'` | Title of the read-only menu `/team info <team>` opens. `{team_name}` is the team being looked up. |
| `TEAM-MENUS.TEAM-INFO.SIZE` | `int` | Any valid integer number | `'54'` | Configures the technical `SIZE` parameter for `TEAM-MENUS.TEAM-INFO.SIZE` in `menus.yml`. |
| `TEAM-MENUS.TEAM-INFO.MAX-ITEMS-PER-PAGE` | `int` | Any valid integer number | `'45'` | How many member heads fit on one page before the arrows appear. |
| `TEAM-MENUS.TEAM-INFO.PLAYER-BUTTON.ONLINE-SYMBOL` | `str` | Any string text | `'&a■'` | Configures the technical `ONLINE-SYMBOL` parameter for `TEAM-MENUS.TEAM-INFO.PLAYER-BUTTON.ONLINE-SYMBOL` in `menus.yml`. |
| `TEAM-MENUS.TEAM-INFO.PLAYER-BUTTON.OFFLINE-SYMBOL` | `str` | Any string text | `'&4■'` | Configures the technical `OFFLINE-SYMBOL` parameter for `TEAM-MENUS.TEAM-INFO.PLAYER-BUTTON.OFFLINE-SYMBOL` in `menus.yml`. |
| `TEAM-MENUS.TEAM-INFO.PLAYER-BUTTON.LEADER-LORE` | `str` | Any string text | `'&6Leader'` | Extra lore line added to the head of the team leader. |
| `TEAM-MENUS.TEAM-INFO.SUMMARY-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DTeam {team_name}'` | Configures the technical `TITLE` parameter for `TEAM-MENUS.TEAM-INFO.SUMMARY-BUTTON.TITLE` in `menus.yml`. |
| `TEAM-MENUS.TEAM-INFO.SUMMARY-BUTTON.MATERIAL` | `str` | Any string text | `'IRON_HELMET'` | Configures the technical `MATERIAL` parameter for `TEAM-MENUS.TEAM-INFO.SUMMARY-BUTTON.MATERIAL` in `menus.yml`. |
| `TEAM-MENUS.TEAM-INFO.SUMMARY-BUTTON.SLOT` | `int` | Any valid integer number | `'49'` | Configures the technical `SLOT` parameter for `TEAM-MENUS.TEAM-INFO.SUMMARY-BUTTON.SLOT` in `menus.yml`. |
| `TEAM-MENUS.TEAM-INFO.SUMMARY-BUTTON.ON-STATE` | `str` | Any string text | `'&a&lON'` | Fills `{state}` in the summary lore while the team has friendly fire on. |
| `TEAM-MENUS.TEAM-INFO.SUMMARY-BUTTON.OFF-STATE` | `str` | Any string text | `'&c&lOFF'` | Fills `{state}` in the summary lore while the team has friendly fire off. |
| `TEAM-MENUS.TEAM-INFO.SUMMARY-BUTTON.LORE` | `list` | List of configured items/strings | `['&7Leader: &f{leader}', '&7Members: &f{members}&7/&f{max_members}', '&7PvP: {state}']` | Summary lore. Supports `{team_name}`, `{leader}`, `{members}`, `{max_members}` and `{state}`. |
| `TEAM-MENUS.TEAM-INFO.PAGE-BUTTON.TITLE` | `str` | Any string text | `'&fPage {page}&7/&f{total_pages}'` | Page counter shown once the roster spans more than one page. Supports `{page}` and `{total_pages}`. |
| `TEAM-MENUS.TEAM-INFO.PAGE-BUTTON.MATERIAL` | `str` | Any string text | `'PAPER'` | Configures the technical `MATERIAL` parameter for `TEAM-MENUS.TEAM-INFO.PAGE-BUTTON.MATERIAL` in `menus.yml`. |
| `TEAM-MENUS.TEAM-INFO.PAGE-BUTTON.SLOT` | `int` | Any valid integer number | `'50'` | Configures the technical `SLOT` parameter for `TEAM-MENUS.TEAM-INFO.PAGE-BUTTON.SLOT` in `menus.yml`. |
| `TEAM-MENUS.TEAM-INFO.PAGE-BUTTON.LORE` | `list` | List of configured items/strings | `['&7Browse team members.']` | Lore under the page counter. Supports `{page}` and `{total_pages}`. |
| *(68 additional sub-keys configured in section)* | | | | |

### 3. Practical Setup Example

```yaml
TEAM-MENUS:
  TEAM:
    TITLE: '&8Team'
    SIZE: 54
    MAX-ITEMS-PER-PAGE: 45
    PLAYER-BUTTON:
      ONLINE-SYMBOL: "&a■"
      OFFLINE-SYMBOL: "&4■"
      LORE: '&fClick to edit'
    SEARCH-BUTTON:
      TITLE: '&#6BF18DSearch'
      MATERIAL: OAK_SIGN
      SLOT: 45
      LORE:
      - '&fSearch for team members'
    SEARCH_SIGN:
      lines:
      - ''
      - ↑↑↑↑↑↑↑↑↑↑↑↑↑
      - Search
      - ''
      input-line: 0
    SORT-BUTTON:
      TITLE: '&aSort'
      MATERIAL: HOPPER
      SLOT: 46
      SELECTED-PREFIX: '&a'
      UNSELECTED-PREFIX: '&f'
      SYMBOL: "▪"
    REFRESH-BUTTON:
      TITLE: '&#6BF18DTeam {team_name}'
      MATERIAL: IRON_HELMET
      SLOT: 49
      LORE:
      - '&fClick to refresh'
      - '&7Add up to {max_members} members'
    HOME-BUTTON:
      TITLE: '&#6BF18DTeam Home'
      MATERIAL: WHITE_BANNER
      SLOT: 52
      HOME-LORE: '&fClick to teleport to your team''s home'
      NO-HOME-LORE: '&fSet the team home with /home'
    PVP-BUTTON:
      TITLE: '&#6BF18DPVP'
      MATERIAL: IRON_SWORD
      SLOT: 53
      ON-STATE: '&a&lON'
      OFF-STATE: '&c&lOFF'
      LORE: '&fCurrently: {state}'
    MESSAGES:
      NOT-IN-TEAM: '&cYou are not part of the team.'
      NO-PERMISSION: '&cYou don''t have permissions to do this.'
      CANT-EDIT-SELF: '&cYou can''t do this yourself!'
  TEAM-INFO:
    TITLE: '&8Team {team_name}'
    SIZE: 54
    MAX-ITEMS-PER-PAGE: 45
    PLAYER-BUTTON:
      ONLINE-SYMBOL: "&a■"
      OFFLINE-SYMBOL: "&4■"
      LEADER-LORE: '&6Leader'
    SUMMARY-BUTTON:
      TITLE: '&#6BF18DTeam {team_name}'
      MATERIAL: IRON_HELMET
      SLOT: 49
      ON-STATE: '&a&lON'
      OFF-STATE: '&c&lOFF'
      LORE:
      - '&7Leader: &f{leader}'
      - '&7Members: &f{members}&7/&f{max_members}'
      - '&7PvP: {state}'
    PAGE-BUTTON:
      TITLE: '&fPage {page}&7/&f{total_pages}'
      MATERIAL: PAPER
      SLOT: 50
      LORE:
      - '&7Browse team members.'
  TEAM-EDIT-MEMBER:
    TITLE: '&8Edit {player}'
    SIZE: 27
    PLACEHOLDER: false
    PLACEHOLDER-MATERIAL: BLACK_STAINED_GLASS_PANE
    EDIT-HOME-BUTTON:
      TITLE: '&#6BF18DEdit Home'
      MATERIAL: WHITE_BANNER
      SLOT: 10
      ON-STATE: '&a&lON'
      OFF-STATE: '&c&lOFF'
      LORE:
      - '&fLet {player} set and remove the team home'
      - '&fCurrently: {state}'
    KICK-BUTTON:
      TITLE: '&#6BF18DKick'
      MATERIAL: OAK_DOOR
      SLOT: 11
      LORE:
      - '&fClick to kick {player}'
    MANAGE-TEAMMATES-BUTTON:
      TITLE: '&#6BF18DManage Teammates'
      MATERIAL: IRON_HELMET
      SLOT: 12
      ON-STATE: '&a&lON'
      OFF-STATE: '&c&lOFF'
      LORE:
      - '&fLet {player} invite and kick teammates'
      - '&fCurrently: {state}'
    PVP-BUTTON:
      TITLE: '&#6BF18DPVP'
      MATERIAL: IRON_SWORD
      SLOT: 13
```

---

## Section: `HOME-MENU`

### 1. Commented Setup Code Example

```yaml
HOME-MENU:
  # Chest menu for Bedrock players. Set true to use the Floodgate popup.
  BEDROCK-FORMS: false
  TITLE: '&8Homes'
  SIZE: 36
  TELEPORT-USED-MATERIAL: LIGHT_BLUE_BED
  TELEPORT-NO-USED-MATERIAL: LIGHT_GRAY_BED
  TELEPORT-NO-PERMISSION-MATERIAL: RED_BED
  CREATE-USED-MATERIAL: BLUE_DYE
  CREATE-NO-USED-MATERIAL: GRAY_DYE
  CREATE-NO-PERMISSION-MATERIAL: RED_DYE
  TEAM_HOME:
    TELEPORT:
      MATERIALS:
        NO_TEAM: RED_BANNER
        NO_HOME: WHITE_BANNER
        HAS_HOME: WHITE_BANNER
      DISPLAY_NAME:
        NO_TEAM: '&cTeam Home'
        NO_HOME: '&fTeam Home'
        HAS_HOME: '&bTeam Home'
      LORE:
        NO_TEAM:
        - '&7You are not in a team.'
        NO_HOME:
        - '&7Click to create your team home.'
        HAS_HOME:
        - '&7World: &f{world}'
        - '&aLeft-click to teleport'
    SAVE:
      MATERIALS:
        NO_TEAM: RED_DYE
        NO_HOME: GRAY_DYE
        HAS_HOME: BLUE_DYE
      DISPLAY_NAME:
        NO_TEAM: '&cTeam Home'
        NO_HOME: '&7Set Team Home'
        HAS_HOME: '&bManage Team Home'
      LORE:
        NO_TEAM:
        - '&7You are not in a team.'
        NO_HOME:
        - '&7Left-click to save your team home.'
        HAS_HOME:
        - '&bLeft-click to update the team home'
        - '&cRight-click to delete'
  TELEPORT:
    HOME-1:
      DISPLAY-NAME:
        NO-USED: '&7{slot}'
        USED: '&b{name}'
        NO-PERMISSION: '&cLocked'
      LORE:
        NO-USED:
        - '&7Click to create a home.'
        USED:
        - '&7World: &f{world}'
        - '&aLeft-click to teleport'
        NO-PERMISSION:
        - '&7You need a higher rank for this home.'
    HOME-2:
      DISPLAY-NAME:
        NO-USED: '&7{slot}'
        USED: '&b{name}'
        NO-PERMISSION: '&cLocked'
      LORE:
        NO-USED:
        - '&7Click to create a home.'
        USED:
        - '&7World: &f{world}'
        - '&aLeft-click to teleport'
        NO-PERMISSION:
        - '&7You need a higher rank for this home.'
    HOME-3:
      DISPLAY-NAME:
        NO-USED: '&7{slot}'
        USED: '&b{name}'
        NO-PERMISSION: '&cLocked'
      LORE:
        NO-USED:
        - '&7Click to create a home.'
        USED:
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `HOME-MENU.TITLE` | `str` | Any string text | `'&8Homes'` | Configures the technical `TITLE` parameter for `HOME-MENU.TITLE` in `menus.yml`. |
| `HOME-MENU.SIZE` | `int` | Any valid integer number | `'36'` | Configures the technical `SIZE` parameter for `HOME-MENU.SIZE` in `menus.yml`. |
| `HOME-MENU.TELEPORT-USED-MATERIAL` | `str` | Any string text | `'LIGHT_BLUE_BED'` | Configures the technical `TELEPORT-USED-MATERIAL` parameter for `HOME-MENU.TELEPORT-USED-MATERIAL` in `menus.yml`. |
| `HOME-MENU.TELEPORT-NO-USED-MATERIAL` | `str` | Any string text | `'LIGHT_GRAY_BED'` | Configures the technical `TELEPORT-NO-USED-MATERIAL` parameter for `HOME-MENU.TELEPORT-NO-USED-MATERIAL` in `menus.yml`. |
| `HOME-MENU.TELEPORT-NO-PERMISSION-MATERIAL` | `str` | Any string text | `'RED_BED'` | Configures the technical `TELEPORT-NO-PERMISSION-MATERIAL` parameter for `HOME-MENU.TELEPORT-NO-PERMISSION-MATERIAL` in `menus.yml`. |
| `HOME-MENU.CREATE-USED-MATERIAL` | `str` | Any string text | `'BLUE_DYE'` | Configures the technical `CREATE-USED-MATERIAL` parameter for `HOME-MENU.CREATE-USED-MATERIAL` in `menus.yml`. |
| `HOME-MENU.CREATE-NO-USED-MATERIAL` | `str` | Any string text | `'GRAY_DYE'` | Configures the technical `CREATE-NO-USED-MATERIAL` parameter for `HOME-MENU.CREATE-NO-USED-MATERIAL` in `menus.yml`. |
| `HOME-MENU.CREATE-NO-PERMISSION-MATERIAL` | `str` | Any string text | `'RED_DYE'` | Configures the technical `CREATE-NO-PERMISSION-MATERIAL` parameter for `HOME-MENU.CREATE-NO-PERMISSION-MATERIAL` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.TELEPORT.MATERIALS.NO_TEAM` | `str` | Any string text | `'RED_BANNER'` | Configures the technical `NO_TEAM` parameter for `HOME-MENU.TEAM_HOME.TELEPORT.MATERIALS.NO_TEAM` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.TELEPORT.MATERIALS.NO_HOME` | `str` | Any string text | `'WHITE_BANNER'` | Configures the technical `NO_HOME` parameter for `HOME-MENU.TEAM_HOME.TELEPORT.MATERIALS.NO_HOME` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.TELEPORT.MATERIALS.HAS_HOME` | `str` | Any string text | `'WHITE_BANNER'` | Configures the technical `HAS_HOME` parameter for `HOME-MENU.TEAM_HOME.TELEPORT.MATERIALS.HAS_HOME` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.TELEPORT.DISPLAY_NAME.NO_TEAM` | `str` | Any string text | `'&cTeam Home'` | Configures the technical `NO_TEAM` parameter for `HOME-MENU.TEAM_HOME.TELEPORT.DISPLAY_NAME.NO_TEAM` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.TELEPORT.DISPLAY_NAME.NO_HOME` | `str` | Any string text | `'&fTeam Home'` | Configures the technical `NO_HOME` parameter for `HOME-MENU.TEAM_HOME.TELEPORT.DISPLAY_NAME.NO_HOME` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.TELEPORT.DISPLAY_NAME.HAS_HOME` | `str` | Any string text | `'&bTeam Home'` | Configures the technical `HAS_HOME` parameter for `HOME-MENU.TEAM_HOME.TELEPORT.DISPLAY_NAME.HAS_HOME` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.TELEPORT.LORE.NO_TEAM` | `list` | List of configured items/strings | `['&7You are not in a team.']` | Configures the technical `NO_TEAM` parameter for `HOME-MENU.TEAM_HOME.TELEPORT.LORE.NO_TEAM` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.TELEPORT.LORE.NO_HOME` | `list` | List of configured items/strings | `['&7Click to create your team home.']` | Configures the technical `NO_HOME` parameter for `HOME-MENU.TEAM_HOME.TELEPORT.LORE.NO_HOME` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.TELEPORT.LORE.HAS_HOME` | `list` | List of configured items/strings | `['&7World: &f{world}', '&aLeft-click to teleport']` | Configures the technical `HAS_HOME` parameter for `HOME-MENU.TEAM_HOME.TELEPORT.LORE.HAS_HOME` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.SAVE.MATERIALS.NO_TEAM` | `str` | Any string text | `'RED_DYE'` | Configures the technical `NO_TEAM` parameter for `HOME-MENU.TEAM_HOME.SAVE.MATERIALS.NO_TEAM` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.SAVE.MATERIALS.NO_HOME` | `str` | Any string text | `'GRAY_DYE'` | Configures the technical `NO_HOME` parameter for `HOME-MENU.TEAM_HOME.SAVE.MATERIALS.NO_HOME` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.SAVE.MATERIALS.HAS_HOME` | `str` | Any string text | `'BLUE_DYE'` | Configures the technical `HAS_HOME` parameter for `HOME-MENU.TEAM_HOME.SAVE.MATERIALS.HAS_HOME` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.SAVE.DISPLAY_NAME.NO_TEAM` | `str` | Any string text | `'&cTeam Home'` | Configures the technical `NO_TEAM` parameter for `HOME-MENU.TEAM_HOME.SAVE.DISPLAY_NAME.NO_TEAM` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.SAVE.DISPLAY_NAME.NO_HOME` | `str` | Any string text | `'&7Set Team Home'` | Configures the technical `NO_HOME` parameter for `HOME-MENU.TEAM_HOME.SAVE.DISPLAY_NAME.NO_HOME` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.SAVE.DISPLAY_NAME.HAS_HOME` | `str` | Any string text | `'&bManage Team Home'` | Configures the technical `HAS_HOME` parameter for `HOME-MENU.TEAM_HOME.SAVE.DISPLAY_NAME.HAS_HOME` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.SAVE.LORE.NO_TEAM` | `list` | List of configured items/strings | `['&7You are not in a team.']` | Configures the technical `NO_TEAM` parameter for `HOME-MENU.TEAM_HOME.SAVE.LORE.NO_TEAM` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.SAVE.LORE.NO_HOME` | `list` | List of configured items/strings | `['&7Left-click to save your team home.']` | Configures the technical `NO_HOME` parameter for `HOME-MENU.TEAM_HOME.SAVE.LORE.NO_HOME` in `menus.yml`. |
| `HOME-MENU.TEAM_HOME.SAVE.LORE.HAS_HOME` | `list` | List of configured items/strings | `['&bLeft-click to update the team home', '&cRight-click to delete']` | Configures the technical `HAS_HOME` parameter for `HOME-MENU.TEAM_HOME.SAVE.LORE.HAS_HOME` in `menus.yml`. |
| `HOME-MENU.TELEPORT.HOME-1.DISPLAY-NAME.NO-USED` | `str` | Any string text | `'&7{slot}'` | Configures the technical `NO-USED` parameter for `HOME-MENU.TELEPORT.HOME-1.DISPLAY-NAME.NO-USED` in `menus.yml`. |
| `HOME-MENU.TELEPORT.HOME-1.DISPLAY-NAME.USED` | `str` | Any string text | `'&b{name}'` | Configures the technical `USED` parameter for `HOME-MENU.TELEPORT.HOME-1.DISPLAY-NAME.USED` in `menus.yml`. |
| `HOME-MENU.TELEPORT.HOME-1.DISPLAY-NAME.NO-PERMISSION` | `str` | Any string text | `'&cLocked'` | Configures the technical `NO-PERMISSION` parameter for `HOME-MENU.TELEPORT.HOME-1.DISPLAY-NAME.NO-PERMISSION` in `menus.yml`. |
| `HOME-MENU.TELEPORT.HOME-1.LORE.NO-USED` | `list` | List of configured items/strings | `['&7Click to create a home.']` | Configures the technical `NO-USED` parameter for `HOME-MENU.TELEPORT.HOME-1.LORE.NO-USED` in `menus.yml`. |
| *(56 additional sub-keys configured in section)* | | | | |

Both `&cRight-click to delete` lines mean what they say, but the click opens a confirmation screen
rather than removing anything on the spot, so a missed left-click no longer costs a player a home.
Cancelling puts them back on the page they were reading. Bedrock players get that same chest
confirmation. Set `HOME-MENU.BEDROCK-FORMS` to `true` in `menus.yml` when you want the Floodgate
popup.

### 3. Practical Setup Example

```yaml
HOME-MENU:
  # Chest menu for Bedrock players. Set true to use the Floodgate popup.
  BEDROCK-FORMS: false
  TITLE: '&8Homes'
  SIZE: 36
  TELEPORT-USED-MATERIAL: LIGHT_BLUE_BED
  TELEPORT-NO-USED-MATERIAL: LIGHT_GRAY_BED
  TELEPORT-NO-PERMISSION-MATERIAL: RED_BED
  CREATE-USED-MATERIAL: BLUE_DYE
  CREATE-NO-USED-MATERIAL: GRAY_DYE
  CREATE-NO-PERMISSION-MATERIAL: RED_DYE
  TEAM_HOME:
    TELEPORT:
      MATERIALS:
        NO_TEAM: RED_BANNER
        NO_HOME: WHITE_BANNER
        HAS_HOME: WHITE_BANNER
      DISPLAY_NAME:
        NO_TEAM: '&cTeam Home'
        NO_HOME: '&fTeam Home'
        HAS_HOME: '&bTeam Home'
      LORE:
        NO_TEAM:
        - '&7You are not in a team.'
        NO_HOME:
        - '&7Click to create your team home.'
        HAS_HOME:
        - '&7World: &f{world}'
        - '&aLeft-click to teleport'
    SAVE:
      MATERIALS:
        NO_TEAM: RED_DYE
        NO_HOME: GRAY_DYE
        HAS_HOME: BLUE_DYE
      DISPLAY_NAME:
        NO_TEAM: '&cTeam Home'
        NO_HOME: '&7Set Team Home'
        HAS_HOME: '&bManage Team Home'
      LORE:
        NO_TEAM:
        - '&7You are not in a team.'
        NO_HOME:
        - '&7Left-click to save your team home.'
        HAS_HOME:
        - '&bLeft-click to update the team home'
        - '&cRight-click to delete'
  TELEPORT:
    HOME-1:
      DISPLAY-NAME:
        NO-USED: '&7{slot}'
        USED: '&b{name}'
        NO-PERMISSION: '&cLocked'
      LORE:
        NO-USED:
        - '&7Click to create a home.'
        USED:
        - '&7World: &f{world}'
        - '&aLeft-click to teleport'
        NO-PERMISSION:
        - '&7You need a higher rank for this home.'
    HOME-2:
      DISPLAY-NAME:
        NO-USED: '&7{slot}'
        USED: '&b{name}'
        NO-PERMISSION: '&cLocked'
      LORE:
        NO-USED:
        - '&7Click to create a home.'
        USED:
        - '&7World: &f{world}'
        - '&aLeft-click to teleport'
        NO-PERMISSION:
        - '&7You need a higher rank for this home.'
    HOME-3:
      DISPLAY-NAME:
        NO-USED: '&7{slot}'
        USED: '&b{name}'
        NO-PERMISSION: '&cLocked'
      LORE:
        NO-USED:
        - '&7Click to create a home.'
        USED:
```

---

## Section: `MEDIA-MENU`

### 1. Commented Setup Code Example

```yaml
MEDIA-MENU:
  TITLE: '&8Media Rank'
  SIZE: 27
  MEDIA-BUTTON:
    DISPLAY-NAME: '&dMedia Rank'
    MATERIAL: PINK_DYE
    SLOT: 13
    LORE:
    - '&dReQuirements: (only one needed)'
    - '&d- &f25 average viewers on Stream'
    - '&d- &f5k views on a YouTube Video'
    - '&d- &f25k views on a TikTok'
    - '&d- &f50k views on YouTube Short'
    - ''
    - '&dReminders:'
    - '&8- &7Must have the IP on screen'
    - '&8- &7Must be from the new season'
    - '&8- &7Create ticket in discord for the rank'
    - '&8- &7It lasts 90 days and has all top ranks perks'
    - ''
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `MEDIA-MENU.TITLE` | `str` | Any string text | `'&8Media Rank'` | Configures the technical `TITLE` parameter for `MEDIA-MENU.TITLE` in `menus.yml`. |
| `MEDIA-MENU.SIZE` | `int` | Any valid integer number | `'27'` | Configures the technical `SIZE` parameter for `MEDIA-MENU.SIZE` in `menus.yml`. |
| `MEDIA-MENU.MEDIA-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&dMedia Rank'` | Configures the technical `DISPLAY-NAME` parameter for `MEDIA-MENU.MEDIA-BUTTON.DISPLAY-NAME` in `menus.yml`. |
| `MEDIA-MENU.MEDIA-BUTTON.MATERIAL` | `str` | Any string text | `'PINK_DYE'` | Configures the technical `MATERIAL` parameter for `MEDIA-MENU.MEDIA-BUTTON.MATERIAL` in `menus.yml`. |
| `MEDIA-MENU.MEDIA-BUTTON.SLOT` | `int` | Any valid integer number | `'13'` | Configures the technical `SLOT` parameter for `MEDIA-MENU.MEDIA-BUTTON.SLOT` in `menus.yml`. |
| `MEDIA-MENU.MEDIA-BUTTON.LORE` | `list` | List of configured items/strings | `[&dReQuirements: (only one needed), &d- &f25 average viewers on Stream, &d- &f5k views on a YouTube Video...]` | Configures the technical `LORE` parameter for `MEDIA-MENU.MEDIA-BUTTON.LORE` in `menus.yml`. |

### 3. Practical Setup Example

```yaml
MEDIA-MENU:
  TITLE: '&8Media Rank'
  SIZE: 27
  MEDIA-BUTTON:
    DISPLAY-NAME: '&dMedia Rank'
    MATERIAL: PINK_DYE
    SLOT: 13
    LORE:
    - '&dReQuirements: (only one needed)'
    - '&d- &f25 average viewers on Stream'
    - '&d- &f5k views on a YouTube Video'
    - '&d- &f25k views on a TikTok'
    - '&d- &f50k views on YouTube Short'
    - ''
    - '&dReminders:'
    - '&8- &7Must have the IP on screen'
    - '&8- &7Must be from the new season'
    - '&8- &7Create ticket in discord for the rank'
    - '&8- &7It lasts 90 days and has all top ranks perks'
    - ''
```

---

## Section: `RANKS-MENU`

Opened with `/ranks` (alias `/rank`). Every button is a rank advert: the icon plus its lore lists what
that rank unlocks, so players can compare ranks without leaving the game.

### 1. Commented Setup Code Example

```yaml
RANKS-MENU:
  TITLE: '&8Ranks'
  SIZE: 27
  BUTTONS:
    # Each key under BUTTONS is one rank. Add or delete keys freely.
    DEFAULT:
      MATERIAL: PLAYER_HEAD
      SLOT: 11
      DISPLAY-NAME: '&fDefault'
      LORE:
      - '&73 Homes'
      - '&718 Auction Slots'
      - '&718 Order Slots'
      # Leave COMMAND empty for a button that only shows perks.
      COMMAND: ''
    DONUT_PLUS:
      MATERIAL: PLAYER_HEAD
      SLOT: 13
      DISPLAY-NAME: '&fDonut&#00A4FC+'
      LORE:
      - '&79 Homes'
      - '&745 Auction Slots'
      - '&745 Order Slots'
      COMMAND: ''
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `RANKS-MENU.TITLE` | `str` | Any string text | `'&8Ranks'` | Inventory title shown at the top of the menu. |
| `RANKS-MENU.SIZE` | `int` | `9`, `18`, `27`, `36`, `45`, `54` | `27` | Inventory size. Anything else falls back to `27` with a console warning. |
| `RANKS-MENU.FILLER-MATERIAL` | `str` | Any valid material name | unset | Optional. Fills the slots no rank uses, e.g. `BLACK_STAINED_GLASS_PANE`. Unset leaves them empty. |
| `RANKS-MENU.BUTTONS.<RANK>.MATERIAL` | `str` | Any valid material name | `PLAYER_HEAD` | Icon material. A button with a missing or invalid material is skipped. |
| `RANKS-MENU.BUTTONS.<RANK>.SLOT` | `int` | `0` to `SIZE - 1` | - | Slot the rank renders in. Out-of-range and duplicate slots are skipped. |
| `RANKS-MENU.BUTTONS.<RANK>.DISPLAY-NAME` | `str` | Any string text | Prettified button key | Icon name. `NAME` also works for consistency with the other menus. |
| `RANKS-MENU.BUTTONS.<RANK>.LORE` | `list` | List of strings | `[]` | The perk list shown under the rank name. |
| `RANKS-MENU.BUTTONS.<RANK>.HEAD-TEXTURE` | `str` | Skin URL or base64 texture | `''` | Optional. Applied when `MATERIAL` is `PLAYER_HEAD` so a rank can use a custom head. |
| `RANKS-MENU.BUTTONS.<RANK>.COMMAND` | `str` | Any command, with or without `/` | `''` | Run as the player on click. Empty keeps the button informational. |

### 3. Practical Setup Example

Custom heads plus a click that sends the player to the store page:

```yaml
RANKS-MENU:
  TITLE: '&8Ranks'
  SIZE: 27
  BUTTONS:
    DONUT_PLUS:
      MATERIAL: PLAYER_HEAD
      SLOT: 13
      DISPLAY-NAME: '&fDonut&#00A4FC+'
      HEAD-TEXTURE: 'https://textures.minecraft.net/texture/d875eb45aca34a4d24c3dc1395fc020ccf37f825a17b054a22fd24b189c24c'
      LORE:
      - '&79 Homes'
      - '&745 Auction Slots'
      - '&745 Order Slots'
      - ''
      - '&7Click to open the store'
      COMMAND: 'store'
```

---

## Section: `STATS-MENU`

### 1. Commented Setup Code Example

```yaml
STATS-MENU:
  TITLE: '&8{username} Stats'
  SIZE: 36
  BUTTONS:
    MONEY:
      DISPLAY-NAME: '&#6BF18DMoney'
      MATERIAL: EMERALD
      SLOT: 10
      LORE:
      - '&7{value}'
    SHARDS:
      DISPLAY-NAME: '&#6BF18DShards'
      MATERIAL: AMETHYST_SHARD
      SLOT: 11
      LORE:
      - '&7{value}'
    KILLS:
      DISPLAY-NAME: '&#6BF18DKills'
      MATERIAL: DIAMOND_SWORD
      SLOT: 12
      LORE:
      - '&7{value}'
    DEATHS:
      DISPLAY-NAME: '&#6BF18DDeaths'
      MATERIAL: SKELETON_SKULL
      SLOT: 13
      LORE:
      - '&7{value}'
    PLAYTIME:
      DISPLAY-NAME: '&#6BF18DPlaytime'
      MATERIAL: CLOCK
      SLOT: 14
      LORE:
      - '&7{value}'
    BLOCKS_PLACED:
      DISPLAY-NAME: '&#6BF18DBlocks Placed'
      MATERIAL: STONE
      SLOT: 15
      LORE:
      - '&7{value}'
    BLOCKS_BROKEN:
      DISPLAY-NAME: '&#6BF18DBlocks Broken'
      MATERIAL: COBBLESTONE
      SLOT: 16
      LORE:
      - '&7{value}'
    MOBS_KILLED:
      DISPLAY-NAME: '&#6BF18DMobs Killed'
      MATERIAL: ZOMBIE_HEAD
      SLOT: 19
      LORE:
      - '&7{value}'
    KILL_STREAK:
      DISPLAY-NAME: '&#6BF18DKill Streak'
      MATERIAL: DIAMOND_AXE
      SLOT: 20
      LORE:
      - '&7{value}'
    HIGHEST_KILL_STREAK:
      DISPLAY-NAME: '&#6BF18DHighest Kill Streak'
      MATERIAL: NETHERITE_SWORD
      SLOT: 21
      LORE:
      - '&7{value}'
    MONEY_SPENT:
      DISPLAY-NAME: '&#6BF18DMoney Spent On Shop'
      MATERIAL: GOLD_NUGGET
      SLOT: 22
      LORE:
      - '&7{value}'
    MONEY_MADE:
      DISPLAY-NAME: '&#6BF18DMoney Made On /Sell'
      MATERIAL: IRON_NUGGET
      SLOT: 23
      LORE:
      - '&7{value}'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `STATS-MENU.TITLE` | `str` | Any string text | `'&8{username} Stats'` | Configures the technical `TITLE` parameter for `STATS-MENU.TITLE` in `menus.yml`. |
| `STATS-MENU.SIZE` | `int` | Any valid integer number | `'36'` | Configures the technical `SIZE` parameter for `STATS-MENU.SIZE` in `menus.yml`. |
| `STATS-MENU.BUTTONS.MONEY.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DMoney'` | Configures the technical `DISPLAY-NAME` parameter for `STATS-MENU.BUTTONS.MONEY.DISPLAY-NAME` in `menus.yml`. |
| `STATS-MENU.BUTTONS.MONEY.MATERIAL` | `str` | Any string text | `'EMERALD'` | Configures the technical `MATERIAL` parameter for `STATS-MENU.BUTTONS.MONEY.MATERIAL` in `menus.yml`. |
| `STATS-MENU.BUTTONS.MONEY.SLOT` | `int` | Any valid integer number | `'10'` | Configures the technical `SLOT` parameter for `STATS-MENU.BUTTONS.MONEY.SLOT` in `menus.yml`. |
| `STATS-MENU.BUTTONS.MONEY.LORE` | `list` | List of configured items/strings | `['&7{value}']` | Configures the technical `LORE` parameter for `STATS-MENU.BUTTONS.MONEY.LORE` in `menus.yml`. |
| `STATS-MENU.BUTTONS.SHARDS.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DShards'` | Configures the technical `DISPLAY-NAME` parameter for `STATS-MENU.BUTTONS.SHARDS.DISPLAY-NAME` in `menus.yml`. |
| `STATS-MENU.BUTTONS.SHARDS.MATERIAL` | `str` | Any string text | `'AMETHYST_SHARD'` | Configures the technical `MATERIAL` parameter for `STATS-MENU.BUTTONS.SHARDS.MATERIAL` in `menus.yml`. |
| `STATS-MENU.BUTTONS.SHARDS.SLOT` | `int` | Any valid integer number | `'11'` | Configures the technical `SLOT` parameter for `STATS-MENU.BUTTONS.SHARDS.SLOT` in `menus.yml`. |
| `STATS-MENU.BUTTONS.SHARDS.LORE` | `list` | List of configured items/strings | `['&7{value}']` | Configures the technical `LORE` parameter for `STATS-MENU.BUTTONS.SHARDS.LORE` in `menus.yml`. |
| `STATS-MENU.BUTTONS.KILLS.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DKills'` | Configures the technical `DISPLAY-NAME` parameter for `STATS-MENU.BUTTONS.KILLS.DISPLAY-NAME` in `menus.yml`. |
| `STATS-MENU.BUTTONS.KILLS.MATERIAL` | `str` | Any string text | `'DIAMOND_SWORD'` | Configures the technical `MATERIAL` parameter for `STATS-MENU.BUTTONS.KILLS.MATERIAL` in `menus.yml`. |
| `STATS-MENU.BUTTONS.KILLS.SLOT` | `int` | Any valid integer number | `'12'` | Configures the technical `SLOT` parameter for `STATS-MENU.BUTTONS.KILLS.SLOT` in `menus.yml`. |
| `STATS-MENU.BUTTONS.KILLS.LORE` | `list` | List of configured items/strings | `['&7{value}']` | Configures the technical `LORE` parameter for `STATS-MENU.BUTTONS.KILLS.LORE` in `menus.yml`. |
| `STATS-MENU.BUTTONS.DEATHS.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DDeaths'` | Configures the technical `DISPLAY-NAME` parameter for `STATS-MENU.BUTTONS.DEATHS.DISPLAY-NAME` in `menus.yml`. |
| `STATS-MENU.BUTTONS.DEATHS.MATERIAL` | `str` | Any string text | `'SKELETON_SKULL'` | Configures the technical `MATERIAL` parameter for `STATS-MENU.BUTTONS.DEATHS.MATERIAL` in `menus.yml`. |
| `STATS-MENU.BUTTONS.DEATHS.SLOT` | `int` | Any valid integer number | `'13'` | Configures the technical `SLOT` parameter for `STATS-MENU.BUTTONS.DEATHS.SLOT` in `menus.yml`. |
| `STATS-MENU.BUTTONS.DEATHS.LORE` | `list` | List of configured items/strings | `['&7{value}']` | Configures the technical `LORE` parameter for `STATS-MENU.BUTTONS.DEATHS.LORE` in `menus.yml`. |
| `STATS-MENU.BUTTONS.PLAYTIME.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DPlaytime'` | Configures the technical `DISPLAY-NAME` parameter for `STATS-MENU.BUTTONS.PLAYTIME.DISPLAY-NAME` in `menus.yml`. |
| `STATS-MENU.BUTTONS.PLAYTIME.MATERIAL` | `str` | Any string text | `'CLOCK'` | Configures the technical `MATERIAL` parameter for `STATS-MENU.BUTTONS.PLAYTIME.MATERIAL` in `menus.yml`. |
| `STATS-MENU.BUTTONS.PLAYTIME.SLOT` | `int` | Any valid integer number | `'14'` | Configures the technical `SLOT` parameter for `STATS-MENU.BUTTONS.PLAYTIME.SLOT` in `menus.yml`. |
| `STATS-MENU.BUTTONS.PLAYTIME.LORE` | `list` | List of configured items/strings | `['&7{value}']` | Configures the technical `LORE` parameter for `STATS-MENU.BUTTONS.PLAYTIME.LORE` in `menus.yml`. |
| `STATS-MENU.BUTTONS.BLOCKS_PLACED.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DBlocks Placed'` | Configures the technical `DISPLAY-NAME` parameter for `STATS-MENU.BUTTONS.BLOCKS_PLACED.DISPLAY-NAME` in `menus.yml`. |
| `STATS-MENU.BUTTONS.BLOCKS_PLACED.MATERIAL` | `str` | Any string text | `'STONE'` | Configures the technical `MATERIAL` parameter for `STATS-MENU.BUTTONS.BLOCKS_PLACED.MATERIAL` in `menus.yml`. |
| `STATS-MENU.BUTTONS.BLOCKS_PLACED.SLOT` | `int` | Any valid integer number | `'15'` | Configures the technical `SLOT` parameter for `STATS-MENU.BUTTONS.BLOCKS_PLACED.SLOT` in `menus.yml`. |
| `STATS-MENU.BUTTONS.BLOCKS_PLACED.LORE` | `list` | List of configured items/strings | `['&7{value}']` | Configures the technical `LORE` parameter for `STATS-MENU.BUTTONS.BLOCKS_PLACED.LORE` in `menus.yml`. |
| `STATS-MENU.BUTTONS.BLOCKS_BROKEN.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DBlocks Broken'` | Configures the technical `DISPLAY-NAME` parameter for `STATS-MENU.BUTTONS.BLOCKS_BROKEN.DISPLAY-NAME` in `menus.yml`. |
| `STATS-MENU.BUTTONS.BLOCKS_BROKEN.MATERIAL` | `str` | Any string text | `'COBBLESTONE'` | Configures the technical `MATERIAL` parameter for `STATS-MENU.BUTTONS.BLOCKS_BROKEN.MATERIAL` in `menus.yml`. |
| `STATS-MENU.BUTTONS.BLOCKS_BROKEN.SLOT` | `int` | Any valid integer number | `'16'` | Configures the technical `SLOT` parameter for `STATS-MENU.BUTTONS.BLOCKS_BROKEN.SLOT` in `menus.yml`. |
| `STATS-MENU.BUTTONS.BLOCKS_BROKEN.LORE` | `list` | List of configured items/strings | `['&7{value}']` | Configures the technical `LORE` parameter for `STATS-MENU.BUTTONS.BLOCKS_BROKEN.LORE` in `menus.yml`. |
| *(20 additional sub-keys configured in section)* | | | | |

### 3. Practical Setup Example

```yaml
STATS-MENU:
  TITLE: '&8{username} Stats'
  SIZE: 36
  BUTTONS:
    MONEY:
      DISPLAY-NAME: '&#6BF18DMoney'
      MATERIAL: EMERALD
      SLOT: 10
      LORE:
      - '&7{value}'
    SHARDS:
      DISPLAY-NAME: '&#6BF18DShards'
      MATERIAL: AMETHYST_SHARD
      SLOT: 11
      LORE:
      - '&7{value}'
    KILLS:
      DISPLAY-NAME: '&#6BF18DKills'
      MATERIAL: DIAMOND_SWORD
      SLOT: 12
      LORE:
      - '&7{value}'
    DEATHS:
      DISPLAY-NAME: '&#6BF18DDeaths'
      MATERIAL: SKELETON_SKULL
      SLOT: 13
      LORE:
      - '&7{value}'
    PLAYTIME:
      DISPLAY-NAME: '&#6BF18DPlaytime'
      MATERIAL: CLOCK
      SLOT: 14
      LORE:
      - '&7{value}'
    BLOCKS_PLACED:
      DISPLAY-NAME: '&#6BF18DBlocks Placed'
      MATERIAL: STONE
      SLOT: 15
      LORE:
      - '&7{value}'
    BLOCKS_BROKEN:
      DISPLAY-NAME: '&#6BF18DBlocks Broken'
      MATERIAL: COBBLESTONE
      SLOT: 16
      LORE:
      - '&7{value}'
    MOBS_KILLED:
      DISPLAY-NAME: '&#6BF18DMobs Killed'
      MATERIAL: ZOMBIE_HEAD
      SLOT: 19
      LORE:
      - '&7{value}'
    KILL_STREAK:
      DISPLAY-NAME: '&#6BF18DKill Streak'
      MATERIAL: DIAMOND_AXE
      SLOT: 20
      LORE:
      - '&7{value}'
    HIGHEST_KILL_STREAK:
      DISPLAY-NAME: '&#6BF18DHighest Kill Streak'
      MATERIAL: NETHERITE_SWORD
      SLOT: 21
      LORE:
      - '&7{value}'
    MONEY_SPENT:
      DISPLAY-NAME: '&#6BF18DMoney Spent On Shop'
      MATERIAL: GOLD_NUGGET
      SLOT: 22
      LORE:
      - '&7{value}'
    MONEY_MADE:
      DISPLAY-NAME: '&#6BF18DMoney Made On /Sell'
      MATERIAL: IRON_NUGGET
      SLOT: 23
      LORE:
      - '&7{value}'
```

---

## Section: `SETTINGS-MENU`

### 1. Commented Setup Code Example

```yaml
SETTINGS-MENU:
  TITLE: '&8Settings'
  SIZE: 54
  FEEDBACK:
    TOGGLE-MESSAGE: '&7{setting} is now {state}&7.'
    CHOICE-MESSAGE: '&7{setting} is now set to {choice}&7.'
    STATE-ENABLED: '&aEnabled'
    STATE-DISABLED: '&cDisabled'
    CHOICE-OFF-TEXT: '&cOff'
    CHOICE-ANYONE-TEXT: '&aAnyone'
    CHOICE-FRIENDS-FOLLOWED-TEXT: '&dFriends/Followed'
  BUTTONS:
    # Buttons are grouped a row at a time: chat and messages on the first row,
    # alerts on the second, gameplay and display on the third, who may reach you on
    # the fourth, the scoreboard on the fifth, and the world around you on the last.
    # Every setting below accepts two optional keys:
    #   DEFAULT: <value>  Starting value for players who never touched the setting.
    #                     On/off buttons take true or false. The privacy buttons
    #                     (PRIVATE_MESSAGES, TPA_REQUESTS, TPA_HERE_REQUESTS, PAYMENTS)
    #                     take ANYONE, FRIENDS_FOLLOWED or OFF. DEATH_MESSAGES and
    #                     JOIN_LEAVE_MESSAGES are on or off: both feeds are server
    #                     wide, so those buttons only mute them.
    #                     true/false also work as shortcuts.
    #   ENABLED: false    Removes the option from /settings and pins every player to the
    #                     DEFAULT above. Use this instead of deleting the block - deleted
    #                     blocks are restored from the bundled defaults on the next start.
    # Example, hide advancement messages and keep them off for everyone:
    # ADVANCEMENT_MESSAGES:
    #   DEFAULT: OFF
    #   ENABLED: false
    # Custom redirect buttons can also be added here:
    # EXTERNAL_FLY:
    #   DISPLAY-NAME: '&bFlight Mode'
    #   MATERIAL: FEATHER
    #   SLOT: 25
    #   COMMAND: '[player] /fly'
    #   STATUS-PLACEHOLDER: '%cmi_user_flying%'
    #   LORE:
    #   - '&7Toggle flight via external plugin'
    #   - '&fCurrently: {status}'
    # Row 1 - chat and messages
    PUBLIC_CHAT:
      DISPLAY-NAME: '&#6BF18DPublic Chat'
      MATERIAL: OAK_SIGN
      SLOT: 0
      LORE:
      - '&7Receive public chat messages'
      - '&fCurrently: {status}'
    PRIVATE_MESSAGES:
      DISPLAY-NAME: '&#6BF18DPrivate Messages'
      MATERIAL: DARK_OAK_SIGN
      SLOT: 1
      LORE:
      - '&7Private messages privacy settings'
      - '&fCurrently: {status}'
    SERVER_BROADCASTS:
      DISPLAY-NAME: '&#6BF18DServer Broadcasts'
      MATERIAL: WARPED_SIGN
      SLOT: 2
      LORE:
      - '&7Receive server broadcasts'
      - '&fCurrently: {status}'
    HOTBAR_MESSAGES:
      DISPLAY-NAME: '&#6BF18DHotbar Messages'
      MATERIAL: CRIMSON_SIGN
      SLOT: 3
      LORE:
      - '&7Show action bar status notifications'
      - '&fCurrently: {status}'
    DEATH_MESSAGES:
      DISPLAY-NAME: '&#6BF18DDeath Messages'
      MATERIAL: SPRUCE_SIGN
      SLOT: 4
      LORE:
      - '&7Show death message notifications'
      - '&fCurrently: {status}'
    ADVANCEMENT_MESSAGES:
      DISPLAY-NAME: '&#6BF18DAdvancement Messages'
      MATERIAL: BIRCH_SIGN
      SLOT: 5
      LORE:
      - '&7Show advancement achievement notifications'
      - '&fCurrently: {status}'
    JOIN_LEAVE_MESSAGES:
      DISPLAY-NAME: '&#6BF18DJoin/Leave Messages'
      MATERIAL: JUNGLE_SIGN
      SLOT: 6
      LORE:
      - '&7Show join and leave notifications'
      - '&fCurrently: {status}'
    TEAM_CHAT_VISIBILITY:
      DISPLAY-NAME: '&#6BF18DTeam Chat Visibility'
      MATERIAL: MANGROVE_SIGN
      SLOT: 7
      LORE:
      - '&7Show team chat in main chat'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `SETTINGS-MENU.TITLE` | `str` | Any string text | `'&8Settings'` | Configures the technical `TITLE` parameter for `SETTINGS-MENU.TITLE` in `menus.yml`. |
| `SETTINGS-MENU.SIZE` | `int` | Any valid integer number | `'54'` | Configures the technical `SIZE` parameter for `SETTINGS-MENU.SIZE` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.PUBLIC_CHAT.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DPublic Chat'` | Configures the technical `DISPLAY-NAME` parameter for `SETTINGS-MENU.BUTTONS.PUBLIC_CHAT.DISPLAY-NAME` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.PUBLIC_CHAT.MATERIAL` | `str` | Any string text | `'OAK_SIGN'` | Configures the technical `MATERIAL` parameter for `SETTINGS-MENU.BUTTONS.PUBLIC_CHAT.MATERIAL` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.PUBLIC_CHAT.SLOT` | `int` | Any valid integer number | `'0'` | Configures the technical `SLOT` parameter for `SETTINGS-MENU.BUTTONS.PUBLIC_CHAT.SLOT` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.PUBLIC_CHAT.LORE` | `list` | List of configured items/strings | `['&7Receive public chat messages', '&fCurrently: {status}']` | Configures the technical `LORE` parameter for `SETTINGS-MENU.BUTTONS.PUBLIC_CHAT.LORE` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.PRIVATE_MESSAGES.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DPrivate Messages'` | Configures the technical `DISPLAY-NAME` parameter for `SETTINGS-MENU.BUTTONS.PRIVATE_MESSAGES.DISPLAY-NAME` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.PRIVATE_MESSAGES.MATERIAL` | `str` | Any string text | `'DARK_OAK_SIGN'` | Configures the technical `MATERIAL` parameter for `SETTINGS-MENU.BUTTONS.PRIVATE_MESSAGES.MATERIAL` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.PRIVATE_MESSAGES.SLOT` | `int` | Any valid integer number | `'1'` | Configures the technical `SLOT` parameter for `SETTINGS-MENU.BUTTONS.PRIVATE_MESSAGES.SLOT` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.PRIVATE_MESSAGES.LORE` | `list` | List of configured items/strings | `['&7Private messages privacy settings', '&fCurrently: {status}']` | Configures the technical `LORE` parameter for `SETTINGS-MENU.BUTTONS.PRIVATE_MESSAGES.LORE` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.SERVER_BROADCASTS.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DServer Broadcasts'` | Configures the technical `DISPLAY-NAME` parameter for `SETTINGS-MENU.BUTTONS.SERVER_BROADCASTS.DISPLAY-NAME` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.SERVER_BROADCASTS.MATERIAL` | `str` | Any string text | `'WARPED_SIGN'` | Configures the technical `MATERIAL` parameter for `SETTINGS-MENU.BUTTONS.SERVER_BROADCASTS.MATERIAL` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.SERVER_BROADCASTS.SLOT` | `int` | Any valid integer number | `'2'` | Configures the technical `SLOT` parameter for `SETTINGS-MENU.BUTTONS.SERVER_BROADCASTS.SLOT` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.SERVER_BROADCASTS.LORE` | `list` | List of configured items/strings | `['&7Receive server broadcasts', '&fCurrently: {status}']` | Configures the technical `LORE` parameter for `SETTINGS-MENU.BUTTONS.SERVER_BROADCASTS.LORE` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.HOTBAR_MESSAGES.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DHotbar Messages'` | Configures the technical `DISPLAY-NAME` parameter for `SETTINGS-MENU.BUTTONS.HOTBAR_MESSAGES.DISPLAY-NAME` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.HOTBAR_MESSAGES.MATERIAL` | `str` | Any string text | `'CRIMSON_SIGN'` | Configures the technical `MATERIAL` parameter for `SETTINGS-MENU.BUTTONS.HOTBAR_MESSAGES.MATERIAL` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.HOTBAR_MESSAGES.SLOT` | `int` | Any valid integer number | `'3'` | Configures the technical `SLOT` parameter for `SETTINGS-MENU.BUTTONS.HOTBAR_MESSAGES.SLOT` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.HOTBAR_MESSAGES.LORE` | `list` | List of configured items/strings | `['&7Show action bar status notifications', '&fCurrently: {status}']` | Configures the technical `LORE` parameter for `SETTINGS-MENU.BUTTONS.HOTBAR_MESSAGES.LORE` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.DEATH_MESSAGES.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DDeath Messages'` | Configures the technical `DISPLAY-NAME` parameter for `SETTINGS-MENU.BUTTONS.DEATH_MESSAGES.DISPLAY-NAME` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.DEATH_MESSAGES.MATERIAL` | `str` | Any string text | `'SPRUCE_SIGN'` | Configures the technical `MATERIAL` parameter for `SETTINGS-MENU.BUTTONS.DEATH_MESSAGES.MATERIAL` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.DEATH_MESSAGES.SLOT` | `int` | Any valid integer number | `'4'` | Configures the technical `SLOT` parameter for `SETTINGS-MENU.BUTTONS.DEATH_MESSAGES.SLOT` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.DEATH_MESSAGES.LORE` | `list` | List of configured items/strings | `['&7Show death message notifications', '&fCurrently: {status}']` | Configures the technical `LORE` parameter for `SETTINGS-MENU.BUTTONS.DEATH_MESSAGES.LORE` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.ADVANCEMENT_MESSAGES.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DAdvancement Messages'` | Configures the technical `DISPLAY-NAME` parameter for `SETTINGS-MENU.BUTTONS.ADVANCEMENT_MESSAGES.DISPLAY-NAME` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.ADVANCEMENT_MESSAGES.MATERIAL` | `str` | Any string text | `'BIRCH_SIGN'` | Configures the technical `MATERIAL` parameter for `SETTINGS-MENU.BUTTONS.ADVANCEMENT_MESSAGES.MATERIAL` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.ADVANCEMENT_MESSAGES.SLOT` | `int` | Any valid integer number | `'5'` | Configures the technical `SLOT` parameter for `SETTINGS-MENU.BUTTONS.ADVANCEMENT_MESSAGES.SLOT` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.ADVANCEMENT_MESSAGES.LORE` | `list` | List of configured items/strings | `['&7Show advancement achievement notifications', '&fCurrently: {status}']` | Configures the technical `LORE` parameter for `SETTINGS-MENU.BUTTONS.ADVANCEMENT_MESSAGES.LORE` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.JOIN_LEAVE_MESSAGES.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DJoin/Leave Messages'` | Configures the technical `DISPLAY-NAME` parameter for `SETTINGS-MENU.BUTTONS.JOIN_LEAVE_MESSAGES.DISPLAY-NAME` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.JOIN_LEAVE_MESSAGES.MATERIAL` | `str` | Any string text | `'JUNGLE_SIGN'` | Configures the technical `MATERIAL` parameter for `SETTINGS-MENU.BUTTONS.JOIN_LEAVE_MESSAGES.MATERIAL` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.JOIN_LEAVE_MESSAGES.SLOT` | `int` | Any valid integer number | `'6'` | Configures the technical `SLOT` parameter for `SETTINGS-MENU.BUTTONS.JOIN_LEAVE_MESSAGES.SLOT` in `menus.yml`. |
| `SETTINGS-MENU.BUTTONS.JOIN_LEAVE_MESSAGES.LORE` | `list` | List of configured items/strings | `['&7Show join and leave notifications', '&fCurrently: {status}']` | Configures the technical `LORE` parameter for `SETTINGS-MENU.BUTTONS.JOIN_LEAVE_MESSAGES.LORE` in `menus.yml`. |
| *(152 additional sub-keys configured in section)* | | | | |

### 3. Practical Setup Example

```yaml
SETTINGS-MENU:
  TITLE: '&8Settings'
  SIZE: 54
  BUTTONS:
    # Buttons are grouped a row at a time: chat and messages on the first row,
    # alerts on the second, gameplay and display on the third, who may reach you on
    # the fourth, the scoreboard on the fifth, and the world around you on the last.
    # Every setting below accepts two optional keys:
    #   DEFAULT: <value>  Starting value for players who never touched the setting.
    #                     On/off buttons take true or false. The privacy buttons
    #                     (PRIVATE_MESSAGES, TPA_REQUESTS, TPA_HERE_REQUESTS, PAYMENTS)
    #                     take ANYONE, FRIENDS_FOLLOWED or OFF. DEATH_MESSAGES and
    #                     JOIN_LEAVE_MESSAGES are on or off: both feeds are server
    #                     wide, so those buttons only mute them.
    #                     true/false also work as shortcuts.
    #   ENABLED: false    Removes the option from /settings and pins every player to the
    #                     DEFAULT above. Use this instead of deleting the block - deleted
    #                     blocks are restored from the bundled defaults on the next start.
    # Example, hide advancement messages and keep them off for everyone:
    # ADVANCEMENT_MESSAGES:
    #   DEFAULT: OFF
    #   ENABLED: false
    # Custom redirect buttons can also be added here:
    # EXTERNAL_FLY:
    #   DISPLAY-NAME: '&bFlight Mode'
    #   MATERIAL: FEATHER
    #   SLOT: 25
    #   COMMAND: '[player] /fly'
    #   STATUS-PLACEHOLDER: '%cmi_user_flying%'
    #   LORE:
    #   - '&7Toggle flight via external plugin'
    #   - '&fCurrently: {status}'
    # Row 1 - chat and messages
    PUBLIC_CHAT:
      DISPLAY-NAME: '&#6BF18DPublic Chat'
      MATERIAL: OAK_SIGN
      SLOT: 0
      LORE:
      - '&7Receive public chat messages'
      - '&fCurrently: {status}'
    PRIVATE_MESSAGES:
      DISPLAY-NAME: '&#6BF18DPrivate Messages'
      MATERIAL: DARK_OAK_SIGN
      SLOT: 1
      LORE:
```

### 4. Per-Setting Defaults & Removing Options

Every entry under `SETTINGS-MENU.BUTTONS` accepts two optional keys on top of the display keys
documented above.

| Key | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `SETTINGS-MENU.BUTTONS.<SETTING>.DEFAULT` | `str` / `bool` | `true`, `false`, `ANYONE`, `FRIENDS_FOLLOWED`, `OFF` | Built-in default (`true` / `ANYONE` for most settings) | Value a player starts with before they ever open `/settings`. |
| `SETTINGS-MENU.BUTTONS.<SETTING>.ENABLED` | `bool` | `true`, `false` | `true` | `false` removes the option from `/settings` and pins every player to `DEFAULT`. |

**Which values a setting accepts.** On/off buttons take `true` or `false` (`on`/`off`, `yes`/`no`
and `enabled`/`disabled` are accepted too). The privacy buttons — `PRIVATE_MESSAGES`,
`TPA_REQUESTS`, `TPA_HERE_REQUESTS` and `PAYMENTS` — take `ANYONE`, `FRIENDS_FOLLOWED` or `OFF`,
where `true` is shorthand for `ANYONE` and `false` for `OFF`. `ADVANCEMENT_MESSAGES`,
`DEATH_MESSAGES` and `JOIN_LEAVE_MESSAGES` are plain on/off buttons: those feeds go to the whole
server, so the settings only mute them. `DISABLE_MOB_SPAWN`
and `DISABLE_PHANTOM_SPAWN` follow the button label, so `DEFAULT: true` means the prevention is
on and the mobs stop spawning. An unusable value is ignored and logged as a console warning.

**Turning a setting off for everyone.** `DEFAULT` alone only affects players who have never
touched that setting; existing players keep whatever they last chose. Pair it with
`ENABLED: false` to also pin players who already toggled it:

```yaml
SETTINGS-MENU:
  BUTTONS:
    ADVANCEMENT_MESSAGES:
      DEFAULT: OFF
      ENABLED: false
    JOIN_LEAVE_MESSAGES:
      DEFAULT: OFF
      ENABLED: false
```

Notes:

- Use `ENABLED: false` rather than deleting the block. Deleted blocks are restored from the
  bundled defaults the next time the plugin loads, which is also how new settings reach an
  existing `menus.yml`.
- While an option is disabled its `DEFAULT` is authoritative: the value is re-applied every time
  a player is loaded and on every `/uds reload`, and the button is neither drawn nor clickable.
  A player's stored choice is not deliberately rewritten, but routine data saves can overwrite
  it, so treat re-enabling an option as a reset for the players affected.
- `QUICK_AUCTION_PURCHASE` and `QUICK_AUCTION_SELL` are stored by the auction house instead of
  the player profile, so they support `ENABLED` but not `DEFAULT`.
- The bundled slots put one theme on each row and leave the rest of the row empty: chat and
  messages on the first, alerts on the second, gameplay and display on the third, who may reach
  you on the fourth, the scoreboard on the fifth, and the world around you on the last. Moving a
  button is only a matter of changing its `SLOT`, and the trailing gaps are there so a server can
  slot its own buttons into the row they belong to.
- `SCOREBOARD_VISIBILITY` hides the sidebar for that player. `SHOW_MONEY`, `SHOW_SHARDS`,
  `SHOW_KILLS`, `SHOW_DEATHS` and `SHOW_PLAYTIME` each hide one line of it, matched by the
  placeholder the line carries in `SCOREBOARD.LINES`. A server that does not want players hiding
  their statistics can drop the whole row with `ENABLED: false` on those five.
- `COMBAT_TIMER` hides the `COMBAT-MANAGER.ACTION-BAR` countdown. It only controls whether the
  countdown is drawn: a player who turns it off is still tagged, still has their commands blocked,
  and still dies on logout where `KILL-ON-LOGOUT` is on. Turning off `HOTBAR_MESSAGES` hides it as
  well, since the countdown goes out on the action bar like every other hotbar notification.
- Lunar teammates has no button. The setting still exists and still defaults to on, so the Apollo
  team markers keep working; there is simply no longer a way for a player to switch them off.
- A `menus.yml` written before the current grouping is backed up under `config-backups/` and
  regenerated on the next start, because merging bundled defaults never rewrites a `SLOT` that
  is already in the file.

### 5. Custom Feedback Messages & Fonts (`FEEDBACK`)

When players toggle a setting or cycle choices in `/settings`, the plugin sends chat feedback. The feedback templates, state texts, choice labels, and font styling can be configured globally under `SETTINGS-MENU.FEEDBACK` or customized per button.

#### Global Settings (`SETTINGS-MENU.FEEDBACK`)

```yaml
SETTINGS-MENU:
  FEEDBACK:
    TOGGLE-MESSAGE: '&7{setting} is now {state}&7.'
    CHOICE-MESSAGE: '&7{setting} is now set to {choice}&7.'
    STATE-ENABLED: '&aEnabled'
    STATE-DISABLED: '&cDisabled'
    CHOICE-OFF-TEXT: '&cOff'
    CHOICE-ANYONE-TEXT: '&aAnyone'
    CHOICE-FRIENDS-FOLLOWED-TEXT: '&dFriends/Followed'
```

#### Placeholders

| Placeholder | Description | Example |
| :--- | :--- | :--- |
| `{setting}` | Setting name (from `FEEDBACK-NAME`, customized stripped `DISPLAY-NAME`, or default label) | `Notification Sounds` or `ɴᴏᴛɪꜰɪᴄᴀᴛɪᴏɴ ꜱᴏᴜɴᴅꜱ` |
| `{setting_display}` | Raw `DISPLAY-NAME` of the button preserving color codes | `&#6BF18DNotification Sounds` |
| `{state}` | Current state or choice (`STATE-ENABLED`, `STATE-DISABLED`, or selected choice) | `&aEnabled` or `&aᴇɴᴀʙʟᴇᴅ` |
| `{status}` | Alias for `{state}` | `&aEnabled` |
| `{choice}` | Current choice text for three-choice settings | `&aAnyone` |

#### Per-Button Overrides

Individual buttons under `SETTINGS-MENU.BUTTONS` can define custom feedback names and messages:

```yaml
SETTINGS-MENU:
  BUTTONS:
    NOTIFICATION_SOUNDS:
      FEEDBACK-NAME: 'ɴᴏᴛɪꜰɪᴄᴀᴛɪᴏɴ ꜱᴏᴜɴᴅꜱ'
      FEEDBACK-MESSAGE: '&7{setting} is now {state}&7.'
```

- `FEEDBACK-NAME`: Custom label used for `{setting}` in chat feedback (useful for small caps or special font styling).
- `FEEDBACK-MESSAGE`: Overrides the global `TOGGLE-MESSAGE` or `CHOICE-MESSAGE` for this specific button. Setting it to `none` or `""` silences feedback for this button.
- **Customized `DISPLAY-NAME`**: If a button's `DISPLAY-NAME` is customized (e.g. `&aɴᴏᴛɪꜰɪᴄᴀᴛɪᴏɴ ꜱᴏᴜɴᴅꜱ`), the stripped display name is automatically used for `{setting}` without needing `FEEDBACK-NAME`.

---

## Section: `LEADERBOARDS-MENU`

### 1. Commented Setup Code Example

```yaml
LEADERBOARDS-MENU:
  TITLE: '&8Leaderboards'
  SIZE: 36
  TYPE-MENU:
    TITLE: '&8{type}'
    SIZE: 54
    BUTTON:
      MATERIAL: PLAYER_HEAD
      DISPLAY-NAME: '&#6BF18D{player}'
      LORE: '&f{type}: &7{value} &#6BF18D(#{position})'
  TYPE-NAMES:
    money: Money
    moneySpent: Money Spent
    moneyMade: Money Made
    kills: Kills
    deaths: Deaths
    playtime: Playtime
    blocksPlaced: Blocks Placed
    blocksBroken: Blocks Broken
    mobsKilled: Mobs Killed
    killStreak: Kill Streak
    highestKillStreak: Highest Kill Streak
    shards: Shards
    bounties: Bounties
  BUTTONS:
    MONEY:
      TYPE: money
      DISPLAY-NAME: '&#6BF18DMoney Leaderboard'
      MATERIAL: EMERALD
      SLOT: 10
      LORE:
      - '&fClick to view MONEY leaderboard'
    SHARDS:
      TYPE: shards
      DISPLAY-NAME: '&#6BF18DShards Leaderboard'
      MATERIAL: AMETHYST_SHARD
      SLOT: 11
      LORE:
      - '&fClick to view SHARDS leaderboard'
    KILLS:
      TYPE: kills
      DISPLAY-NAME: '&#6BF18DKills Leaderboard'
      MATERIAL: DIAMOND_SWORD
      SLOT: 12
      LORE:
      - '&fClick to view KILLS leaderboard'
    DEATHS:
      TYPE: deaths
      DISPLAY-NAME: '&#6BF18DDeaths Leaderboard'
      MATERIAL: SKELETON_SKULL
      SLOT: 13
      LORE:
      - '&fClick to view DEATHS leaderboard'
    PLAYTIME:
      TYPE: playtime
      DISPLAY-NAME: '&#6BF18DPlaytime Leaderboard'
      MATERIAL: CLOCK
      SLOT: 14
      LORE:
      - '&fClick to view PLAYTIME leaderboard'
    BLOCKS_PLACED:
      TYPE: blocksPlaced
      DISPLAY-NAME: '&#6BF18DBlocks Placed Leaderboard'
      MATERIAL: STONE
      SLOT: 15
      LORE:
      - '&fClick to view BLOCKS PLACED leaderboard'
    BLOCKS_BROKEN:
      TYPE: blocksBroken
      DISPLAY-NAME: '&#6BF18DBlocks Broken Leaderboard'
      MATERIAL: COBBLESTONE
      SLOT: 16
      LORE:
      - '&fClick to view BLOCKS BROKEN leaderboard'
    MOBS_KILLED:
      TYPE: mobsKilled
      DISPLAY-NAME: '&#6BF18DMobs Killed Leaderboard'
      MATERIAL: ZOMBIE_HEAD
      SLOT: 19
      LORE:
      - '&fClick to view MOBS KILLED leaderboard'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `LEADERBOARDS-MENU.TITLE` | `str` | Any string text | `'&8Leaderboards'` | Configures the technical `TITLE` parameter for `LEADERBOARDS-MENU.TITLE` in `menus.yml`. |
| `LEADERBOARDS-MENU.SIZE` | `int` | Any valid integer number | `'36'` | Configures the technical `SIZE` parameter for `LEADERBOARDS-MENU.SIZE` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-MENU.TITLE` | `str` | Any string text | `'&8{type}'` | Configures the technical `TITLE` parameter for `LEADERBOARDS-MENU.TYPE-MENU.TITLE` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-MENU.SIZE` | `int` | Any valid integer number | `'54'` | Configures the technical `SIZE` parameter for `LEADERBOARDS-MENU.TYPE-MENU.SIZE` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-MENU.BUTTON.MATERIAL` | `str` | Any string text | `'PLAYER_HEAD'` | Configures the technical `MATERIAL` parameter for `LEADERBOARDS-MENU.TYPE-MENU.BUTTON.MATERIAL` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-MENU.BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18D{player}'` | Configures the technical `DISPLAY-NAME` parameter for `LEADERBOARDS-MENU.TYPE-MENU.BUTTON.DISPLAY-NAME` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-MENU.BUTTON.LORE` | `str` | Any string text | `'&f{type}: &7{value} &#6BF18D(#{posi...'` | Configures the technical `LORE` parameter for `LEADERBOARDS-MENU.TYPE-MENU.BUTTON.LORE` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.money` | `str` | Any string text | `'Money'` | Configures the technical `money` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.money` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.moneySpent` | `str` | Any string text | `'Money Spent'` | Configures the technical `moneySpent` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.moneySpent` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.moneyMade` | `str` | Any string text | `'Money Made'` | Configures the technical `moneyMade` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.moneyMade` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.kills` | `str` | Any string text | `'Kills'` | Configures the technical `kills` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.kills` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.deaths` | `str` | Any string text | `'Deaths'` | Configures the technical `deaths` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.deaths` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.playtime` | `str` | Any string text | `'Playtime'` | Configures the technical `playtime` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.playtime` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.blocksPlaced` | `str` | Any string text | `'Blocks Placed'` | Configures the technical `blocksPlaced` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.blocksPlaced` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.blocksBroken` | `str` | Any string text | `'Blocks Broken'` | Configures the technical `blocksBroken` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.blocksBroken` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.mobsKilled` | `str` | Any string text | `'Mobs Killed'` | Configures the technical `mobsKilled` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.mobsKilled` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.killStreak` | `str` | Any string text | `'Kill Streak'` | Configures the technical `killStreak` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.killStreak` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.highestKillStreak` | `str` | Any string text | `'Highest Kill Streak'` | Configures the technical `highestKillStreak` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.highestKillStreak` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.shards` | `str` | Any string text | `'Shards'` | Configures the technical `shards` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.shards` in `menus.yml`. |
| `LEADERBOARDS-MENU.TYPE-NAMES.bounties` | `str` | Any string text | `'Bounties'` | Configures the technical `bounties` parameter for `LEADERBOARDS-MENU.TYPE-NAMES.bounties` in `menus.yml`. |
| `LEADERBOARDS-MENU.BUTTONS.MONEY.TYPE` | `str` | Any string text | `'money'` | Configures the technical `TYPE` parameter for `LEADERBOARDS-MENU.BUTTONS.MONEY.TYPE` in `menus.yml`. |
| `LEADERBOARDS-MENU.BUTTONS.MONEY.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DMoney Leaderboard'` | Configures the technical `DISPLAY-NAME` parameter for `LEADERBOARDS-MENU.BUTTONS.MONEY.DISPLAY-NAME` in `menus.yml`. |
| `LEADERBOARDS-MENU.BUTTONS.MONEY.MATERIAL` | `str` | Any string text | `'EMERALD'` | Configures the technical `MATERIAL` parameter for `LEADERBOARDS-MENU.BUTTONS.MONEY.MATERIAL` in `menus.yml`. |
| `LEADERBOARDS-MENU.BUTTONS.MONEY.SLOT` | `int` | Any valid integer number | `'10'` | Configures the technical `SLOT` parameter for `LEADERBOARDS-MENU.BUTTONS.MONEY.SLOT` in `menus.yml`. |
| `LEADERBOARDS-MENU.BUTTONS.MONEY.LORE` | `list` | List of configured items/strings | `['&fClick to view MONEY leaderboard']` | Configures the technical `LORE` parameter for `LEADERBOARDS-MENU.BUTTONS.MONEY.LORE` in `menus.yml`. |
| `LEADERBOARDS-MENU.BUTTONS.SHARDS.TYPE` | `str` | Any string text | `'shards'` | Configures the technical `TYPE` parameter for `LEADERBOARDS-MENU.BUTTONS.SHARDS.TYPE` in `menus.yml`. |
| `LEADERBOARDS-MENU.BUTTONS.SHARDS.DISPLAY-NAME` | `str` | Any string text | `'&#6BF18DShards Leaderboard'` | Configures the technical `DISPLAY-NAME` parameter for `LEADERBOARDS-MENU.BUTTONS.SHARDS.DISPLAY-NAME` in `menus.yml`. |
| `LEADERBOARDS-MENU.BUTTONS.SHARDS.MATERIAL` | `str` | Any string text | `'AMETHYST_SHARD'` | Configures the technical `MATERIAL` parameter for `LEADERBOARDS-MENU.BUTTONS.SHARDS.MATERIAL` in `menus.yml`. |
| `LEADERBOARDS-MENU.BUTTONS.SHARDS.SLOT` | `int` | Any valid integer number | `'11'` | Configures the technical `SLOT` parameter for `LEADERBOARDS-MENU.BUTTONS.SHARDS.SLOT` in `menus.yml`. |
| `LEADERBOARDS-MENU.BUTTONS.SHARDS.LORE` | `list` | List of configured items/strings | `['&fClick to view SHARDS leaderboard']` | Configures the technical `LORE` parameter for `LEADERBOARDS-MENU.BUTTONS.SHARDS.LORE` in `menus.yml`. |
| `LEADERBOARDS-MENU.BUTTONS.KILLS.TYPE` | `str` | Any string text | `'kills'` | Configures the technical `TYPE` parameter for `LEADERBOARDS-MENU.BUTTONS.KILLS.TYPE` in `menus.yml`. |
| *(54 additional sub-keys configured in section)* | | | | |

### 3. Practical Setup Example

```yaml
LEADERBOARDS-MENU:
  TITLE: '&8Leaderboards'
  SIZE: 36
  TYPE-MENU:
    TITLE: '&8{type}'
    SIZE: 54
    BUTTON:
      MATERIAL: PLAYER_HEAD
      DISPLAY-NAME: '&#6BF18D{player}'
      LORE: '&f{type}: &7{value} &#6BF18D(#{position})'
  TYPE-NAMES:
    money: Money
    moneySpent: Money Spent
    moneyMade: Money Made
    kills: Kills
    deaths: Deaths
    playtime: Playtime
    blocksPlaced: Blocks Placed
    blocksBroken: Blocks Broken
    mobsKilled: Mobs Killed
    killStreak: Kill Streak
    highestKillStreak: Highest Kill Streak
    shards: Shards
    bounties: Bounties
  BUTTONS:
    MONEY:
      TYPE: money
      DISPLAY-NAME: '&#6BF18DMoney Leaderboard'
      MATERIAL: EMERALD
      SLOT: 10
      LORE:
      - '&fClick to view MONEY leaderboard'
    SHARDS:
      TYPE: shards
      DISPLAY-NAME: '&#6BF18DShards Leaderboard'
      MATERIAL: AMETHYST_SHARD
      SLOT: 11
      LORE:
      - '&fClick to view SHARDS leaderboard'
    KILLS:
      TYPE: kills
      DISPLAY-NAME: '&#6BF18DKills Leaderboard'
      MATERIAL: DIAMOND_SWORD
      SLOT: 12
      LORE:
      - '&fClick to view KILLS leaderboard'
    DEATHS:
      TYPE: deaths
      DISPLAY-NAME: '&#6BF18DDeaths Leaderboard'
      MATERIAL: SKELETON_SKULL
      SLOT: 13
      LORE:
      - '&fClick to view DEATHS leaderboard'
    PLAYTIME:
      TYPE: playtime
      DISPLAY-NAME: '&#6BF18DPlaytime Leaderboard'
      MATERIAL: CLOCK
      SLOT: 14
      LORE:
      - '&fClick to view PLAYTIME leaderboard'
    BLOCKS_PLACED:
      TYPE: blocksPlaced
      DISPLAY-NAME: '&#6BF18DBlocks Placed Leaderboard'
      MATERIAL: STONE
      SLOT: 15
      LORE:
      - '&fClick to view BLOCKS PLACED leaderboard'
    BLOCKS_BROKEN:
      TYPE: blocksBroken
      DISPLAY-NAME: '&#6BF18DBlocks Broken Leaderboard'
      MATERIAL: COBBLESTONE
      SLOT: 16
      LORE:
      - '&fClick to view BLOCKS BROKEN leaderboard'
    MOBS_KILLED:
      TYPE: mobsKilled
      DISPLAY-NAME: '&#6BF18DMobs Killed Leaderboard'
      MATERIAL: ZOMBIE_HEAD
      SLOT: 19
      LORE:
      - '&fClick to view MOBS KILLED leaderboard'
```

---

## Section: `PROGRESS-MENU`

### 1. Commented Setup Code Example

```yaml
PROGRESS-MENU:
  PROGRESS-BAR: "■"
  LEVEL:
  - 25000
  - 150000
  - 500000
  - 1000000
  - 5000000
  - 25000000
  - 250000000
  - 550000000
  - 850000000
  - 1000000000
  - 2000000000
  - 4000000000
  - 8000000000
  - 10000000000
  - 20000000000
  - 40000000000
  - 80000000000
  - 160000000000
  - 320000000000
  - 640000000000
  TITLE:
    CROPS: '&8CROPS PROGRESS'
    ORES: '&8ORE PROGRESS'
    MOBS: '&8MOB DROPS PROGRESS'
    NATURAL: '&8NATURAL ITEMS PROGRESS'
    ARMOR_AND_TOOLS: '&8ARMOR AND TOOLS PROGRESS'
    FISH: '&8FISH PROGRESS'
    BOOK: '&8ENCHANTED BOOK PROGRESS'
    POTIONS: '&8POTIONS PROGRESS'
    BLOCKS: '&8BLOCKS PROGRESS'
  TYPE-BUTTON:
    TITLE:
      CROPS: '&#6BF18DCROPS'
      ORES: '&#6BF18DORE'
      MOBS: '&#6BF18DMOB'
      NATURAL: '&#6BF18DNATURAL ITEMS'
      ARMOR_AND_TOOLS: '&#6BF18DARMOR AND TOOLS'
      FISH: '&#6BF18DFISH'
      BOOK: '&#6BF18DENCHANTED BOOK'
      POTIONS: '&#6BF18DPOTIONS'
      BLOCKS: '&#6BF18DBLOCKS'
    LORE:
      CROPS:
      - '&7Sell crops and farming materials to'
      - '&7upgrade your sell multiplier!'
      ORES:
      - '&7Sell ores and mining materials to'
      - '&7upgrade your sell multiplier!'
      MOBS:
      - '&7Sell mob drops and combat materials to'
      - '&7upgrade your sell multiplier!'
      NATURAL:
      - '&7Sell natural materials and trees to'
      - '&7upgrade your sell multiplier!'
      ARMOR_AND_TOOLS:
      - '&7Sell armor and tools to'
      - '&7upgrade your sell multiplier!'
      FISH:
      - '&7Sell fish and other fishing loot to'
      - '&7upgrade your sell multiplier!'
      BOOK:
      - '&7Sell books and enchanted books to'
      - '&7upgrade your sell multiplier!'
      POTIONS:
      - '&7Sell potions and brewing materials to'
      - '&7upgrade your sell multiplier!'
      BLOCKS:
      - '&7Sell blocks and placeable items to'
      - '&7upgrade your sell multiplier!'
    MATERIAL:
      CROPS: WHEAT
      ORES: DIAMOND
      MOBS: BONE
      NATURAL: OAK_LEAVES
      ARMOR_AND_TOOLS: NETHERITE_HELMET
      FISH: TROPICAL_FISH
      BOOK: BOOK
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `PROGRESS-MENU.PROGRESS-BAR` | `str` | Any string text | `'■'` | Configures the technical `PROGRESS-BAR` parameter for `PROGRESS-MENU.PROGRESS-BAR` in `menus.yml`. |
| `PROGRESS-MENU.LEVEL` | `list` | List of configured items/strings | `[25000, 150000, 500000...]` | Configures the technical `LEVEL` parameter for `PROGRESS-MENU.LEVEL` in `menus.yml`. |
| `PROGRESS-MENU.TITLE.CROPS` | `str` | Any string text | `'&8CROPS PROGRESS'` | Configures the technical `CROPS` parameter for `PROGRESS-MENU.TITLE.CROPS` in `menus.yml`. |
| `PROGRESS-MENU.TITLE.ORES` | `str` | Any string text | `'&8ORE PROGRESS'` | Configures the technical `ORES` parameter for `PROGRESS-MENU.TITLE.ORES` in `menus.yml`. |
| `PROGRESS-MENU.TITLE.MOBS` | `str` | Any string text | `'&8MOB DROPS PROGRESS'` | Configures the technical `MOBS` parameter for `PROGRESS-MENU.TITLE.MOBS` in `menus.yml`. |
| `PROGRESS-MENU.TITLE.NATURAL` | `str` | Any string text | `'&8NATURAL ITEMS PROGRESS'` | Configures the technical `NATURAL` parameter for `PROGRESS-MENU.TITLE.NATURAL` in `menus.yml`. |
| `PROGRESS-MENU.TITLE.ARMOR_AND_TOOLS` | `str` | Any string text | `'&8ARMOR AND TOOLS PROGRESS'` | Configures the technical `ARMOR_AND_TOOLS` parameter for `PROGRESS-MENU.TITLE.ARMOR_AND_TOOLS` in `menus.yml`. |
| `PROGRESS-MENU.TITLE.FISH` | `str` | Any string text | `'&8FISH PROGRESS'` | Configures the technical `FISH` parameter for `PROGRESS-MENU.TITLE.FISH` in `menus.yml`. |
| `PROGRESS-MENU.TITLE.BOOK` | `str` | Any string text | `'&8ENCHANTED BOOK PROGRESS'` | Configures the technical `BOOK` parameter for `PROGRESS-MENU.TITLE.BOOK` in `menus.yml`. |
| `PROGRESS-MENU.TITLE.POTIONS` | `str` | Any string text | `'&8POTIONS PROGRESS'` | Configures the technical `POTIONS` parameter for `PROGRESS-MENU.TITLE.POTIONS` in `menus.yml`. |
| `PROGRESS-MENU.TITLE.BLOCKS` | `str` | Any string text | `'&8BLOCKS PROGRESS'` | Configures the technical `BLOCKS` parameter for `PROGRESS-MENU.TITLE.BLOCKS` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.TITLE.CROPS` | `str` | Any string text | `'&#6BF18DCROPS'` | Configures the technical `CROPS` parameter for `PROGRESS-MENU.TYPE-BUTTON.TITLE.CROPS` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.TITLE.ORES` | `str` | Any string text | `'&#6BF18DORE'` | Configures the technical `ORES` parameter for `PROGRESS-MENU.TYPE-BUTTON.TITLE.ORES` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.TITLE.MOBS` | `str` | Any string text | `'&#6BF18DMOB'` | Configures the technical `MOBS` parameter for `PROGRESS-MENU.TYPE-BUTTON.TITLE.MOBS` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.TITLE.NATURAL` | `str` | Any string text | `'&#6BF18DNATURAL ITEMS'` | Configures the technical `NATURAL` parameter for `PROGRESS-MENU.TYPE-BUTTON.TITLE.NATURAL` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.TITLE.ARMOR_AND_TOOLS` | `str` | Any string text | `'&#6BF18DARMOR AND TOOLS'` | Configures the technical `ARMOR_AND_TOOLS` parameter for `PROGRESS-MENU.TYPE-BUTTON.TITLE.ARMOR_AND_TOOLS` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.TITLE.FISH` | `str` | Any string text | `'&#6BF18DFISH'` | Configures the technical `FISH` parameter for `PROGRESS-MENU.TYPE-BUTTON.TITLE.FISH` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.TITLE.BOOK` | `str` | Any string text | `'&#6BF18DENCHANTED BOOK'` | Configures the technical `BOOK` parameter for `PROGRESS-MENU.TYPE-BUTTON.TITLE.BOOK` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.TITLE.POTIONS` | `str` | Any string text | `'&#6BF18DPOTIONS'` | Configures the technical `POTIONS` parameter for `PROGRESS-MENU.TYPE-BUTTON.TITLE.POTIONS` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.TITLE.BLOCKS` | `str` | Any string text | `'&#6BF18DBLOCKS'` | Configures the technical `BLOCKS` parameter for `PROGRESS-MENU.TYPE-BUTTON.TITLE.BLOCKS` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.LORE.CROPS` | `list` | List of configured items/strings | `['&7Sell crops and farming materials to', '&7upgrade your sell multiplier!']` | Configures the technical `CROPS` parameter for `PROGRESS-MENU.TYPE-BUTTON.LORE.CROPS` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.LORE.ORES` | `list` | List of configured items/strings | `['&7Sell ores and mining materials to', '&7upgrade your sell multiplier!']` | Configures the technical `ORES` parameter for `PROGRESS-MENU.TYPE-BUTTON.LORE.ORES` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.LORE.MOBS` | `list` | List of configured items/strings | `['&7Sell mob drops and combat materials to', '&7upgrade your sell multiplier!']` | Configures the technical `MOBS` parameter for `PROGRESS-MENU.TYPE-BUTTON.LORE.MOBS` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.LORE.NATURAL` | `list` | List of configured items/strings | `['&7Sell natural materials and trees to', '&7upgrade your sell multiplier!']` | Configures the technical `NATURAL` parameter for `PROGRESS-MENU.TYPE-BUTTON.LORE.NATURAL` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.LORE.ARMOR_AND_TOOLS` | `list` | List of configured items/strings | `['&7Sell armor and tools to', '&7upgrade your sell multiplier!']` | Configures the technical `ARMOR_AND_TOOLS` parameter for `PROGRESS-MENU.TYPE-BUTTON.LORE.ARMOR_AND_TOOLS` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.LORE.FISH` | `list` | List of configured items/strings | `['&7Sell fish and other fishing loot to', '&7upgrade your sell multiplier!']` | Configures the technical `FISH` parameter for `PROGRESS-MENU.TYPE-BUTTON.LORE.FISH` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.LORE.BOOK` | `list` | List of configured items/strings | `['&7Sell books and enchanted books to', '&7upgrade your sell multiplier!']` | Configures the technical `BOOK` parameter for `PROGRESS-MENU.TYPE-BUTTON.LORE.BOOK` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.LORE.POTIONS` | `list` | List of configured items/strings | `['&7Sell potions and brewing materials to', '&7upgrade your sell multiplier!']` | Configures the technical `POTIONS` parameter for `PROGRESS-MENU.TYPE-BUTTON.LORE.POTIONS` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.LORE.BLOCKS` | `list` | List of configured items/strings | `['&7Sell blocks and placeable items to', '&7upgrade your sell multiplier!']` | Configures the technical `BLOCKS` parameter for `PROGRESS-MENU.TYPE-BUTTON.LORE.BLOCKS` in `menus.yml`. |
| `PROGRESS-MENU.TYPE-BUTTON.MATERIAL.CROPS` | `str` | Any string text | `'WHEAT'` | Configures the technical `CROPS` parameter for `PROGRESS-MENU.TYPE-BUTTON.MATERIAL.CROPS` in `menus.yml`. |
| *(14 additional sub-keys configured in section)* | | | | |

### 3. Practical Setup Example

```yaml
PROGRESS-MENU:
  PROGRESS-BAR: "■"
  LEVEL:
  - 25000
  - 150000
  - 500000
  - 1000000
  - 5000000
  - 25000000
  - 250000000
  - 550000000
  - 850000000
  - 1000000000
  - 2000000000
  - 4000000000
  - 8000000000
  - 10000000000
  - 20000000000
  - 40000000000
  - 80000000000
  - 160000000000
  - 320000000000
  - 640000000000
  TITLE:
    CROPS: '&8CROPS PROGRESS'
    ORES: '&8ORE PROGRESS'
    MOBS: '&8MOB DROPS PROGRESS'
    NATURAL: '&8NATURAL ITEMS PROGRESS'
    ARMOR_AND_TOOLS: '&8ARMOR AND TOOLS PROGRESS'
    FISH: '&8FISH PROGRESS'
    BOOK: '&8ENCHANTED BOOK PROGRESS'
    POTIONS: '&8POTIONS PROGRESS'
    BLOCKS: '&8BLOCKS PROGRESS'
  TYPE-BUTTON:
    TITLE:
      CROPS: '&#6BF18DCROPS'
      ORES: '&#6BF18DORE'
      MOBS: '&#6BF18DMOB'
      NATURAL: '&#6BF18DNATURAL ITEMS'
      ARMOR_AND_TOOLS: '&#6BF18DARMOR AND TOOLS'
      FISH: '&#6BF18DFISH'
      BOOK: '&#6BF18DENCHANTED BOOK'
      POTIONS: '&#6BF18DPOTIONS'
      BLOCKS: '&#6BF18DBLOCKS'
    LORE:
      CROPS:
      - '&7Sell crops and farming materials to'
      - '&7upgrade your sell multiplier!'
      ORES:
      - '&7Sell ores and mining materials to'
      - '&7upgrade your sell multiplier!'
      MOBS:
      - '&7Sell mob drops and combat materials to'
      - '&7upgrade your sell multiplier!'
      NATURAL:
      - '&7Sell natural materials and trees to'
      - '&7upgrade your sell multiplier!'
      ARMOR_AND_TOOLS:
      - '&7Sell armor and tools to'
      - '&7upgrade your sell multiplier!'
      FISH:
      - '&7Sell fish and other fishing loot to'
      - '&7upgrade your sell multiplier!'
      BOOK:
      - '&7Sell books and enchanted books to'
      - '&7upgrade your sell multiplier!'
      POTIONS:
      - '&7Sell potions and brewing materials to'
      - '&7upgrade your sell multiplier!'
      BLOCKS:
      - '&7Sell blocks and placeable items to'
      - '&7upgrade your sell multiplier!'
    MATERIAL:
      CROPS: WHEAT
      ORES: DIAMOND
      MOBS: BONE
      NATURAL: OAK_LEAVES
      ARMOR_AND_TOOLS: NETHERITE_HELMET
      FISH: TROPICAL_FISH
      BOOK: BOOK
```

---

## Section: `SELL-MENU`

### 1. Commented Setup Code Example

```yaml
SELL-MENU:
  TITLE: '&8Place Items In Here To Sell'
  MULTIPLIER-TITLE: '&8Sell Multipliers'
  AUTO-SELL: true
  MODE: 'confirm'
  CONFIRM-BUTTON:
    MATERIAL: LIME_STAINED_GLASS_PANE
    TITLE: '&a&lConfirm Sell'
    LORE:
    - '&a{price_formatted}'
  CROPS-BUTTON:
    MATERIAL: WHEAT
    TITLE: '&#6BF18DCrops'
    LORE:
    - '&7Sell crops and farming materials to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  ORES-BUTTON:
    MATERIAL: DIAMOND
    TITLE: '&#6BF18DOres'
    LORE:
    - '&7Sell ores and mining materials to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  MOBS-BUTTON:
    MATERIAL: BONE
    TITLE: '&#6BF18DMobs'
    LORE:
    - '&7Sell mob drops and combat materials to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  NATURAL-BUTTON:
    MATERIAL: OAK_LEAVES
    TITLE: '&#6BF18DNatural Items'
    LORE:
    - '&7Sell natural materials and trees to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  ARMOR-AND-TOOLS-BUTTON:
    MATERIAL: NETHERITE_HELMET
    TITLE: '&#6BF18DArmor And Tools'
    LORE:
    - '&7Sell armor and tools to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  FISH-BUTTON:
    MATERIAL: TROPICAL_FISH
    TITLE: '&#6BF18DFish'
    LORE:
    - '&7Sell fish and other fishing loot to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  BOOK-BUTTON:
    MATERIAL: BOOK
    TITLE: '&#6BF18DEnchanted Book'
    LORE:
    - '&7Sell books and enchanted books to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  POTIONS-BUTTON:
    MATERIAL: BREWING_STAND
    TITLE: '&#6BF18DPotions'
    LORE:
    - '&7Sell potions and brewing materials to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  BLOCKS-BUTTON:
    MATERIAL: BRICK
    TITLE: '&#6BF18DBlocks'
    LORE:
    - '&7Sell blocks and placeable items to'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `SELL-MENU.TITLE` | `str` | Any string text | `'&8Place Items In Here To Sell'` | Configures the technical `TITLE` parameter for `SELL-MENU.TITLE` in `menus.yml`. |
| `SELL-MENU.MULTIPLIER-TITLE` | `str` | Any string text | `'&8Sell Multipliers'` | Configures the technical `MULTIPLIER-TITLE` parameter for `SELL-MENU.MULTIPLIER-TITLE` in `menus.yml`. |
| `SELL-MENU.MODE` | `str` | `confirm`, `close`, `instant` | `'confirm'` | Decides when the menu takes payment. `confirm` shows the Confirm Sell button and gives items back if the player closes without clicking it. `close` sells the whole grid the moment the menu is shut. `instant` pays out item by item as things land, and still settles whatever is left on close. An unrecognised value falls back to `instant`. |
| `SELL-MENU.AUTO-SELL` | `bool` | `true`, `false` | `true` | Only applies to `MODE: instant`. Leave it `true` for the item-by-item payout as things land in the grid; set it `false` and instant mode holds everything until the player shuts the menu, the same as `MODE: close`. Both `confirm` and `close` ignore it. |
| `SELL-MENU.CONFIRM-BUTTON.MATERIAL` | `str` | Any string text | `'LIME_STAINED_GLASS_PANE'` | Item used for the Confirm Sell button in `MODE: confirm`. |
| `SELL-MENU.CONFIRM-BUTTON.TITLE` | `str` | Any string text | `'&a&lConfirm Sell'` | Name of the Confirm Sell button. `{price}` is the compact total of what is in the grid, `{price_formatted}` is the full money format. |
| `SELL-MENU.CONFIRM-BUTTON.LORE` | `list` | List of configured items/strings | `['&a{price_formatted}']` | Lore under the Confirm Sell button. It is rewritten as items are added or taken out, using the same `{price}` and `{price_formatted}` placeholders as the title. The total includes sell multipliers. |
| `SELL-MENU.CROPS-BUTTON.MATERIAL` | `str` | Any string text | `'WHEAT'` | Configures the technical `MATERIAL` parameter for `SELL-MENU.CROPS-BUTTON.MATERIAL` in `menus.yml`. |
| `SELL-MENU.CROPS-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DCrops'` | Configures the technical `TITLE` parameter for `SELL-MENU.CROPS-BUTTON.TITLE` in `menus.yml`. |
| `SELL-MENU.CROPS-BUTTON.LORE` | `list` | List of configured items/strings | `[&7Sell crops and farming materials to, &7upgrade your sell multiplier!, ...]` | Configures the technical `LORE` parameter for `SELL-MENU.CROPS-BUTTON.LORE` in `menus.yml`. |
| `SELL-MENU.ORES-BUTTON.MATERIAL` | `str` | Any string text | `'DIAMOND'` | Configures the technical `MATERIAL` parameter for `SELL-MENU.ORES-BUTTON.MATERIAL` in `menus.yml`. |
| `SELL-MENU.ORES-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DOres'` | Configures the technical `TITLE` parameter for `SELL-MENU.ORES-BUTTON.TITLE` in `menus.yml`. |
| `SELL-MENU.ORES-BUTTON.LORE` | `list` | List of configured items/strings | `[&7Sell ores and mining materials to, &7upgrade your sell multiplier!, ...]` | Configures the technical `LORE` parameter for `SELL-MENU.ORES-BUTTON.LORE` in `menus.yml`. |
| `SELL-MENU.MOBS-BUTTON.MATERIAL` | `str` | Any string text | `'BONE'` | Configures the technical `MATERIAL` parameter for `SELL-MENU.MOBS-BUTTON.MATERIAL` in `menus.yml`. |
| `SELL-MENU.MOBS-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DMobs'` | Configures the technical `TITLE` parameter for `SELL-MENU.MOBS-BUTTON.TITLE` in `menus.yml`. |
| `SELL-MENU.MOBS-BUTTON.LORE` | `list` | List of configured items/strings | `[&7Sell mob drops and combat materials to, &7upgrade your sell multiplier!, ...]` | Configures the technical `LORE` parameter for `SELL-MENU.MOBS-BUTTON.LORE` in `menus.yml`. |
| `SELL-MENU.NATURAL-BUTTON.MATERIAL` | `str` | Any string text | `'OAK_LEAVES'` | Configures the technical `MATERIAL` parameter for `SELL-MENU.NATURAL-BUTTON.MATERIAL` in `menus.yml`. |
| `SELL-MENU.NATURAL-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DNatural Items'` | Configures the technical `TITLE` parameter for `SELL-MENU.NATURAL-BUTTON.TITLE` in `menus.yml`. |
| `SELL-MENU.NATURAL-BUTTON.LORE` | `list` | List of configured items/strings | `[&7Sell natural materials and trees to, &7upgrade your sell multiplier!, ...]` | Configures the technical `LORE` parameter for `SELL-MENU.NATURAL-BUTTON.LORE` in `menus.yml`. |
| `SELL-MENU.ARMOR-AND-TOOLS-BUTTON.MATERIAL` | `str` | Any string text | `'NETHERITE_HELMET'` | Configures the technical `MATERIAL` parameter for `SELL-MENU.ARMOR-AND-TOOLS-BUTTON.MATERIAL` in `menus.yml`. |
| `SELL-MENU.ARMOR-AND-TOOLS-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DArmor And Tools'` | Configures the technical `TITLE` parameter for `SELL-MENU.ARMOR-AND-TOOLS-BUTTON.TITLE` in `menus.yml`. |
| `SELL-MENU.ARMOR-AND-TOOLS-BUTTON.LORE` | `list` | List of configured items/strings | `[&7Sell armor and tools to, &7upgrade your sell multiplier!, ...]` | Configures the technical `LORE` parameter for `SELL-MENU.ARMOR-AND-TOOLS-BUTTON.LORE` in `menus.yml`. |
| `SELL-MENU.FISH-BUTTON.MATERIAL` | `str` | Any string text | `'TROPICAL_FISH'` | Configures the technical `MATERIAL` parameter for `SELL-MENU.FISH-BUTTON.MATERIAL` in `menus.yml`. |
| `SELL-MENU.FISH-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DFish'` | Configures the technical `TITLE` parameter for `SELL-MENU.FISH-BUTTON.TITLE` in `menus.yml`. |
| `SELL-MENU.FISH-BUTTON.LORE` | `list` | List of configured items/strings | `[&7Sell fish and other fishing loot to, &7upgrade your sell multiplier!, ...]` | Configures the technical `LORE` parameter for `SELL-MENU.FISH-BUTTON.LORE` in `menus.yml`. |
| `SELL-MENU.BOOK-BUTTON.MATERIAL` | `str` | Any string text | `'BOOK'` | Configures the technical `MATERIAL` parameter for `SELL-MENU.BOOK-BUTTON.MATERIAL` in `menus.yml`. |
| `SELL-MENU.BOOK-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DEnchanted Book'` | Configures the technical `TITLE` parameter for `SELL-MENU.BOOK-BUTTON.TITLE` in `menus.yml`. |
| `SELL-MENU.BOOK-BUTTON.LORE` | `list` | List of configured items/strings | `[&7Sell books and enchanted books to, &7upgrade your sell multiplier!, ...]` | Configures the technical `LORE` parameter for `SELL-MENU.BOOK-BUTTON.LORE` in `menus.yml`. |
| `SELL-MENU.POTIONS-BUTTON.MATERIAL` | `str` | Any string text | `'BREWING_STAND'` | Configures the technical `MATERIAL` parameter for `SELL-MENU.POTIONS-BUTTON.MATERIAL` in `menus.yml`. |
| `SELL-MENU.POTIONS-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DPotions'` | Configures the technical `TITLE` parameter for `SELL-MENU.POTIONS-BUTTON.TITLE` in `menus.yml`. |
| `SELL-MENU.POTIONS-BUTTON.LORE` | `list` | List of configured items/strings | `[&7Sell potions and brewing materials to, &7upgrade your sell multiplier!, ...]` | Configures the technical `LORE` parameter for `SELL-MENU.POTIONS-BUTTON.LORE` in `menus.yml`. |
| `SELL-MENU.BLOCKS-BUTTON.MATERIAL` | `str` | Any string text | `'BRICK'` | Configures the technical `MATERIAL` parameter for `SELL-MENU.BLOCKS-BUTTON.MATERIAL` in `menus.yml`. |
| `SELL-MENU.BLOCKS-BUTTON.TITLE` | `str` | Any string text | `'&#6BF18DBlocks'` | Configures the technical `TITLE` parameter for `SELL-MENU.BLOCKS-BUTTON.TITLE` in `menus.yml`. |
| `SELL-MENU.BLOCKS-BUTTON.LORE` | `list` | List of configured items/strings | `[&7Sell blocks and placeable items to, &7upgrade your sell multiplier!, ...]` | Configures the technical `LORE` parameter for `SELL-MENU.BLOCKS-BUTTON.LORE` in `menus.yml`. |

### 3. Practical Setup Example

```yaml
SELL-MENU:
  TITLE: '&8Place Items In Here To Sell'
  MULTIPLIER-TITLE: '&8Sell Multipliers'
  AUTO-SELL: true
  MODE: 'confirm'
  CONFIRM-BUTTON:
    MATERIAL: LIME_STAINED_GLASS_PANE
    TITLE: '&a&lConfirm Sell'
    LORE:
    - '&a{price_formatted}'
  CROPS-BUTTON:
    MATERIAL: WHEAT
    TITLE: '&#6BF18DCrops'
    LORE:
    - '&7Sell crops and farming materials to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  ORES-BUTTON:
    MATERIAL: DIAMOND
    TITLE: '&#6BF18DOres'
    LORE:
    - '&7Sell ores and mining materials to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  MOBS-BUTTON:
    MATERIAL: BONE
    TITLE: '&#6BF18DMobs'
    LORE:
    - '&7Sell mob drops and combat materials to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  NATURAL-BUTTON:
    MATERIAL: OAK_LEAVES
    TITLE: '&#6BF18DNatural Items'
    LORE:
    - '&7Sell natural materials and trees to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  ARMOR-AND-TOOLS-BUTTON:
    MATERIAL: NETHERITE_HELMET
    TITLE: '&#6BF18DArmor And Tools'
    LORE:
    - '&7Sell armor and tools to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  FISH-BUTTON:
    MATERIAL: TROPICAL_FISH
    TITLE: '&#6BF18DFish'
    LORE:
    - '&7Sell fish and other fishing loot to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  BOOK-BUTTON:
    MATERIAL: BOOK
    TITLE: '&#6BF18DEnchanted Book'
    LORE:
    - '&7Sell books and enchanted books to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  POTIONS-BUTTON:
    MATERIAL: BREWING_STAND
    TITLE: '&#6BF18DPotions'
    LORE:
    - '&7Sell potions and brewing materials to'
    - '&7upgrade your sell multiplier!'
    - ''
    - '&7Progress to &f{next_multiplier}'
    - '{porcentage_level} &#6BF18D{porcentage}%'
  BLOCKS-BUTTON:
    MATERIAL: BRICK
    TITLE: '&#6BF18DBlocks'
    LORE:
    - '&7Sell blocks and placeable items to'
```

---

## Section: `WORTH-MENU`

### 1. Commented Setup Code Example

```yaml
WORTH-MENU:
  TITLE: '&8Item Prices'
  FORMAT: '&7Worth: &a${price}'
  SORT-BUTTON:
    TITLE: '&aSort'
    MATERIAL: CAULDRON
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `WORTH-MENU.TITLE` | `str` | Any string text | `'&8Item Prices'` | Configures the technical `TITLE` parameter for `WORTH-MENU.TITLE` in `menus.yml`. |
| `WORTH-MENU.FORMAT` | `str` | Any string text | `'&7Worth: &a${price}'` | Configures the technical `FORMAT` parameter for `WORTH-MENU.FORMAT` in `menus.yml`. |
| `WORTH-MENU.SORT-BUTTON.TITLE` | `str` | Any string text | `'&aSort'` | Configures the technical `TITLE` parameter for `WORTH-MENU.SORT-BUTTON.TITLE` in `menus.yml`. |
| `WORTH-MENU.SORT-BUTTON.MATERIAL` | `str` | Any string text | `'CAULDRON'` | Configures the technical `MATERIAL` parameter for `WORTH-MENU.SORT-BUTTON.MATERIAL` in `menus.yml`. |

### 3. Practical Setup Example

```yaml
WORTH-MENU:
  TITLE: '&8Item Prices'
  FORMAT: '&7Worth: &a${price}'
  SORT-BUTTON:
    TITLE: '&aSort'
    MATERIAL: CAULDRON
```

---

## Section: `TPA-CONFIRM-MENU`

### 1. Commented Setup Code Example

```yaml
TPA-CONFIRM-MENU:
  TITLE: '&8Confirm TPA {here}'
  SIZE: 27
  BUTTONS:
    CANCEL:
      MATERIAL: RED_STAINED_GLASS_PANE
      NAME: '&cCancel'
      LORE:
      - '&fCLICK TO CANCEL'
    CONFIRM:
      MATERIAL: LIME_STAINED_GLASS_PANE
      NAME: '&aConfirm'
      LORE:
      - '&fCLICK TO CONFIRM'
    PLAYER:
      MATERIAL: PLAYER_HEAD
      NAME: '&#00FC00Player'
      LORE:
      - '&7{player}'
    LOCATION:
      NAME: '&#6BF18DLocation'
      MATERIAL: GRASS_BLOCK
      LORE:
      - '&7{world}'
    REGION:
      NAME: '&#6BF18DRegion'
      MATERIAL: FEATHER
      LORE:
      - '&7NA East (&#0069D6${ping}ms&7)'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `TPA-CONFIRM-MENU.TITLE` | `str` | Any string text | `'&8Confirm TPA {here}'` | Configures the technical `TITLE` parameter for `TPA-CONFIRM-MENU.TITLE` in `menus.yml`. |
| `TPA-CONFIRM-MENU.SIZE` | `int` | Any valid integer number | `'27'` | Configures the technical `SIZE` parameter for `TPA-CONFIRM-MENU.SIZE` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.CANCEL.MATERIAL` | `str` | Any string text | `'RED_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `TPA-CONFIRM-MENU.BUTTONS.CANCEL.MATERIAL` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.CANCEL.NAME` | `str` | Any string text | `'&cCancel'` | Configures the technical `NAME` parameter for `TPA-CONFIRM-MENU.BUTTONS.CANCEL.NAME` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.CANCEL.LORE` | `list` | List of configured items/strings | `['&fCLICK TO CANCEL']` | Configures the technical `LORE` parameter for `TPA-CONFIRM-MENU.BUTTONS.CANCEL.LORE` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.CONFIRM.MATERIAL` | `str` | Any string text | `'LIME_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `TPA-CONFIRM-MENU.BUTTONS.CONFIRM.MATERIAL` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.CONFIRM.NAME` | `str` | Any string text | `'&aConfirm'` | Configures the technical `NAME` parameter for `TPA-CONFIRM-MENU.BUTTONS.CONFIRM.NAME` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.CONFIRM.LORE` | `list` | List of configured items/strings | `['&fCLICK TO CONFIRM']` | Configures the technical `LORE` parameter for `TPA-CONFIRM-MENU.BUTTONS.CONFIRM.LORE` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.PLAYER.MATERIAL` | `str` | Any string text | `'PLAYER_HEAD'` | Configures the technical `MATERIAL` parameter for `TPA-CONFIRM-MENU.BUTTONS.PLAYER.MATERIAL` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.PLAYER.NAME` | `str` | Any string text | `'&#00FC00Player'` | Configures the technical `NAME` parameter for `TPA-CONFIRM-MENU.BUTTONS.PLAYER.NAME` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.PLAYER.LORE` | `list` | List of configured items/strings | `['&7{player}']` | Configures the technical `LORE` parameter for `TPA-CONFIRM-MENU.BUTTONS.PLAYER.LORE` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.LOCATION.NAME` | `str` | Any string text | `'&#6BF18DLocation'` | Configures the technical `NAME` parameter for `TPA-CONFIRM-MENU.BUTTONS.LOCATION.NAME` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.LOCATION.MATERIAL` | `str` | Any string text | `'GRASS_BLOCK'` | Configures the technical `MATERIAL` parameter for `TPA-CONFIRM-MENU.BUTTONS.LOCATION.MATERIAL` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.LOCATION.LORE` | `list` | List of configured items/strings | `['&7{world}']` | Configures the technical `LORE` parameter for `TPA-CONFIRM-MENU.BUTTONS.LOCATION.LORE` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.REGION.NAME` | `str` | Any string text | `'&#6BF18DRegion'` | Configures the technical `NAME` parameter for `TPA-CONFIRM-MENU.BUTTONS.REGION.NAME` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.REGION.MATERIAL` | `str` | Any string text | `'FEATHER'` | Configures the technical `MATERIAL` parameter for `TPA-CONFIRM-MENU.BUTTONS.REGION.MATERIAL` in `menus.yml`. |
| `TPA-CONFIRM-MENU.BUTTONS.REGION.LORE` | `list` | List of configured items/strings | `['&7NA East (&#0069D6${ping}ms&7)']` | Configures the technical `LORE` parameter for `TPA-CONFIRM-MENU.BUTTONS.REGION.LORE` in `menus.yml`. |

### 3. Practical Setup Example

```yaml
TPA-CONFIRM-MENU:
  TITLE: '&8Confirm TPA {here}'
  SIZE: 27
  BUTTONS:
    CANCEL:
      MATERIAL: RED_STAINED_GLASS_PANE
      NAME: '&cCancel'
      LORE:
      - '&fCLICK TO CANCEL'
    CONFIRM:
      MATERIAL: LIME_STAINED_GLASS_PANE
      NAME: '&aConfirm'
      LORE:
      - '&fCLICK TO CONFIRM'
    PLAYER:
      MATERIAL: PLAYER_HEAD
      NAME: '&#00FC00Player'
      LORE:
      - '&7{player}'
    LOCATION:
      NAME: '&#6BF18DLocation'
      MATERIAL: GRASS_BLOCK
      LORE:
      - '&7{world}'
    REGION:
      NAME: '&#6BF18DRegion'
      MATERIAL: FEATHER
      LORE:
      - '&7NA East (&#0069D6${ping}ms&7)'
```

---

## Section: `BOUNTIES-MENU`

### 1. Commented Setup Code Example

```yaml
BOUNTIES-MENU:
  TITLE: '&8Bounties'
  SIZE: 54
  MAX-ITEMS-PER-PAGE: 45
  BOUNTY-BUTTON:
    MATERIAL: PLAYER_HEAD
    NAME: '&#6BF18D{player}'
    LORE:
    - '&fBounty: &7${price}'
  REFRESH-BUTTON:
    SLOT: 49
    MATERIAL: SKELETON_SKULL
    NAME: '&#6BF18DBounties'
    LORE:
    - '&fClick to refresh'
    - ''
    - '&7Set a bounty using this:'
    - '&7/bounty add (player) (amount)'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `BOUNTIES-MENU.TITLE` | `str` | Any string text | `'&8Bounties'` | Configures the technical `TITLE` parameter for `BOUNTIES-MENU.TITLE` in `menus.yml`. |
| `BOUNTIES-MENU.SIZE` | `int` | Any valid integer number | `'54'` | Configures the technical `SIZE` parameter for `BOUNTIES-MENU.SIZE` in `menus.yml`. |
| `BOUNTIES-MENU.MAX-ITEMS-PER-PAGE` | `int` | Any valid integer number | `'45'` | Configures the technical `MAX-ITEMS-PER-PAGE` parameter for `BOUNTIES-MENU.MAX-ITEMS-PER-PAGE` in `menus.yml`. |
| `BOUNTIES-MENU.BOUNTY-BUTTON.MATERIAL` | `str` | Any string text | `'PLAYER_HEAD'` | Configures the technical `MATERIAL` parameter for `BOUNTIES-MENU.BOUNTY-BUTTON.MATERIAL` in `menus.yml`. |
| `BOUNTIES-MENU.BOUNTY-BUTTON.NAME` | `str` | Any string text | `'&#6BF18D{player}'` | Configures the technical `NAME` parameter for `BOUNTIES-MENU.BOUNTY-BUTTON.NAME` in `menus.yml`. |
| `BOUNTIES-MENU.BOUNTY-BUTTON.LORE` | `list` | List of configured items/strings | `['&fBounty: &7${price}']` | Configures the technical `LORE` parameter for `BOUNTIES-MENU.BOUNTY-BUTTON.LORE` in `menus.yml`. |
| `BOUNTIES-MENU.REFRESH-BUTTON.SLOT` | `int` | Any valid integer number | `'49'` | Configures the technical `SLOT` parameter for `BOUNTIES-MENU.REFRESH-BUTTON.SLOT` in `menus.yml`. |
| `BOUNTIES-MENU.REFRESH-BUTTON.MATERIAL` | `str` | Any string text | `'SKELETON_SKULL'` | Configures the technical `MATERIAL` parameter for `BOUNTIES-MENU.REFRESH-BUTTON.MATERIAL` in `menus.yml`. |
| `BOUNTIES-MENU.REFRESH-BUTTON.NAME` | `str` | Any string text | `'&#6BF18DBounties'` | Configures the technical `NAME` parameter for `BOUNTIES-MENU.REFRESH-BUTTON.NAME` in `menus.yml`. |
| `BOUNTIES-MENU.REFRESH-BUTTON.LORE` | `list` | List of configured items/strings | `[&fClick to refresh, , &7Set a bounty using this:...]` | Configures the technical `LORE` parameter for `BOUNTIES-MENU.REFRESH-BUTTON.LORE` in `menus.yml`. |

### 3. Practical Setup Example

```yaml
BOUNTIES-MENU:
  TITLE: '&8Bounties'
  SIZE: 54
  MAX-ITEMS-PER-PAGE: 45
  BOUNTY-BUTTON:
    MATERIAL: PLAYER_HEAD
    NAME: '&#6BF18D{player}'
    LORE:
    - '&fBounty: &7${price}'
  REFRESH-BUTTON:
    SLOT: 49
    MATERIAL: SKELETON_SKULL
    NAME: '&#6BF18DBounties'
    LORE:
    - '&fClick to refresh'
    - ''
    - '&7Set a bounty using this:'
    - '&7/bounty add (player) (amount)'
```

---

## Section: `BOUNTY-CONFIRM-MENU`

### 1. Commented Setup Code Example

```yaml
BOUNTY-CONFIRM-MENU:
  TITLE: '&8Confirm Bounty'
  SIZE: 27
  CANCEL-BUTTON:
    MATERIAL: RED_STAINED_GLASS_PANE
    NAME: '&#FC0000Cancel'
    LORE:
    - '&7Click to cancel the bounty adding!'
  PLAYER-BUTTON:
    MATERIAL: PLAYER_HEAD
    NAME: '&#00FC00{player}'
    LORE:
    - '&fYou''re going to set &#00FC00{amount}'
  CONFIRM-BUTTON:
    MATERIAL: LIME_STAINED_GLASS_PANE
    NAME: '&#00FC00Confirm'
    LORE:
    - '&7Click to confirm to add {amount} bounty!'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `BOUNTY-CONFIRM-MENU.TITLE` | `str` | Any string text | `'&8Confirm Bounty'` | Configures the technical `TITLE` parameter for `BOUNTY-CONFIRM-MENU.TITLE` in `menus.yml`. |
| `BOUNTY-CONFIRM-MENU.SIZE` | `int` | Any valid integer number | `'27'` | Configures the technical `SIZE` parameter for `BOUNTY-CONFIRM-MENU.SIZE` in `menus.yml`. |
| `BOUNTY-CONFIRM-MENU.CANCEL-BUTTON.MATERIAL` | `str` | Any string text | `'RED_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `BOUNTY-CONFIRM-MENU.CANCEL-BUTTON.MATERIAL` in `menus.yml`. |
| `BOUNTY-CONFIRM-MENU.CANCEL-BUTTON.NAME` | `str` | Any string text | `'&#FC0000Cancel'` | Configures the technical `NAME` parameter for `BOUNTY-CONFIRM-MENU.CANCEL-BUTTON.NAME` in `menus.yml`. |
| `BOUNTY-CONFIRM-MENU.CANCEL-BUTTON.LORE` | `list` | List of configured items/strings | `['&7Click to cancel the bounty adding!']` | Configures the technical `LORE` parameter for `BOUNTY-CONFIRM-MENU.CANCEL-BUTTON.LORE` in `menus.yml`. |
| `BOUNTY-CONFIRM-MENU.PLAYER-BUTTON.MATERIAL` | `str` | Any string text | `'PLAYER_HEAD'` | Configures the technical `MATERIAL` parameter for `BOUNTY-CONFIRM-MENU.PLAYER-BUTTON.MATERIAL` in `menus.yml`. |
| `BOUNTY-CONFIRM-MENU.PLAYER-BUTTON.NAME` | `str` | Any string text | `'&#00FC00{player}'` | Configures the technical `NAME` parameter for `BOUNTY-CONFIRM-MENU.PLAYER-BUTTON.NAME` in `menus.yml`. |
| `BOUNTY-CONFIRM-MENU.PLAYER-BUTTON.LORE` | `list` | List of configured items/strings | `["&fYou're going to set &#00FC00{amount}"]` | Configures the technical `LORE` parameter for `BOUNTY-CONFIRM-MENU.PLAYER-BUTTON.LORE` in `menus.yml`. |
| `BOUNTY-CONFIRM-MENU.CONFIRM-BUTTON.MATERIAL` | `str` | Any string text | `'LIME_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `BOUNTY-CONFIRM-MENU.CONFIRM-BUTTON.MATERIAL` in `menus.yml`. |
| `BOUNTY-CONFIRM-MENU.CONFIRM-BUTTON.NAME` | `str` | Any string text | `'&#00FC00Confirm'` | Configures the technical `NAME` parameter for `BOUNTY-CONFIRM-MENU.CONFIRM-BUTTON.NAME` in `menus.yml`. |
| `BOUNTY-CONFIRM-MENU.CONFIRM-BUTTON.LORE` | `list` | List of configured items/strings | `['&7Click to confirm to add {amount} bounty!']` | Configures the technical `LORE` parameter for `BOUNTY-CONFIRM-MENU.CONFIRM-BUTTON.LORE` in `menus.yml`. |

### 3. Practical Setup Example

```yaml
BOUNTY-CONFIRM-MENU:
  TITLE: '&8Confirm Bounty'
  SIZE: 27
  CANCEL-BUTTON:
    MATERIAL: RED_STAINED_GLASS_PANE
    NAME: '&#FC0000Cancel'
    LORE:
    - '&7Click to cancel the bounty adding!'
  PLAYER-BUTTON:
    MATERIAL: PLAYER_HEAD
    NAME: '&#00FC00{player}'
    LORE:
    - '&fYou''re going to set &#00FC00{amount}'
  CONFIRM-BUTTON:
    MATERIAL: LIME_STAINED_GLASS_PANE
    NAME: '&#00FC00Confirm'
    LORE:
    - '&7Click to confirm to add {amount} bounty!'
```

---

## Section: `SELL-HISTORY-MENU`

### 1. Commented Setup Code Example

```yaml
SELL-HISTORY-MENU:
  TITLE: '&8Sell History'
  SIZE: 54
  MAX-ITEMS-PER-PAGE: 45
  BUTTONS:
    SORT:
      MATERIAL: ANVIL
      NAME: '&aSort'
      LORE:
      - '&fClick to sort'
      - ''
      - '&7({sort_state})'
      SLOT: 49
    MATERIAL-ITEM:
      LORE:
      - '&fTotal price: &a{price}'
      - '&fTotal amount: {amount}'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `SELL-HISTORY-MENU.TITLE` | `str` | Any string text | `'&8Sell History'` | Configures the technical `TITLE` parameter for `SELL-HISTORY-MENU.TITLE` in `menus.yml`. |
| `SELL-HISTORY-MENU.SIZE` | `int` | Any valid integer number | `'54'` | Configures the technical `SIZE` parameter for `SELL-HISTORY-MENU.SIZE` in `menus.yml`. |
| `SELL-HISTORY-MENU.MAX-ITEMS-PER-PAGE` | `int` | Any valid integer number | `'45'` | Configures the technical `MAX-ITEMS-PER-PAGE` parameter for `SELL-HISTORY-MENU.MAX-ITEMS-PER-PAGE` in `menus.yml`. |
| `SELL-HISTORY-MENU.BUTTONS.SORT.MATERIAL` | `str` | Any string text | `'ANVIL'` | Configures the technical `MATERIAL` parameter for `SELL-HISTORY-MENU.BUTTONS.SORT.MATERIAL` in `menus.yml`. |
| `SELL-HISTORY-MENU.BUTTONS.SORT.NAME` | `str` | Any string text | `'&aSort'` | Configures the technical `NAME` parameter for `SELL-HISTORY-MENU.BUTTONS.SORT.NAME` in `menus.yml`. |
| `SELL-HISTORY-MENU.BUTTONS.SORT.LORE` | `list` | List of configured items/strings | `['&fClick to sort', '', '&7({sort_state})']` | Configures the technical `LORE` parameter for `SELL-HISTORY-MENU.BUTTONS.SORT.LORE` in `menus.yml`. |
| `SELL-HISTORY-MENU.BUTTONS.SORT.SLOT` | `int` | Any valid integer number | `'49'` | Configures the technical `SLOT` parameter for `SELL-HISTORY-MENU.BUTTONS.SORT.SLOT` in `menus.yml`. |
| `SELL-HISTORY-MENU.BUTTONS.MATERIAL-ITEM.LORE` | `list` | List of configured items/strings | `['&fTotal price: &a{price}', '&fTotal amount: {amount}']` | Configures the technical `LORE` parameter for `SELL-HISTORY-MENU.BUTTONS.MATERIAL-ITEM.LORE` in `menus.yml`. |

### 3. Practical Setup Example

```yaml
SELL-HISTORY-MENU:
  TITLE: '&8Sell History'
  SIZE: 54
  MAX-ITEMS-PER-PAGE: 45
  BUTTONS:
    SORT:
      MATERIAL: ANVIL
      NAME: '&aSort'
      LORE:
      - '&fClick to sort'
      - ''
      - '&7({sort_state})'
      SLOT: 49
    MATERIAL-ITEM:
      LORE:
      - '&fTotal price: &a{price}'
      - '&fTotal amount: {amount}'
```

---

## Section: `BILLFORD-MENU`

### 1. Commented Setup Code Example

```yaml
BILLFORD-MENU:
  TITLE: '&8Billford'
  SIZE: 54
  TRADE-BUTTON:
    MATERIAL:
      NAME: '&aTrade with Billford'
      LORE:
      - ''
  CONFIRM-TRADE-BUTTON:
    MATERIAL: HOPPER
    NAME: '&8Trade'
    LORE:
    - '&fClick to confirm the trade'
    - ''
    - '&7(you need the items in your inventory)'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `BILLFORD-MENU.TITLE` | `str` | Any string text | `'&8Billford'` | Configures the technical `TITLE` parameter for `BILLFORD-MENU.TITLE` in `menus.yml`. |
| `BILLFORD-MENU.SIZE` | `int` | Any valid integer number | `'54'` | Configures the technical `SIZE` parameter for `BILLFORD-MENU.SIZE` in `menus.yml`. |
| `BILLFORD-MENU.TRADE-BUTTON.MATERIAL.NAME` | `str` | Any string text | `'&aTrade with Billford'` | Configures the technical `NAME` parameter for `BILLFORD-MENU.TRADE-BUTTON.MATERIAL.NAME` in `menus.yml`. |
| `BILLFORD-MENU.TRADE-BUTTON.MATERIAL.LORE` | `list` | List of configured items/strings | `['']` | Configures the technical `LORE` parameter for `BILLFORD-MENU.TRADE-BUTTON.MATERIAL.LORE` in `menus.yml`. |
| `BILLFORD-MENU.CONFIRM-TRADE-BUTTON.MATERIAL` | `str` | Any string text | `'HOPPER'` | Configures the technical `MATERIAL` parameter for `BILLFORD-MENU.CONFIRM-TRADE-BUTTON.MATERIAL` in `menus.yml`. |
| `BILLFORD-MENU.CONFIRM-TRADE-BUTTON.NAME` | `str` | Any string text | `'&8Trade'` | Configures the technical `NAME` parameter for `BILLFORD-MENU.CONFIRM-TRADE-BUTTON.NAME` in `menus.yml`. |
| `BILLFORD-MENU.CONFIRM-TRADE-BUTTON.LORE` | `list` | List of configured items/strings | `['&fClick to confirm the trade', '', '&7(you need the items in your inventory)']` | Configures the technical `LORE` parameter for `BILLFORD-MENU.CONFIRM-TRADE-BUTTON.LORE` in `menus.yml`. |

### 3. Practical Setup Example

```yaml
BILLFORD-MENU:
  TITLE: '&8Billford'
  SIZE: 54
  TRADE-BUTTON:
    MATERIAL:
      NAME: '&aTrade with Billford'
      LORE:
      - ''
  CONFIRM-TRADE-BUTTON:
    MATERIAL: HOPPER
    NAME: '&8Trade'
    LORE:
    - '&fClick to confirm the trade'
    - ''
    - '&7(you need the items in your inventory)'
```

---

## Section: `PURCHASE-SHOP-MENU`

### 1. Commented Setup Code Example

```yaml
PURCHASE-SHOP-MENU:
  TITLE: '&8Confirmation Menu'
  SIZE: 27
  BUTTONS:
    MAIN:
      SLOT: 13
      LORE:
        MONEY: '&fBUY PRICE: &a${price}'
        SHARD: '&fBUY PRICE: &5${price}X &lShards'
        DEFAULT: '&fBUY PRICE: &a${price}'
    CANCEL:
      SLOT: 21
      MATERIAL: RED_STAINED_GLASS_PANE
      NAME: '&cCancel'
      LORE: '&fCLICK TO CANCEL'
    CONFIRM:
      SLOT: 23
      MATERIAL: LIME_STAINED_GLASS_PANE
      NAME: '&aConfirm'
      LORE: '&fCLICK TO BUY'
    QUANTITY_ADJUST:
      ADD:
        MATERIAL: LIME_STAINED_GLASS_PANE
        ADD_1:
          SLOT: 15
          NAME: '&aAdd 1'
          INCREMENT: 1
        ADD_10:
          SLOT: 16
          NAME: '&aAdd 10'
          INCREMENT: 10
        SET_64:
          SLOT: 17
          NAME: '&aSet To 64'
          INCREMENT: 64
      REMOVE:
        MATERIAL: RED_STAINED_GLASS_PANE
        REMOVE_1:
          SLOT: 11
          NAME: '&cRemove 1'
          DECREMENT: 1
        REMOVE_10:
          SLOT: 10
          NAME: '&cRemove 10'
          DECREMENT: 10
        REMOVE_64:
          SLOT: 9
          NAME: '&cRemove 64'
          DECREMENT: 64
  RESTRICTIONS:
    TOTEM_OF_UNDYING:
      MAX_QUANTITY: 1
      MIN_QUANTITY: 1
      HIDE_QUANTITY_BUTTONS: true
    ENDER_PEARL:
      MAX_QUANTITY: 16
      MIN_QUANTITY: 1
    DEFAULT:
      MAX_QUANTITY: 64
      MIN_QUANTITY: 1
  MESSAGES:
    SUCCESS:
      MONEY: '&7You bought &e{Quantity} {item-name}&7 for &a${amount}'
      SHARDS: '&7You bought {item-name}&7 for &5{amount} shards'
    ERROR:
      NO_MONEY: '&cYOU DON''T HAVE ENOUGH MONEY.'
      NO_SHARDS: '&cYOU DON''T HAVE ENOUGH SHARDS.'
      FULL_INVENTORY: '&cYOUR INVENTORY IS FULL.'
  SOUNDS:
    SUCCESS: ENTITY_EXPERIENCE_ORB_PICKUP
    ERROR: ENTITY_VILLAGER_NO
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `PURCHASE-SHOP-MENU.TITLE` | `str` | Any string text | `'&8Confirmation Menu'` | Configures the technical `TITLE` parameter for `PURCHASE-SHOP-MENU.TITLE` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.SIZE` | `int` | Any valid integer number | `'27'` | Configures the technical `SIZE` parameter for `PURCHASE-SHOP-MENU.SIZE` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.MAIN.SLOT` | `int` | Any valid integer number | `'13'` | Configures the technical `SLOT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.MAIN.SLOT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.MAIN.LORE.MONEY` | `str` | Any string text | `'&fBUY PRICE: &a${price}'` | Configures the technical `MONEY` parameter for `PURCHASE-SHOP-MENU.BUTTONS.MAIN.LORE.MONEY` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.MAIN.LORE.SHARD` | `str` | Any string text | `'&fBUY PRICE: &5${price}X &lShards'` | Configures the technical `SHARD` parameter for `PURCHASE-SHOP-MENU.BUTTONS.MAIN.LORE.SHARD` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.MAIN.LORE.DEFAULT` | `str` | Any string text | `'&fBUY PRICE: &a${price}'` | Configures the technical `DEFAULT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.MAIN.LORE.DEFAULT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.CANCEL.SLOT` | `int` | Any valid integer number | `'21'` | Configures the technical `SLOT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.CANCEL.SLOT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.CANCEL.MATERIAL` | `str` | Any string text | `'RED_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `PURCHASE-SHOP-MENU.BUTTONS.CANCEL.MATERIAL` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.CANCEL.NAME` | `str` | Any string text | `'&cCancel'` | Configures the technical `NAME` parameter for `PURCHASE-SHOP-MENU.BUTTONS.CANCEL.NAME` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.CANCEL.LORE` | `str` | Any string text | `'&fCLICK TO CANCEL'` | Configures the technical `LORE` parameter for `PURCHASE-SHOP-MENU.BUTTONS.CANCEL.LORE` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.CONFIRM.SLOT` | `int` | Any valid integer number | `'23'` | Configures the technical `SLOT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.CONFIRM.SLOT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.CONFIRM.MATERIAL` | `str` | Any string text | `'LIME_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `PURCHASE-SHOP-MENU.BUTTONS.CONFIRM.MATERIAL` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.CONFIRM.NAME` | `str` | Any string text | `'&aConfirm'` | Configures the technical `NAME` parameter for `PURCHASE-SHOP-MENU.BUTTONS.CONFIRM.NAME` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.CONFIRM.LORE` | `str` | Any string text | `'&fCLICK TO BUY'` | Configures the technical `LORE` parameter for `PURCHASE-SHOP-MENU.BUTTONS.CONFIRM.LORE` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.MATERIAL` | `str` | Any string text | `'LIME_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.MATERIAL` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_1.SLOT` | `int` | Any valid integer number | `'15'` | Configures the technical `SLOT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_1.SLOT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_1.NAME` | `str` | Any string text | `'&aAdd 1'` | Configures the technical `NAME` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_1.NAME` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_1.INCREMENT` | `int` | Any valid integer number | `'1'` | Configures the technical `INCREMENT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_1.INCREMENT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_10.SLOT` | `int` | Any valid integer number | `'16'` | Configures the technical `SLOT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_10.SLOT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_10.NAME` | `str` | Any string text | `'&aAdd 10'` | Configures the technical `NAME` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_10.NAME` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_10.INCREMENT` | `int` | Any valid integer number | `'10'` | Configures the technical `INCREMENT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.ADD_10.INCREMENT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.SET_64.SLOT` | `int` | Any valid integer number | `'17'` | Configures the technical `SLOT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.SET_64.SLOT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.SET_64.NAME` | `str` | Any string text | `'&aSet To 64'` | Configures the technical `NAME` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.SET_64.NAME` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.SET_64.INCREMENT` | `int` | Any valid integer number | `'64'` | Configures the technical `INCREMENT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.ADD.SET_64.INCREMENT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.MATERIAL` | `str` | Any string text | `'RED_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.MATERIAL` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.REMOVE_1.SLOT` | `int` | Any valid integer number | `'11'` | Configures the technical `SLOT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.REMOVE_1.SLOT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.REMOVE_1.NAME` | `str` | Any string text | `'&cRemove 1'` | Configures the technical `NAME` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.REMOVE_1.NAME` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.REMOVE_1.DECREMENT` | `int` | Any valid integer number | `'1'` | Configures the technical `DECREMENT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.REMOVE_1.DECREMENT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.REMOVE_10.SLOT` | `int` | Any valid integer number | `'10'` | Configures the technical `SLOT` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.REMOVE_10.SLOT` in `menus.yml`. |
| `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.REMOVE_10.NAME` | `str` | Any string text | `'&cRemove 10'` | Configures the technical `NAME` parameter for `PURCHASE-SHOP-MENU.BUTTONS.QUANTITY_ADJUST.REMOVE.REMOVE_10.NAME` in `menus.yml`. |
| *(18 additional sub-keys configured in section)* | | | | |

### 3. Practical Setup Example

```yaml
PURCHASE-SHOP-MENU:
  TITLE: '&8Confirmation Menu'
  SIZE: 27
  BUTTONS:
    MAIN:
      SLOT: 13
      LORE:
        MONEY: '&fBUY PRICE: &a${price}'
        SHARD: '&fBUY PRICE: &5${price}X &lShards'
        DEFAULT: '&fBUY PRICE: &a${price}'
    CANCEL:
      SLOT: 21
      MATERIAL: RED_STAINED_GLASS_PANE
      NAME: '&cCancel'
      LORE: '&fCLICK TO CANCEL'
    CONFIRM:
      SLOT: 23
      MATERIAL: LIME_STAINED_GLASS_PANE
      NAME: '&aConfirm'
      LORE: '&fCLICK TO BUY'
    QUANTITY_ADJUST:
      ADD:
        MATERIAL: LIME_STAINED_GLASS_PANE
        ADD_1:
          SLOT: 15
          NAME: '&aAdd 1'
          INCREMENT: 1
        ADD_10:
          SLOT: 16
          NAME: '&aAdd 10'
          INCREMENT: 10
        SET_64:
          SLOT: 17
          NAME: '&aSet To 64'
          INCREMENT: 64
      REMOVE:
        MATERIAL: RED_STAINED_GLASS_PANE
        REMOVE_1:
          SLOT: 11
          NAME: '&cRemove 1'
          DECREMENT: 1
        REMOVE_10:
          SLOT: 10
          NAME: '&cRemove 10'
          DECREMENT: 10
        REMOVE_64:
          SLOT: 9
          NAME: '&cRemove 64'
          DECREMENT: 64
  RESTRICTIONS:
    TOTEM_OF_UNDYING:
      MAX_QUANTITY: 1
      MIN_QUANTITY: 1
      HIDE_QUANTITY_BUTTONS: true
    ENDER_PEARL:
      MAX_QUANTITY: 16
      MIN_QUANTITY: 1
    DEFAULT:
      MAX_QUANTITY: 64
      MIN_QUANTITY: 1
  MESSAGES:
    SUCCESS:
      MONEY: '&7You bought &e{Quantity} {item-name}&7 for &a${amount}'
      SHARDS: '&7You bought {item-name}&7 for &5{amount} shards'
    ERROR:
      NO_MONEY: '&cYOU DON''T HAVE ENOUGH MONEY.'
      NO_SHARDS: '&cYOU DON''T HAVE ENOUGH SHARDS.'
      FULL_INVENTORY: '&cYOUR INVENTORY IS FULL.'
  SOUNDS:
    SUCCESS: ENTITY_EXPERIENCE_ORB_PICKUP
    ERROR: ENTITY_VILLAGER_NO
```

---

## Section: `PAY-CONFIRM-MENU`

### 1. Commented Setup Code Example

```yaml
PAY-CONFIRM-MENU:
  TITLE: '&8Confirm Payment'
  SIZE: 27
  CONFIRM-BUTTON:
    TITLE: '&#00FC00Confirm'
    MATERIAL: LIME_STAINED_GLASS_PANE
    LORE:
    - '&7Click to confirm to pay {amount}!'
  CANCEL-BUTTON:
    TITLE: '&#FC0000Cancel'
    MATERIAL: RED_STAINED_GLASS_PANE
    LORE:
    - '&7Click to cancel'
  PLAYER-BUTTON:
    TITLE: '&#00FC00{player}'
    MATERIAL: PLAYER_HEAD
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `PAY-CONFIRM-MENU.TITLE` | `str` | Any string text | `'&8Confirm Payment'` | Configures the technical `TITLE` parameter for `PAY-CONFIRM-MENU.TITLE` in `menus.yml`. |
| `PAY-CONFIRM-MENU.SIZE` | `int` | Any valid integer number | `'27'` | Configures the technical `SIZE` parameter for `PAY-CONFIRM-MENU.SIZE` in `menus.yml`. |
| `PAY-CONFIRM-MENU.CONFIRM-BUTTON.TITLE` | `str` | Any string text | `'&#00FC00Confirm'` | Configures the technical `TITLE` parameter for `PAY-CONFIRM-MENU.CONFIRM-BUTTON.TITLE` in `menus.yml`. |
| `PAY-CONFIRM-MENU.CONFIRM-BUTTON.MATERIAL` | `str` | Any string text | `'LIME_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `PAY-CONFIRM-MENU.CONFIRM-BUTTON.MATERIAL` in `menus.yml`. |
| `PAY-CONFIRM-MENU.CONFIRM-BUTTON.LORE` | `list` | List of configured items/strings | `['&7Click to confirm to pay {amount}!']` | Configures the technical `LORE` parameter for `PAY-CONFIRM-MENU.CONFIRM-BUTTON.LORE` in `menus.yml`. |
| `PAY-CONFIRM-MENU.CANCEL-BUTTON.TITLE` | `str` | Any string text | `'&#FC0000Cancel'` | Configures the technical `TITLE` parameter for `PAY-CONFIRM-MENU.CANCEL-BUTTON.TITLE` in `menus.yml`. |
| `PAY-CONFIRM-MENU.CANCEL-BUTTON.MATERIAL` | `str` | Any string text | `'RED_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `PAY-CONFIRM-MENU.CANCEL-BUTTON.MATERIAL` in `menus.yml`. |
| `PAY-CONFIRM-MENU.CANCEL-BUTTON.LORE` | `list` | List of configured items/strings | `['&7Click to cancel']` | Configures the technical `LORE` parameter for `PAY-CONFIRM-MENU.CANCEL-BUTTON.LORE` in `menus.yml`. |
| `PAY-CONFIRM-MENU.PLAYER-BUTTON.TITLE` | `str` | Any string text | `'&#00FC00{player}'` | Configures the technical `TITLE` parameter for `PAY-CONFIRM-MENU.PLAYER-BUTTON.TITLE` in `menus.yml`. |
| `PAY-CONFIRM-MENU.PLAYER-BUTTON.MATERIAL` | `str` | Any string text | `'PLAYER_HEAD'` | Configures the technical `MATERIAL` parameter for `PAY-CONFIRM-MENU.PLAYER-BUTTON.MATERIAL` in `menus.yml`. |

### 3. Practical Setup Example

```yaml
PAY-CONFIRM-MENU:
  TITLE: '&8Confirm Payment'
  SIZE: 27
  CONFIRM-BUTTON:
    TITLE: '&#00FC00Confirm'
    MATERIAL: LIME_STAINED_GLASS_PANE
    LORE:
    - '&7Click to confirm to pay {amount}!'
  CANCEL-BUTTON:
    TITLE: '&#FC0000Cancel'
    MATERIAL: RED_STAINED_GLASS_PANE
    LORE:
    - '&7Click to cancel'
  PLAYER-BUTTON:
    TITLE: '&#00FC00{player}'
    MATERIAL: PLAYER_HEAD
```

---

## Section: `SELLALL-CONFIRM-MENU`

### 1. Commented Setup Code Example

```yaml
SELLALL-CONFIRM-MENU:
  TITLE: '&8Confirm Sell All'
  SIZE: 27
  CONFIRM-BUTTON:
    TITLE: '&#00FC00Confirm'
    MATERIAL: LIME_STAINED_GLASS_PANE
    SLOT: 15
    LORE:
    - '&7Click to confirm to sell all'
    - '&7sellable items in your inventory.'
  CANCEL-BUTTON:
    TITLE: '&#FC0000Cancel'
    MATERIAL: RED_STAINED_GLASS_PANE
    SLOT: 11
    LORE:
    - '&7Click to cancel'
  INFO-BUTTON:
    TITLE: '&#E69F00Sell All Items'
    MATERIAL: CHEST
    SLOT: 13
    LORE:
    - '&7This will sell all sellable'
    - '&7items in your inventory.'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `SELLALL-CONFIRM-MENU.TITLE` | `str` | Any string text | `'&8Confirm Sell All'` | Configures the technical `TITLE` parameter for `SELLALL-CONFIRM-MENU.TITLE` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.SIZE` | `int` | Any valid integer number | `'27'` | Configures the technical `SIZE` parameter for `SELLALL-CONFIRM-MENU.SIZE` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.CONFIRM-BUTTON.TITLE` | `str` | Any string text | `'&#00FC00Confirm'` | Configures the technical `TITLE` parameter for `SELLALL-CONFIRM-MENU.CONFIRM-BUTTON.TITLE` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.CONFIRM-BUTTON.MATERIAL` | `str` | Any string text | `'LIME_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `SELLALL-CONFIRM-MENU.CONFIRM-BUTTON.MATERIAL` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.CONFIRM-BUTTON.SLOT` | `int` | Any valid integer number | `'15'` | Configures the technical `SLOT` parameter for `SELLALL-CONFIRM-MENU.CONFIRM-BUTTON.SLOT` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.CONFIRM-BUTTON.LORE` | `list` | List of configured items/strings | `['&7Click to confirm to sell all', '&7sellable items in your inventory.']` | Configures the technical `LORE` parameter for `SELLALL-CONFIRM-MENU.CONFIRM-BUTTON.LORE` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.CANCEL-BUTTON.TITLE` | `str` | Any string text | `'&#FC0000Cancel'` | Configures the technical `TITLE` parameter for `SELLALL-CONFIRM-MENU.CANCEL-BUTTON.TITLE` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.CANCEL-BUTTON.MATERIAL` | `str` | Any string text | `'RED_STAINED_GLASS_PANE'` | Configures the technical `MATERIAL` parameter for `SELLALL-CONFIRM-MENU.CANCEL-BUTTON.MATERIAL` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.CANCEL-BUTTON.SLOT` | `int` | Any valid integer number | `'11'` | Configures the technical `SLOT` parameter for `SELLALL-CONFIRM-MENU.CANCEL-BUTTON.SLOT` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.CANCEL-BUTTON.LORE` | `list` | List of configured items/strings | `['&7Click to cancel']` | Configures the technical `LORE` parameter for `SELLALL-CONFIRM-MENU.CANCEL-BUTTON.LORE` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.INFO-BUTTON.TITLE` | `str` | Any string text | `'&#E69F00Sell All Items'` | Configures the technical `TITLE` parameter for `SELLALL-CONFIRM-MENU.INFO-BUTTON.TITLE` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.INFO-BUTTON.MATERIAL` | `str` | Any string text | `'CHEST'` | Configures the technical `MATERIAL` parameter for `SELLALL-CONFIRM-MENU.INFO-BUTTON.MATERIAL` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.INFO-BUTTON.SLOT` | `int` | Any valid integer number | `'13'` | Configures the technical `SLOT` parameter for `SELLALL-CONFIRM-MENU.INFO-BUTTON.SLOT` in `menus.yml`. |
| `SELLALL-CONFIRM-MENU.INFO-BUTTON.LORE` | `list` | List of configured items/strings | `['&7This will sell all sellable', '&7items in your inventory.']` | Configures the technical `LORE` parameter for `SELLALL-CONFIRM-MENU.INFO-BUTTON.LORE` in `menus.yml`. |

### 3. Practical Setup Example

```yaml
SELLALL-CONFIRM-MENU:
  TITLE: '&8Confirm Sell All'
  SIZE: 27
  CONFIRM-BUTTON:
    TITLE: '&#00FC00Confirm'
    MATERIAL: LIME_STAINED_GLASS_PANE
    SLOT: 15
    LORE:
    - '&7Click to confirm to sell all'
    - '&7sellable items in your inventory.'
  CANCEL-BUTTON:
    TITLE: '&#FC0000Cancel'
    MATERIAL: RED_STAINED_GLASS_PANE
    SLOT: 11
    LORE:
    - '&7Click to cancel'
  INFO-BUTTON:
    TITLE: '&#E69F00Sell All Items'
    MATERIAL: CHEST
    SLOT: 13
    LORE:
    - '&7This will sell all sellable'
    - '&7items in your inventory.'
```

---

## Section: `SERVER-INFO-MENU`

Opened with `/help`. A paged set of help screens: each page is a small menu of icons that
explain something about the server, and the navigation row moves between them. Pages are yours to
write, so this is the section most servers rewrite completely.

### 1. Commented Setup Code Example

```yaml
SERVER-INFO-MENU:
  TITLE: '&8Server Info'
  SIZE: 27
  # Fallback only. Ignored whenever PAGES produces at least one page.
  BUTTONS:
    SERVER:
      MATERIAL: LANTERN
      SLOT: 10
      NAME: '&#00A4FCDonutSMP'
      LORE:
      - '&fBuild a base, fight players.'
  NAVIGATION:
    BACK-SLOT: 18
    PAGE-INFO-SLOT: 22
    NEXT-SLOT: 26
    PAGE-INFO-MATERIAL: BOOK
    PAGE-INFO-NAME: '&#00A4FCHelp Pages'
  PAGES:
    # Keys are sorted numerically, so '10' lands after '9' rather than after '1'.
    '1':
      TITLE: '&8Server Info'
      SIZE: 27
      BUTTONS:
        SERVER:
          MATERIAL: LANTERN
          SLOT: 10
          NAME: '&#00A4FCDonutSMP'
          LORE:
          - '&fBuild a base, fight players,'
          - '&fand become the richest.'
        ECONOMY:
          MATERIAL: GOLD_INGOT
          SLOT: 11
          NAME: '&#00A4FCEconomy'
          LORE:
          - '&fSell items to earn money.'
          # Optional. Runs as the player on click.
          COMMAND: 'sell'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `SERVER-INFO-MENU.TITLE` | `str` | Any string text | `'&8Server info'` | Title for any page that does not set its own. |
| `SERVER-INFO-MENU.SIZE` | `int` | `9`, `18`, `27`, `36`, `45`, `54` | `27` | Size for any page that does not set its own. Anything else falls back to `27`. |
| `SERVER-INFO-MENU.NAVIGATION.BACK-SLOT` | `int` | `0` to `SIZE - 1` | `SIZE - 9` | Slot for the previous-page arrow. |
| `SERVER-INFO-MENU.NAVIGATION.PAGE-INFO-SLOT` | `int` | `0` to `SIZE - 1` | `SIZE - 5` | Slot for the page counter. |
| `SERVER-INFO-MENU.NAVIGATION.NEXT-SLOT` | `int` | `0` to `SIZE - 1` | `SIZE - 1` | Slot for the next-page arrow. |
| `SERVER-INFO-MENU.NAVIGATION.PAGE-INFO-MATERIAL` | `str` | Any valid material name | `BOOK` | Icon for the page counter. |
| `SERVER-INFO-MENU.NAVIGATION.PAGE-INFO-NAME` | `str` | Any string text | `'&bHelp pages'` | Name of the page counter. |
| `SERVER-INFO-MENU.PAGES.<N>.TITLE` | `str` | Any string text | the menu `TITLE` | Title for that page. |
| `SERVER-INFO-MENU.PAGES.<N>.SIZE` | `int` | `9`, `18`, `27`, `36`, `45`, `54` | the menu `SIZE` | Size for that page, so pages can differ. |
| `SERVER-INFO-MENU.PAGES.<N>.BUTTONS.<KEY>.SLOT` | `int` | `0` to `SIZE - 1` | - | Slot for the icon. The three navigation slots are reserved and a button placed on one is dropped. |
| `SERVER-INFO-MENU.PAGES.<N>.BUTTONS.<KEY>.MATERIAL` | `str` | Any valid material name | - | Icon material. A missing or invalid one skips the button. |
| `SERVER-INFO-MENU.PAGES.<N>.BUTTONS.<KEY>.NAME` | `str` | Any string text | Prettified button key | Icon name. |
| `SERVER-INFO-MENU.PAGES.<N>.BUTTONS.<KEY>.LORE` | `list` | List of strings | `[]` | The explanation itself. |
| `SERVER-INFO-MENU.PAGES.<N>.BUTTONS.<KEY>.COMMAND` | `str` | Any command, with or without `/` | unset | Run as the player on click. Leave it out for an icon that only reads. |
| `SERVER-INFO-MENU.PAGES.<N>.BUTTONS.<KEY>.ACTION.VALUE` | `str` | Any command, with or without `/` | unset | A second command slot, read the same way as `COMMAND`. |
| `SERVER-INFO-MENU.BUTTONS` | `section` | Same button shape | - | Legacy single-page fallback. See below. |

The top-level `BUTTONS` block is the part that catches people out. It is only read when `PAGES`
yields no usable page at all, and `menus.yml` ships both, so on a default install the top-level block
is never drawn and editing it changes nothing. Edit `PAGES.'1'.BUTTONS` instead. The block is worth
keeping for a config written before pages existed, but treat it as dead weight otherwise.

Page keys sort numerically rather than as text, so a tenth page keyed `'10'` lands after `'9'` where
plain string sorting would put it after `'1'`. A page whose buttons all fail to load is skipped
entirely rather than showing empty.

The previous and next arrows take their material and their names from the shared
`GLOBAL.PAGE-MENU` block, so only the slots and the page counter are configured here.

### 3. Practical Setup Example

Two pages of different sizes, with the second one linking out to a command:

```yaml
SERVER-INFO-MENU:
  TITLE: '&8About Us'
  SIZE: 27
  NAVIGATION:
    BACK-SLOT: 18
    PAGE-INFO-SLOT: 22
    NEXT-SLOT: 26
    PAGE-INFO-MATERIAL: WRITABLE_BOOK
    PAGE-INFO-NAME: '&ePage'
  PAGES:
    '1':
      TITLE: '&8About Us'
      BUTTONS:
        WELCOME:
          MATERIAL: LANTERN
          SLOT: 13
          NAME: '&bWelcome'
          LORE:
          - '&fSurvival with a shop and teams.'
    '2':
      TITLE: '&8Getting Started'
      SIZE: 36
      BUTTONS:
        SHOP:
          MATERIAL: EMERALD
          SLOT: 11
          NAME: '&bThe Shop'
          LORE:
          - '&fBuy and sell here.'
          - '&aClick to open'
          COMMAND: 'shop'
        HOMES:
          MATERIAL: RED_BED
          SLOT: 15
          NAME: '&bHomes'
          LORE:
          - '&fSet one with &a/sethome&f.'
```

Page 2 is a row deeper than page 1, which is allowed. Mind the navigation slots when you mix sizes:
the three values above are global rather than per page, so the numbers that suit a 27-slot page put
the arrows mid-inventory on a 36-slot one. Leaving them unset avoids that entirely, since the
defaults are worked out from each page's own size.

---

## Section: `RULES-MENU`

Opened with `/rules`. Each button is one page of rules: the icon name is the heading, the lore is the
list itself, so a server can split its rules across as many books as it likes. Clicking a page also
sends a short line in chat.

### 1. Commented Setup Code Example

```yaml
RULES-MENU:
  TITLE: '&8Rules'
  SIZE: 27
  BUTTONS:
    # Each key under BUTTONS is one rules page. Add or delete keys freely.
    RULE_1:
      MATERIAL: KNOWLEDGE_BOOK
      SLOT: 12
      NAME: '&#00A4FCServer Rules'
      LORE:
      - "&#00A4FC● &fNo Hacked Clients"
      - "&#00A4FC● &fNo Movement Mods"
    RULE_2:
      MATERIAL: KNOWLEDGE_BOOK
      SLOT: 14
      NAME: '&#00A4FC&lChat Rules'
      LORE:
      - "&#00A4FC● &fNo Spamming"
      # Leave CLICK-MESSAGE out and the plugin picks a line to suit the page.
      CLICK-MESSAGE:
      - '&7Read these before you type in chat.'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `RULES-MENU.TITLE` | `str` | Any string text | `'&8Rules'` | Inventory title shown at the top of the menu. |
| `RULES-MENU.SIZE` | `int` | `9`, `18`, `27`, `36`, `45`, `54` | `27` | Inventory size. Anything else falls back to `27` with a console warning. |
| `RULES-MENU.BUTTONS.<PAGE>.MATERIAL` | `str` | Any valid material name | - | Icon material. A page with a missing or invalid material is skipped. |
| `RULES-MENU.BUTTONS.<PAGE>.SLOT` | `int` | `0` to `SIZE - 1` | - | Slot the page renders in. Out-of-range and duplicate slots are skipped with a console warning. |
| `RULES-MENU.BUTTONS.<PAGE>.NAME` | `str` | Any string text | Prettified button key | Icon name, which acts as the heading for that page. |
| `RULES-MENU.BUTTONS.<PAGE>.LORE` | `list` | List of strings | `[]` | The rules themselves, one per line. |
| `RULES-MENU.BUTTONS.<PAGE>.CLICK-MESSAGE` | `list` | List of strings | Built-in line | Sent in chat on click. Left out, the plugin reads the key and the name: a key or name mentioning chat gets the chat wording, one mentioning server gets the server wording, anything else gets a generic line. |

Empty slots are always filled with `BLACK_STAINED_GLASS_PANE`. Unlike `RANKS-MENU` there is no
`FILLER-MATERIAL` option here. If no page renders at all the menu shows a barrier instead, which
means every page was skipped for a bad slot or a bad material. Turning `COMMANDS.RULES` off in
`config.yml` disables the command.

### 3. Practical Setup Example

Three pages on one row, each with wording of its own:

```yaml
RULES-MENU:
  TITLE: '&8Server Rules'
  SIZE: 27
  BUTTONS:
    GAMEPLAY:
      MATERIAL: DIAMOND_SWORD
      SLOT: 11
      NAME: '&bGameplay'
      LORE:
      - '&7No cheating of any kind'
      - '&7No abusing bugs'
      CLICK-MESSAGE:
      - '&7Caught cheating is an instant ban.'
    CHAT:
      MATERIAL: PAPER
      SLOT: 13
      NAME: '&bChat'
      LORE:
      - '&7No spam, no harassment'
    BUILDING:
      MATERIAL: BRICKS
      SLOT: 15
      NAME: '&bBuilding'
      LORE:
      - '&7No lag machines'
```

`GAMEPLAY` and `BUILDING` have no wording of their own, so both fall back to the generic line;
`CHAT` matches on its key and would get the chat wording even without a `CLICK-MESSAGE`.

---

## Section: `AFK-MENU`

Opened with `/afk`. One icon per AFK area, each bound to a cuboid, and clicking one queues a teleport
there. An extra button teleports to a random area. Areas are normally created with `/setafk` rather
than by hand, which writes the cuboid and the destination into this section for you.

### 1. Commented Setup Code Example

```yaml
AFK-MENU:
  TITLE: '&8AFK Areas'
  SIZE: 54
  # Only drawn when two or more areas resolve to a destination.
  RANDOM-BUTTON:
    SLOT: 49
    MATERIAL: AMETHYST_BLOCK
    DISPLAY-NAME: '&#A303F9AFK'
    LORE:
    - '&fClick to teleport to a random afk area'
  AREAS:
    # Each key is one area. Quote the numeric ids so YAML keeps them as keys.
    '1':
      SLOT: 0
      MATERIAL: ITEM_FRAME
      DISPLAY-NAME: '&#A303F9AFK #1'
      LORE:
      - '&8{players}/200'
      - '&7Click to go to this'
      - '&7AFK zone area.'
      # Written by /setafk. CUBOID names the region, LOCATION the exact destination.
      CUBOID: afk1
      LOCATION: 1
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `AFK-MENU.TITLE` | `str` | Any string text | `'&8AFK areas'` | Inventory title shown at the top of the menu. |
| `AFK-MENU.SIZE` | `int` | `9` to `54` | `54` | Inventory size. Unlike most menus this one rounds up to the next multiple of nine rather than warning, so `20` becomes `27`, and anything above `54` is capped there. |
| `AFK-MENU.RANDOM-BUTTON.SLOT` | `int` | `0` to `SIZE - 1` | `-1` | Slot for the random teleport button. Left unset the button never draws. |
| `AFK-MENU.RANDOM-BUTTON.MATERIAL` | `str` | Any valid material name | `COMPASS` | Icon material for the random button. |
| `AFK-MENU.RANDOM-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&fRandom'` | Icon name. `{areas}` becomes the number of areas currently drawn. |
| `AFK-MENU.RANDOM-BUTTON.LORE` | `list` | List of strings | `[]` | Icon lore, `{areas}` again. |
| `AFK-MENU.AREAS.<ID>.SLOT` | `int` | `0` to `SIZE - 1` | - | Slot the area renders in. Out-of-range slots, slots already taken by another area, and the random button's own slot are all skipped with a console warning. |
| `AFK-MENU.AREAS.<ID>.MATERIAL` | `str` | Any valid material name | - | Icon material. |
| `AFK-MENU.AREAS.<ID>.DISPLAY-NAME` | `str` | Any string text | - | Icon name. |
| `AFK-MENU.AREAS.<ID>.LORE` | `list` | List of strings | `[]` | Icon lore. |
| `AFK-MENU.AREAS.<ID>.CUBOID` | `str` | A cuboid name | `''` | The region this area belongs to. An area with no cuboid warns on startup and stays a decorative icon. |
| `AFK-MENU.AREAS.<ID>.LOCATION` | `str` | A serialised location | unset | Exact teleport destination. Written by `/setafk`; the older lowercase `location` is still read. |
| `AFK-MENU.AREAS.<ID>.CAPACITY` | `int` | `1` or more | `200` | What `{capacity}` reports. Not shipped in `menus.yml`, so add the key yourself if you want a number other than 200. |

`DISPLAY-NAME` and `LORE` on an area understand four placeholders:

| Placeholder | Replaced with |
| :--- | :--- |
| `{players}` | How many players are within 16 blocks of the destination |
| `{capacity}` | The area's `CAPACITY` |
| `{cuboid}` | The cuboid name, or nothing when the area has none |
| `{id}` | The area key, so `'1'` renders as `1` |

The bundled lore writes `&8{players}/200` with the 200 typed in as text. Using `{players}/{capacity}`
instead keeps the two in step if you ever change the capacity.

Empty slots are filled with `GRAY_STAINED_GLASS_PANE` and there is no option to change that. An area
whose destination will not resolve is quietly left out, so a menu that lists four areas can draw
three. With no areas at all the menu shows a barrier reading `&cNo AFK areas`; with areas that all
fail to resolve it shows `&cLocation not set` instead, which is the one to look for after editing
locations by hand. The random button only appears once **two or more** areas resolve, so a
single-area menu never shows it however the button is configured.

Players holding `ultimatedonutsmp.admin.teleportareas.delete` or `ultimatedonutsmp.admin` get an
extra `&cRight-click to delete` line on each area. That click opens a confirmation screen instead of
removing the area on the spot, because deleting one also blanks the point `/setafk` saved in
`LOCATIONS.AFK-LOCATION`; on the spawn menu the same click would take the server spawn with it.
Whoever confirms is named in the server log, along with the config key that was cleared. Turn the
whole menu off with `SETTINGS.AFK-MENU` in `config.yml`.

### 3. Practical Setup Example

Two areas on the top row with a live capacity readout, and the random button moved to the middle of
the bottom row:

```yaml
AFK-MENU:
  TITLE: '&8AFK Areas'
  SIZE: 27
  RANDOM-BUTTON:
    SLOT: 22
    MATERIAL: ENDER_PEARL
    DISPLAY-NAME: '&dRandom AFK'
    LORE:
    - '&7Sends you to one of &f{areas}&7 areas'
  AREAS:
    '1':
      SLOT: 11
      MATERIAL: ITEM_FRAME
      DISPLAY-NAME: '&dAFK #{id}'
      LORE:
      - '&8{players}/{capacity}'
      - '&7Region: &f{cuboid}'
      CUBOID: afk1
      CAPACITY: 50
    '2':
      SLOT: 15
      MATERIAL: ITEM_FRAME
      DISPLAY-NAME: '&dAFK #{id}'
      LORE:
      - '&8{players}/{capacity}'
      - '&7Region: &f{cuboid}'
      CUBOID: afk2
      CAPACITY: 50
```

---

## Section: `SPAWN-MENU`

Opened with `/spawn`. The same machinery as `AFK-MENU`, pointed at spawn areas instead: one icon per
area, a random button, and `/setspawn` to write the cuboid and destination rather than typing them.
Everything in the AFK section applies here with the paths swapped, so this entry only restates the
parts that differ.

### 1. Commented Setup Code Example

```yaml
SPAWN-MENU:
  TITLE: '&8Spawn Areas'
  SIZE: 54
  RANDOM-BUTTON:
    SLOT: 49
    MATERIAL: LIGHT_BLUE_GLAZED_TERRACOTTA
    DISPLAY-NAME: '&#00A4FCSpawn'
    LORE:
    - '&fClick to teleport to a random spawn area'
  AREAS:
    '1':
      SLOT: 0
      MATERIAL: ITEM_FRAME
      DISPLAY-NAME: '&#00A4FCSpawn #1'
      LORE:
      - '&8{players}/200'
      - '&7Click to go to this'
      - '&7Spawn area.'
      CUBOID: spawn1
      LOCATION: 1
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `SPAWN-MENU.TITLE` | `str` | Any string text | `'&8Spawn areas'` | Inventory title shown at the top of the menu. |
| `SPAWN-MENU.SIZE` | `int` | `9` to `54` | `54` | Rounds up to the next multiple of nine, capped at `54`, same as the AFK menu. |
| `SPAWN-MENU.RANDOM-BUTTON.SLOT` | `int` | `0` to `SIZE - 1` | `-1` | Slot for the random teleport button. Unset means no button. |
| `SPAWN-MENU.RANDOM-BUTTON.MATERIAL` | `str` | Any valid material name | `COMPASS` | Icon material for the random button. |
| `SPAWN-MENU.RANDOM-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&fRandom'` | Icon name, with `{areas}` available. |
| `SPAWN-MENU.RANDOM-BUTTON.LORE` | `list` | List of strings | `[]` | Icon lore, with `{areas}` available. |
| `SPAWN-MENU.AREAS.<ID>.SLOT` | `int` | `0` to `SIZE - 1` | - | Slot the area renders in. Collisions and out-of-range slots are skipped with a warning. |
| `SPAWN-MENU.AREAS.<ID>.MATERIAL` | `str` | Any valid material name | - | Icon material. |
| `SPAWN-MENU.AREAS.<ID>.DISPLAY-NAME` | `str` | Any string text | - | Icon name. |
| `SPAWN-MENU.AREAS.<ID>.LORE` | `list` | List of strings | `[]` | Icon lore. |
| `SPAWN-MENU.AREAS.<ID>.CUBOID` | `str` | A cuboid name | `''` | The region this area belongs to. |
| `SPAWN-MENU.AREAS.<ID>.LOCATION` | `str` | A serialised location | unset | Teleport destination, written by `/setspawn`. |
| `SPAWN-MENU.AREAS.<ID>.CAPACITY` | `int` | `1` or more | `200` | What `{capacity}` reports. Not shipped in `menus.yml`. |

The `{players}`, `{capacity}`, `{cuboid}` and `{id}` placeholders behave exactly as they do for the
AFK menu, and so do the barrier fallbacks, the two-area rule for the random button and the
right-click delete for admins. The empty menu here reads `&cNo spawn areas`. Turn it off with
`SETTINGS.SPAWN-MENU` in `config.yml`.

One thing worth keeping straight: this menu is the list of spawn *areas*, which is separate from the
single spawn hub that `/uds setup setspawn` records and that players respawn at. Editing this section
changes where `/spawn` can send people, not where a death sends them.

### 3. Practical Setup Example

A single spawn area, which is the common case on a server that does not want players choosing:

```yaml
SPAWN-MENU:
  TITLE: '&8Spawn'
  SIZE: 27
  AREAS:
    '1':
      SLOT: 13
      MATERIAL: LIGHT_BLUE_GLAZED_TERRACOTTA
      DISPLAY-NAME: '&bMain Spawn'
      LORE:
      - '&8{players} here now'
      - '&7Click to teleport'
      CUBOID: spawn1
```

With one area the random button is never drawn, so leaving `RANDOM-BUTTON` out entirely is the
tidier way to write it.

---

## Section: `PROFILE-VIEWER-MENU`

Opened with `/profileviewer <player>` (alias `/pv`). A read-only look at another player: a summary
head, their stats, and buttons through to their homes and their punishment history. The location
button teleports the viewer to them when they are online.

### 1. Commented Setup Code Example

```yaml
PROFILE-VIEWER-MENU:
  TITLE: '&8{username}''s Profile'
  SIZE: 54
  BUTTONS:
    SUMMARY:
      SLOT: 4
      MATERIAL: PLAYER_HEAD
      DISPLAY-NAME: '&#6BF18D{username}'
      LORE:
      - '&7Status: &f{status}'
      - '&7Team: &f{team}'
      - '&7Homes: &f{homes}'
    HOMES:
      SLOT: 40
      MATERIAL: RED_BED
      DISPLAY-NAME: '&#6BF18DHomes'
      LORE:
      - '&7Homes saved: &f{homes}'
    CURRENT-LOCATION:
      SLOT: 41
      MATERIAL: COMPASS
      DISPLAY-NAME: '&#6BF18DCurrent Location'
      # The -OFFLINE pair is used instead whenever the player cannot be teleported to.
      DISPLAY-NAME-OFFLINE: '&cCurrent Location'
      LORE:
      - '&7{world} ({x}, {y}, {z})'
      - '&aClick to teleport'
      LORE-OFFLINE:
      - '&7This player is offline right now.'
    PUNISHMENTS:
      SLOT: 42
      MATERIAL: IRON_BARS
      DISPLAY-NAME: '&#6BF18DPunishments'
    REFRESH:
      SLOT: 49
      MATERIAL: CLOCK
      DISPLAY-NAME: '&#6BF18DRefresh'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `PROFILE-VIEWER-MENU.TITLE` | `str` | Any string text | `'&8{username}''s profile'` | Inventory title. `{username}` is the player being viewed. |
| `PROFILE-VIEWER-MENU.SIZE` | `int` | `27`, `36`, `45`, `54` | `54` | Inventory size. Anything smaller than `27` or not a multiple of nine falls back to `54`. |
| `PROFILE-VIEWER-MENU.BUTTONS.SUMMARY.SLOT` | `int` | `0` to `SIZE - 1` | `4` | The head at the top of the menu. |
| `PROFILE-VIEWER-MENU.BUTTONS.SUMMARY.MATERIAL` | `str` | Any valid material name | `PLAYER_HEAD` | Icon material for the summary. |
| `PROFILE-VIEWER-MENU.BUTTONS.SUMMARY.DISPLAY-NAME` | `str` | Any string text | `'&b{username}'` | Summary icon name. |
| `PROFILE-VIEWER-MENU.BUTTONS.SUMMARY.LORE` | `list` | List of strings | `[]` | Summary lore, where most of the profile placeholders earn their keep. |
| `PROFILE-VIEWER-MENU.BUTTONS.HOMES.SLOT` | `int` | `0` to `SIZE - 1` | `40` | Opens `PROFILE-VIEWER-HOMES-MENU` for this player. |
| `PROFILE-VIEWER-MENU.BUTTONS.HOMES.MATERIAL` | `str` | Any valid material name | `RED_BED` | Icon material. |
| `PROFILE-VIEWER-MENU.BUTTONS.HOMES.DISPLAY-NAME` | `str` | Any string text | `'&bHomes'` | Icon name. |
| `PROFILE-VIEWER-MENU.BUTTONS.CURRENT-LOCATION.SLOT` | `int` | `0` to `SIZE - 1` | `41` | Teleports the viewer to the player. |
| `PROFILE-VIEWER-MENU.BUTTONS.CURRENT-LOCATION.MATERIAL` | `str` | Any valid material name | `COMPASS` | Icon material, shared by both states. |
| `PROFILE-VIEWER-MENU.BUTTONS.CURRENT-LOCATION.DISPLAY-NAME` | `str` | Any string text | `'&bCurrent location'` | Name while the player can be reached. |
| `PROFILE-VIEWER-MENU.BUTTONS.CURRENT-LOCATION.DISPLAY-NAME-OFFLINE` | `str` | Any string text | `'&cCurrent location'` | Name while they cannot. |
| `PROFILE-VIEWER-MENU.BUTTONS.CURRENT-LOCATION.LORE` | `list` | List of strings | Coordinates plus a click hint | Lore while the player can be reached. |
| `PROFILE-VIEWER-MENU.BUTTONS.CURRENT-LOCATION.LORE-OFFLINE` | `list` | List of strings | `'&7This player is offline right now.'` | Lore while they cannot. An empty list restores the default rather than blanking it. |
| `PROFILE-VIEWER-MENU.BUTTONS.PUNISHMENTS.SLOT` | `int` | `0` to `SIZE - 1` | `42` | Opens `PUNISHMENT-HISTORY-MENU` for this player. |
| `PROFILE-VIEWER-MENU.BUTTONS.PUNISHMENTS.MATERIAL` | `str` | Any valid material name | `IRON_BARS` | Icon material. |
| `PROFILE-VIEWER-MENU.BUTTONS.PUNISHMENTS.DISPLAY-NAME` | `str` | Any string text | `'&bPunishments'` | Icon name. |
| `PROFILE-VIEWER-MENU.BUTTONS.REFRESH.SLOT` | `int` | `0` to `SIZE - 1` | `49` | Rebuilds the menu against fresh data. |
| `PROFILE-VIEWER-MENU.BUTTONS.REFRESH.MATERIAL` | `str` | Any valid material name | `CLOCK` | Icon material. |
| `PROFILE-VIEWER-MENU.BUTTONS.REFRESH.DISPLAY-NAME` | `str` | Any string text | `'&bRefresh'` | Icon name. |

Every name and lore on this menu understands these:

| Placeholder | Replaced with |
| :--- | :--- |
| `{username}` | The name of the player being viewed |
| `{status}` | Their online or offline label |
| `{team}` | Their team name, blank when they have none |
| `{homes}` | How many homes they have saved |
| `{afk}` | Whether they are AFK, as yes or no |
| `{world}`, `{x}`, `{y}`, `{z}` | Where they last were |

Two behaviours are worth knowing before you rearrange anything. The `-OFFLINE` name and lore are
used whenever the player cannot be teleported to, which covers a player who is online but has no
resolvable location, not only one who has logged off. And the stat icons down the middle are not
configured here at all: they are read from `STATS-MENU.BUTTONS`, so editing that section changes what
`/stats` shows **and** what this menu shows. A stat icon whose slot falls outside this menu's size is
dropped without a warning.

Empty slots are filled with `GRAY_STAINED_GLASS_PANE`. If the profile cannot be loaded the menu shows
a barrier in the middle instead of the buttons.

### 3. Practical Setup Example

A smaller profile with the navigation moved onto one row:

```yaml
PROFILE-VIEWER-MENU:
  TITLE: '&8Profile: {username}'
  SIZE: 27
  BUTTONS:
    SUMMARY:
      SLOT: 4
      MATERIAL: PLAYER_HEAD
      DISPLAY-NAME: '&a{username}'
      LORE:
      - '&7Status: &f{status}'
      - '&7AFK: &f{afk}'
      - '&7Team: &f{team}'
      - '&7Last seen in &f{world}'
    HOMES:
      SLOT: 20
      MATERIAL: RED_BED
      DISPLAY-NAME: '&aHomes &7({homes})'
    CURRENT-LOCATION:
      SLOT: 22
      MATERIAL: COMPASS
      DISPLAY-NAME: '&aGo to {username}'
      DISPLAY-NAME-OFFLINE: '&7Cannot reach {username}'
      LORE-OFFLINE:
      - '&7They are offline or between worlds.'
    PUNISHMENTS:
      SLOT: 24
      MATERIAL: IRON_BARS
      DISPLAY-NAME: '&aPunishments'
```

Dropping `SIZE` to `27` also hides any `STATS-MENU` icon sitting on a slot above 26, which is the
quickest way to get a compact profile without touching the stats menu itself.

---

## Section: `PROFILE-VIEWER-HOMES-MENU`

Reached from the homes button on `PROFILE-VIEWER-MENU`. Lists the homes the viewed player has saved,
paged when there are more than a screenful, and clicking one teleports the viewer there. Unlike the
menus above there is no `BUTTONS` map here: each button is its own named block, because each one
means something different rather than being one entry in a list.

### 1. Commented Setup Code Example

```yaml
PROFILE-VIEWER-HOMES-MENU:
  TITLE: '&8{username}''s Homes'
  SIZE: 54
  MAX-ITEMS-PER-PAGE: 45
  HOME-BUTTON:
    MATERIAL: LIGHT_BLUE_BED
    DISPLAY-NAME: '&b{name}'
    LORE:
    - '&7World: &f{world}'
    - '&7X: &f{x} &7Y: &f{y} &7Z: &f{z}'
    - '&aClick to teleport'
  # Used for a home whose world is not loaded, in place of HOME-BUTTON.
  INVALID-HOME-BUTTON:
    MATERIAL: BARRIER
    DISPLAY-NAME: '&c{name}'
    LORE:
    - '&7This home points to an unavailable world.'
  EMPTY-BUTTON:
    MATERIAL: BARRIER
    DISPLAY-NAME: '&cNo Homes'
    LORE:
    - '&7This player has no homes saved.'
  BACK-BUTTON:
    MATERIAL: RED_STAINED_GLASS_PANE
    DISPLAY-NAME: '&cBack'
  CLOSE-BUTTON:
    MATERIAL: RED_STAINED_GLASS_PANE
    DISPLAY-NAME: '&cClose'
  REFRESH-BUTTON:
    MATERIAL: CLOCK
    DISPLAY-NAME: '&#6BF18DRefresh'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `PROFILE-VIEWER-HOMES-MENU.TITLE` | `str` | Any string text | `'&8{username}''s homes'` | Inventory title. `{username}` is the player being viewed. |
| `PROFILE-VIEWER-HOMES-MENU.SIZE` | `int` | `27`, `36`, `45`, `54` | `54` | Inventory size. Anything smaller than `27` or not a multiple of nine falls back to `54`. |
| `PROFILE-VIEWER-HOMES-MENU.MAX-ITEMS-PER-PAGE` | `int` | `1` to `45` | `45` | Homes drawn per page. Values outside the range are pulled back into it rather than rejected, so `60` behaves as `45` and `0` as `1`. |
| `PROFILE-VIEWER-HOMES-MENU.HOME-BUTTON.MATERIAL` | `str` | Any valid material name | `LIGHT_BLUE_BED` | Icon for a home that can be teleported to. |
| `PROFILE-VIEWER-HOMES-MENU.HOME-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&b{name}'` | Icon name for a home. |
| `PROFILE-VIEWER-HOMES-MENU.HOME-BUTTON.LORE` | `list` | List of strings | `[]` | Icon lore for a home. |
| `PROFILE-VIEWER-HOMES-MENU.INVALID-HOME-BUTTON.MATERIAL` | `str` | Any valid material name | `BARRIER` | Icon for a home whose world is not loaded. |
| `PROFILE-VIEWER-HOMES-MENU.INVALID-HOME-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&c{name}'` | Icon name for an unreachable home. |
| `PROFILE-VIEWER-HOMES-MENU.INVALID-HOME-BUTTON.LORE` | `list` | List of strings | `[]` | Icon lore for an unreachable home. |
| `PROFILE-VIEWER-HOMES-MENU.EMPTY-BUTTON.MATERIAL` | `str` | Any valid material name | `BARRIER` | Shown when the player has no homes at all. |
| `PROFILE-VIEWER-HOMES-MENU.EMPTY-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&cNo homes'` | Name of the empty placeholder. |
| `PROFILE-VIEWER-HOMES-MENU.EMPTY-BUTTON.LORE` | `list` | List of strings | `[]` | Lore of the empty placeholder. |
| `PROFILE-VIEWER-HOMES-MENU.BACK-BUTTON.MATERIAL` | `str` | Any valid material name | `RED_STAINED_GLASS_PANE` | Returns to the profile. Drawn only when the menu was opened from the profile. |
| `PROFILE-VIEWER-HOMES-MENU.BACK-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&cBack'` | Name of the back button. |
| `PROFILE-VIEWER-HOMES-MENU.CLOSE-BUTTON.MATERIAL` | `str` | Any valid material name | `RED_STAINED_GLASS_PANE` | Closes the menu. Takes the same position as the back button and replaces it whenever there is no profile to go back to. |
| `PROFILE-VIEWER-HOMES-MENU.CLOSE-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&cClose'` | Name of the close button. |
| `PROFILE-VIEWER-HOMES-MENU.REFRESH-BUTTON.MATERIAL` | `str` | Any valid material name | `CLOCK` | Rebuilds the list against fresh data. |
| `PROFILE-VIEWER-HOMES-MENU.REFRESH-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&bRefresh'` | Name of the refresh button. |

The title and the refresh button read `{username}` and `{homes}`. A home icon gets its own set:

| Placeholder | Replaced with |
| :--- | :--- |
| `{name}` | The home's name |
| `{world}` | The world the home is in |
| `{x}`, `{y}`, `{z}` | The home's coordinates |
| `{username}` | The player who owns the home |

Back and close are the same button wearing two hats: the menu draws `BACK-BUTTON` when it was
opened from a profile and `CLOSE-BUTTON` when it was not, so both blocks want configuring even
though only one shows at a time.

`INVALID-HOME-BUTTON` is the one people miss. A home in a world the server is not currently running
still occupies a slot; it just draws with this block instead and does nothing when clicked. That is
why the default is a barrier rather than a bed, and it is worth leaving obviously different from
`HOME-BUTTON` so the reason a teleport does nothing is visible.

Paging buttons come from the shared `GLOBAL.PAGE-MENU` block rather than from here, so the arrows
match every other paged menu.

### 3. Practical Setup Example

A shorter list with two rows of homes, so the navigation row stays clear of them:

```yaml
PROFILE-VIEWER-HOMES-MENU:
  TITLE: '&8Homes of {username}'
  SIZE: 36
  MAX-ITEMS-PER-PAGE: 18
  HOME-BUTTON:
    MATERIAL: LIGHT_BLUE_BED
    DISPLAY-NAME: '&b{name}'
    LORE:
    - '&7{world} &8({x}, {y}, {z})'
    - '&aClick to teleport'
  INVALID-HOME-BUTTON:
    MATERIAL: STRUCTURE_VOID
    DISPLAY-NAME: '&8{name}'
    LORE:
    - '&7World &f{world} &7is not loaded.'
  EMPTY-BUTTON:
    MATERIAL: LIGHT_GRAY_STAINED_GLASS_PANE
    DISPLAY-NAME: '&7Nothing saved'
    LORE:
    - '&7{username} has no homes.'
```

---

## Section: `PUNISHMENT-HISTORY-MENU`

Opened with `/punishments <player>`, and from the punishments button on a profile. Every record the
plugin holds for one player, newest first, with filters for state and type. Staff who hold the delete
permission can remove a record from here.

Note before you start moving things: the buttons on this menu have no `SLOT` option. Their positions
are fixed along the bottom row, so this section controls what they look like rather than where they
sit.

### 1. Commented Setup Code Example

```yaml
PUNISHMENT-HISTORY-MENU:
  TITLE: '&8Punishments ({player})'
  SIZE: 54
  MAX-ITEMS-PER-PAGE: 45
  BUTTONS:
    # Positions are fixed: back 45, state filter 46, type filter 47, refresh 49.
    BACK:
      MATERIAL: ARROW
      DISPLAY-NAME: '&cBack'
    FILTER-STATE:
      MATERIAL: HOPPER
      DISPLAY-NAME: '&#6BF18DState Filter'
      LORE:
      - '&7Current: &f{state_filter}'
    FILTER-TYPE:
      MATERIAL: BOOK
      DISPLAY-NAME: '&#6BF18DType Filter'
      LORE:
      - '&7Current: &f{type_filter}'
    REFRESH:
      MATERIAL: CLOCK
      DISPLAY-NAME: '&#6BF18DRefresh'
  # One template for every record, with the icon picked by punishment type.
  PUNISHMENT-ITEM:
    MATERIALS:
      BAN: IRON_BARS
      MUTE: PAPER
      WARN: YELLOW_DYE
      KICK: LEATHER_BOOTS
      BLACKLIST: BARRIER
    DISPLAY-NAME: '{status_color}{type}'
    LORE:
    - '&7Reason: &f{reason}'
    - '&7Issued by: &f{issuer}'
    - '&7Status: {status_color}{status}'
    - '&7ID: &f#{id}'
  EMPTY-BUTTON:
    MATERIAL: BARRIER
    DISPLAY-NAME: '&cNo Punishment History'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `PUNISHMENT-HISTORY-MENU.TITLE` | `str` | Any string text | `'&8Punishments ({player})'` | Inventory title. |
| `PUNISHMENT-HISTORY-MENU.SIZE` | `int` | `27`, `36`, `45`, `54` | `54` | Inventory size. Anything under `27` or not a multiple of nine falls back to `54`. Leave it at `54`, since the fixed button row sits on slots 45 to 52. |
| `PUNISHMENT-HISTORY-MENU.MAX-ITEMS-PER-PAGE` | `int` | `1` to `45` | `45` | Records per page. Values outside the range are pulled back into it. |
| `PUNISHMENT-HISTORY-MENU.BUTTONS.BACK` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `ARROW`, `'&cBack'` | Returns to the profile. Fixed on slot 45. |
| `PUNISHMENT-HISTORY-MENU.BUTTONS.FILTER-STATE` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `HOPPER` | Cycles the state filter on click. Fixed on slot 46. |
| `PUNISHMENT-HISTORY-MENU.BUTTONS.FILTER-TYPE` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `BOOK` | Cycles the type filter on click. Fixed on slot 47. |
| `PUNISHMENT-HISTORY-MENU.BUTTONS.REFRESH` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `CLOCK` | Re-reads the records. Fixed on slot 49. |
| `PUNISHMENT-HISTORY-MENU.PUNISHMENT-ITEM.MATERIALS.<TYPE>` | `str` | Any valid material name | see example | Icon per punishment type: `BAN`, `MUTE`, `WARN`, `KICK`, `BLACKLIST`. |
| `PUNISHMENT-HISTORY-MENU.PUNISHMENT-ITEM.DISPLAY-NAME` | `str` | Any string text | `'{status_color}{type}'` | Record icon name. |
| `PUNISHMENT-HISTORY-MENU.PUNISHMENT-ITEM.LORE` | `list` | List of strings | Built-in block | Record icon lore. |
| `PUNISHMENT-HISTORY-MENU.EMPTY-BUTTON` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `BARRIER` | Shown when the player has no records. |

Menu-level text, meaning the title and the filter buttons, reads these:

| Placeholder | Replaced with |
| :--- | :--- |
| `{player}` | The player whose history this is |
| `{state_filter}`, `{type_filter}` | The filters as they currently stand |
| `{page}`, `{pages}`, `{total}` | Page position and the record count |

A record icon reads a larger set, and four of them are worth calling out because the shipped lore
leaves them out: `{scope}` and `{source_server}` exist alongside the obvious ones.

| Placeholder | Replaced with |
| :--- | :--- |
| `{type}` | Ban, mute, warn, kick or blacklist |
| `{player}` | Who it was issued against |
| `{reason}` | The reason given |
| `{issuer}` | Who issued it |
| `{issued_at}`, `{expires_at}` | When it started and when it ends |
| `{status}`, `{status_color}` | Active or lifted, and the colour that matches |
| `{removed_by}`, `{removal_reason}`, `{removed_at}` | Who lifted it, why and when |
| `{id}` | The record id |
| `{scope}` | Whether the punishment is network-wide or local |
| `{source_server}` | Which server issued it |

Paging arrows come from the shared `GLOBAL.PAGE-MENU` block. Deleting a record is a shift-right-click
and needs `ultimatedonutsmp.staff.punishments.delete`; without that permission the click does
nothing, so leave the hint line out of the lore for servers where only admins hold it.

### 3. Practical Setup Example

A shorter record card that surfaces the network scope, useful when punishments are shared between
servers:

```yaml
PUNISHMENT-HISTORY-MENU:
  TITLE: '&8History: {player}'
  SIZE: 54
  MAX-ITEMS-PER-PAGE: 27
  PUNISHMENT-ITEM:
    MATERIALS:
      BAN: BARRIER
      MUTE: PAPER
      WARN: YELLOW_DYE
      KICK: LEATHER_BOOTS
      BLACKLIST: BEDROCK
    DISPLAY-NAME: '{status_color}{type} &8#{id}'
    LORE:
    - '&7Reason: &f{reason}'
    - '&7By &f{issuer} &7on &f{issued_at}'
    - '&7Scope: &f{scope} &8({source_server})'
    - '&7Status: {status_color}{status}'
```

---

## Section: `PUNISHMENTS-LIST-MENU`

Opened with `/punishments` and no player named. Every record on the server rather than one player's,
with the same state and type filters plus a sort order and a search. Clicking a record opens that
player's history.

Button positions are fixed here too, along the bottom row, so this section sets their appearance
rather than their slots.

### 1. Commented Setup Code Example

```yaml
PUNISHMENTS-LIST-MENU:
  TITLE: '&8All Punishments'
  SIZE: 54
  MAX-ITEMS-PER-PAGE: 45
  BUTTONS:
    # Fixed: back 45, state 46, type 47, refresh 49, search 51, sort 53.
    BACK:
      MATERIAL: ARROW
      DISPLAY-NAME: '&cClose'
    FILTER-STATE:
      MATERIAL: HOPPER
      DISPLAY-NAME: '&#6BF18DState Filter'
      LORE:
      - '&7Current: &f{state_filter}'
    FILTER-TYPE:
      MATERIAL: BOOK
      DISPLAY-NAME: '&#6BF18DType Filter'
      LORE:
      - '&7Current: &f{type_filter}'
    SORT:
      MATERIAL: COMPARATOR
      DISPLAY-NAME: '&#6BF18DSort Order'
      LORE:
      - '&7Current: &f{sort_order}'
    SEARCH:
      MATERIAL: NAME_TAG
      DISPLAY-NAME: '&#6BF18DSearch'
      LORE:
      - '&7Current: &f{search}'
      - '&aLeft-click to search a player'
      - '&cRight-click to clear'
    REFRESH:
      MATERIAL: CLOCK
      DISPLAY-NAME: '&#6BF18DRefresh'
  # The sign that opens when search is clicked.
  SEARCH-SIGN:
    INPUT-LINE: 0
    LINES:
    - ''
    - '^^^^^^^^^^^^^^'
    - 'Player Name'
    - ''
  PUNISHMENT-ITEM:
    MATERIALS:
      BAN: IRON_BARS
      MUTE: PAPER
      WARN: YELLOW_DYE
      KICK: LEATHER_BOOTS
      BLACKLIST: BARRIER
    DISPLAY-NAME: '{status_color}{player} &8- &f{type}'
    LORE:
    - '&7Reason: &f{reason}'
    - '&7Status: {status_color}{status}'
  # Drawn while the punishment table is still being read.
  LOADING-BUTTON:
    MATERIAL: CLOCK
    DISPLAY-NAME: '&eLoading Punishments'
  EMPTY-BUTTON:
    MATERIAL: BARRIER
    DISPLAY-NAME: '&cNo Punishments Found'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `PUNISHMENTS-LIST-MENU.TITLE` | `str` | Any string text | `'&8All punishments'` | Inventory title. |
| `PUNISHMENTS-LIST-MENU.SIZE` | `int` | `27`, `36`, `45`, `54` | `54` | Inventory size. Under `27` or not a multiple of nine falls back to `54`. The fixed row uses slots 45 to 53, so `54` is the only size that fits all of it. |
| `PUNISHMENTS-LIST-MENU.MAX-ITEMS-PER-PAGE` | `int` | `1` to `45` | `45` | Records per page, clamped into range. |
| `PUNISHMENTS-LIST-MENU.BUTTONS.BACK` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `ARROW` | Closes the menu. Fixed on slot 45. |
| `PUNISHMENTS-LIST-MENU.BUTTONS.FILTER-STATE` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `HOPPER` | Cycles the state filter. Fixed on slot 46. |
| `PUNISHMENTS-LIST-MENU.BUTTONS.FILTER-TYPE` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `BOOK` | Cycles the type filter. Fixed on slot 47. |
| `PUNISHMENTS-LIST-MENU.BUTTONS.REFRESH` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `CLOCK` | Re-reads the table. Fixed on slot 49. |
| `PUNISHMENTS-LIST-MENU.BUTTONS.SEARCH` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `NAME_TAG` | Left-click opens the search sign, right-click clears the search. Fixed on slot 51. |
| `PUNISHMENTS-LIST-MENU.BUTTONS.SORT` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `COMPARATOR` | Cycles the sort order. Fixed on slot 53. |
| `PUNISHMENTS-LIST-MENU.SEARCH-SIGN.INPUT-LINE` | `int` | `0` to `3` | `0` | Which line of the sign the staff member types the name on. |
| `PUNISHMENTS-LIST-MENU.SEARCH-SIGN.LINES` | `list` | Four strings | see example | The sign as it opens. Keep the input line blank and use the others as the prompt. |
| `PUNISHMENTS-LIST-MENU.PUNISHMENT-ITEM` | `section` | `MATERIALS`, `DISPLAY-NAME`, `LORE` | see example | Record template, the same shape as the history menu's. |
| `PUNISHMENTS-LIST-MENU.LOADING-BUTTON` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `CLOCK` | Drawn while the table is still loading. |
| `PUNISHMENTS-LIST-MENU.EMPTY-BUTTON` | `section` | `MATERIAL`, `DISPLAY-NAME`, `LORE` | `BARRIER` | Drawn when nothing matches the filters. |

Record icons take the same placeholders as the history menu, `{scope}` and `{source_server}`
included. Menu-level text here adds two of its own to that menu's set:

| Placeholder | Replaced with |
| :--- | :--- |
| `{sort_order}` | The sort as it currently stands |
| `{search}` | The active search term, or a blank when there is none |

`LOADING-BUTTON` is the one that only shows up on a busy server: the list reads the punishment table
off the main thread, so on a large database staff see this icon first and the records a moment later.
If it never appears, that is fine, it just means the read finished quickly.

Left-clicking a record opens that player's `PUNISHMENT-HISTORY-MENU`, and shift-right-click deletes
it for staff holding `ultimatedonutsmp.staff.punishments.delete`. Paging arrows come from
`GLOBAL.PAGE-MENU`.

### 3. Practical Setup Example

A denser list that leans on the search, for a server with a long history:

```yaml
PUNISHMENTS-LIST-MENU:
  TITLE: '&8Punishments &7({total})'
  SIZE: 54
  MAX-ITEMS-PER-PAGE: 36
  BUTTONS:
    SEARCH:
      MATERIAL: NAME_TAG
      DISPLAY-NAME: '&eSearch: &f{search}'
      LORE:
      - '&aLeft-click to type a name'
      - '&cRight-click to clear'
    SORT:
      MATERIAL: COMPARATOR
      DISPLAY-NAME: '&eSort: &f{sort_order}'
  SEARCH-SIGN:
    INPUT-LINE: 0
    LINES:
    - ''
    - '^^^^^^^^^^^^^^'
    - 'Type a name'
    - ''
  PUNISHMENT-ITEM:
    DISPLAY-NAME: '{status_color}{player}'
    LORE:
    - '&7{type} &8- &f{reason}'
    - '&7By &f{issuer}'
    - '&8#{id}'
```

---

## Section: `STATS-WIPE-MENU`

Opened with `/ultimatedonutsmp statswipe`, and it needs `ultimatedonutsmp.admin.statswipe`. One
button per kind of stored data, each showing how many records a wipe would touch, and each leading to
a confirmation menu rather than firing straight away.

The seven buttons map to a fixed list of wipe targets. Adding a key of your own does nothing, but
deleting one removes that option from the GUI, which is the supported way to keep a destructive wipe
off the menu on a live server.

### 1. Commented Setup Code Example

```yaml
STATS-WIPE-MENU:
  TITLE: '&8Stats Wipe'
  SIZE: 27
  PLACEHOLDER: true
  PLACEHOLDER-MATERIAL: BLACK_STAINED_GLASS_PANE
  # Replaces the button grid entirely while another wipe is still running.
  STATUS:
    SLOT: 13
    MATERIAL: BARRIER
    DISPLAY-NAME: '&cWipe In Progress'
    LORE:
    - '&7Another wipe is currently running.'
  BUTTONS:
    # Delete a block to take that wipe off the menu. New keys are ignored.
    MONEY:
      SLOT: 9
      MATERIAL: GOLD_INGOT
      DISPLAY-NAME: '&#6BF18DPlayer Money'
      LORE:
      - '&7Players with custom balances: &f{count}'
    PLAYER_STATS:
      SLOT: 10
      MATERIAL: PAPER
      DISPLAY-NAME: '&#6BF18DPlayer Stats'
      LORE:
      - '&7Players with tracked stats: &f{count}'
    REFRESH:
      SLOT: 22
      MATERIAL: CLOCK
      DISPLAY-NAME: '&#6BF18DRefresh'
    CLOSE:
      SLOT: 26
      MATERIAL: BARRIER
      DISPLAY-NAME: '&cClose'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `STATS-WIPE-MENU.TITLE` | `str` | Any string text | `'&8Stats wipe'` | Inventory title. |
| `STATS-WIPE-MENU.SIZE` | `int` | `9`, `18`, `27`, `36`, `45`, `54` | `27` | Inventory size. Anything else falls back to `27`. |
| `STATS-WIPE-MENU.PLACEHOLDER` | `bool` | `true`, `false` | `true` | Whether the unused slots get filled at all. |
| `STATS-WIPE-MENU.PLACEHOLDER-MATERIAL` | `str` | Any valid material name | `BLACK_STAINED_GLASS_PANE` | What fills them when it is on. |
| `STATS-WIPE-MENU.STATUS.SLOT` | `int` | `0` to `SIZE - 1` | `13` | Where the in-progress notice sits. |
| `STATS-WIPE-MENU.STATUS.MATERIAL` | `str` | Any valid material name | `BARRIER` | Icon for the in-progress notice. |
| `STATS-WIPE-MENU.STATUS.DISPLAY-NAME` | `str` | Any string text | - | Name of the in-progress notice. |
| `STATS-WIPE-MENU.STATUS.LORE` | `list` | List of strings | `[]` | Lore of the in-progress notice. |
| `STATS-WIPE-MENU.BUTTONS.<TARGET>.SLOT` | `int` | `0` to `SIZE - 1` | `-1` | Slot for that wipe. A slot outside the menu drops the button silently. |
| `STATS-WIPE-MENU.BUTTONS.<TARGET>.MATERIAL` | `str` | Any valid material name | - | Icon material. |
| `STATS-WIPE-MENU.BUTTONS.<TARGET>.DISPLAY-NAME` | `str` | Any string text | - | Icon name. |
| `STATS-WIPE-MENU.BUTTONS.<TARGET>.LORE` | `list` | List of strings | `[]` | Icon lore, where `{count}` belongs. |
| `STATS-WIPE-MENU.BUTTONS.REFRESH` | `section` | `SLOT`, `MATERIAL`, `DISPLAY-NAME`, `LORE` | slot `22` | Recounts the records. |
| `STATS-WIPE-MENU.BUTTONS.CLOSE` | `section` | `SLOT`, `MATERIAL`, `DISPLAY-NAME`, `LORE` | slot `26` | Closes the menu. |

`<TARGET>` is one of exactly seven keys:

| Key | Wipes |
| :--- | :--- |
| `PLAYER_STATS` | Kills, deaths, playtime, blocks, mobs, streaks and money-flow stats |
| `TEAM_DOCUMENTS` | Every team and its members |
| `HOME_DOCUMENTS` | Every saved home |
| `BOUNTIES` | Every active bounty |
| `SELL_DOCUMENTS` | Sell history and sell progress |
| `MONEY` | Resets balances to the configured starting money |
| `SHARDS` | Resets every player's shards to zero |

`{count}` in a button's lore is that target's live record count, read when the menu opens and again
when refresh is clicked, so it previews what the wipe would touch rather than reporting a stored
number.

While a wipe is running the whole button grid is replaced by the `STATUS` icon, which is why that
block sits outside `BUTTONS`. Refresh once it finishes to get the grid back.

### 3. Practical Setup Example

A menu cut down to the two wipes a seasonal reset needs, with the other blocks deleted so nobody
clicks them by accident:

```yaml
STATS-WIPE-MENU:
  TITLE: '&8Season Reset'
  SIZE: 27
  PLACEHOLDER: true
  PLACEHOLDER-MATERIAL: GRAY_STAINED_GLASS_PANE
  BUTTONS:
    PLAYER_STATS:
      SLOT: 11
      MATERIAL: PAPER
      DISPLAY-NAME: '&eReset Stats'
      LORE:
      - '&7Tracked players: &f{count}'
      - '&cCannot be undone.'
    MONEY:
      SLOT: 15
      MATERIAL: GOLD_INGOT
      DISPLAY-NAME: '&eReset Money'
      LORE:
      - '&7Custom balances: &f{count}'
      - '&cCannot be undone.'
    CLOSE:
      SLOT: 26
      MATERIAL: BARRIER
      DISPLAY-NAME: '&cClose'
```

---

## Section: `STATS-WIPE-CONFIRM-MENU`

The second step of a wipe. Clicking any button on `STATS-WIPE-MENU` opens this rather than running
anything, so a wipe always takes two deliberate clicks in two different menus.

### 1. Commented Setup Code Example

```yaml
STATS-WIPE-CONFIRM-MENU:
  TITLE: '&8Confirm {target}'
  SIZE: 27
  PLACEHOLDER: true
  PLACEHOLDER-MATERIAL: BLACK_STAINED_GLASS_PANE
  BUTTONS:
    # What is about to be wiped, and how much of it. Clicking it does nothing.
    TARGET:
      SLOT: 13
      MATERIAL: PAPER
      DISPLAY-NAME: '&#6BF18D{target}'
      LORE:
      - '&7Affected records: &f{count}'
      - '&cThis action cannot be undone.'
    CANCEL:
      SLOT: 11
      MATERIAL: RED_STAINED_GLASS_PANE
      DISPLAY-NAME: '&cCancel'
      LORE:
      - '&7Return to the Stats Wipe menu.'
    CONFIRM:
      SLOT: 15
      MATERIAL: LIME_STAINED_GLASS_PANE
      DISPLAY-NAME: '&aConfirm'
      LORE:
      - '&7Run wipe for &f{target}&7.'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `STATS-WIPE-CONFIRM-MENU.TITLE` | `str` | Any string text | `'&8Confirm {target}'` | Inventory title. |
| `STATS-WIPE-CONFIRM-MENU.SIZE` | `int` | `9`, `18`, `27`, `36`, `45`, `54` | `27` | Inventory size. Anything else falls back to `27`. |
| `STATS-WIPE-CONFIRM-MENU.PLACEHOLDER` | `bool` | `true`, `false` | `true` | Whether the unused slots get filled. |
| `STATS-WIPE-CONFIRM-MENU.PLACEHOLDER-MATERIAL` | `str` | Any valid material name | `BLACK_STAINED_GLASS_PANE` | What fills them. |
| `STATS-WIPE-CONFIRM-MENU.BUTTONS.TARGET` | `section` | `SLOT`, `MATERIAL`, `DISPLAY-NAME`, `LORE` | slot `13` | Summary of what is about to run. Inert on click. |
| `STATS-WIPE-CONFIRM-MENU.BUTTONS.CANCEL` | `section` | `SLOT`, `MATERIAL`, `DISPLAY-NAME`, `LORE` | slot `11` | Goes back to `STATS-WIPE-MENU` without running anything. |
| `STATS-WIPE-CONFIRM-MENU.BUTTONS.CONFIRM` | `section` | `SLOT`, `MATERIAL`, `DISPLAY-NAME`, `LORE` | slot `15` | Runs the wipe. |

Every name and lore here reads two placeholders:

| Placeholder | Replaced with |
| :--- | :--- |
| `{target}` | The readable name of the wipe, such as `player stats` or `player money` |
| `{count}` | How many records the wipe will touch |

Worth resisting the urge to tidy this menu by putting confirm next to cancel. They ship two slots
apart with the summary between them, so a misclick on the way to cancel does not land on confirm. If
you do rearrange it, keep them separated.

### 3. Practical Setup Example

Confirm moved to the far end of the row and dressed as a warning, for admins who want more distance
between the two:

```yaml
STATS-WIPE-CONFIRM-MENU:
  TITLE: '&cConfirm: {target}'
  SIZE: 27
  PLACEHOLDER: true
  PLACEHOLDER-MATERIAL: RED_STAINED_GLASS_PANE
  BUTTONS:
    TARGET:
      SLOT: 13
      MATERIAL: PAPER
      DISPLAY-NAME: '&f{target}'
      LORE:
      - '&7About to delete &f{count} &7records.'
      - '&cThere is no undo.'
    CANCEL:
      SLOT: 9
      MATERIAL: LIME_STAINED_GLASS_PANE
      DISPLAY-NAME: '&aKeep everything'
    CONFIRM:
      SLOT: 17
      MATERIAL: TNT
      DISPLAY-NAME: '&4Wipe {target}'
      LORE:
      - '&7Deletes &f{count} &7records now.'
```

---

## Section: `SERVERS-MENU`

Opened with `/servers`. One icon per server on the network, coloured by whether that server answered
the last status check, with the player count and software read from `network.yml`. The menu redraws
itself while it stays open, and clicking an icon asks for an immediate refresh of that one server.

### 1. Commented Setup Code Example

```yaml
SERVERS-MENU:
  TITLE: '&8Ongoing Servers'
  SIZE: 27
  # How often the open menu redraws, in ticks. Anything under 10 is raised to 10.
  REFRESH-TICKS: 40
  PLACEHOLDER-MATERIAL: BLACK_STAINED_GLASS_PANE
  # One template, reused for every server icon.
  SERVER_STATUS:
    SERVER_NAME: '&b%server%'
    LORE:
    - '&8&m---------------------'
    - '&bStatus: %status%'
    - '&aPlayers: &a%players% online'
    - '&eSoftware: &a%software%'
    - '&6Performance: %performance%'
    - '&8&m---------------------'
    MATERIALS:
      ONLINE: LIME_CONCRETE
      OFFLINE: RED_CONCRETE
  SERVERS:
    # Each key is a server id from network.yml. Add or delete keys freely.
    crystal:
      SLOT: 13
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `SERVERS-MENU.TITLE` | `str` | Any string text | `SERVER_STATUS.TITLE`, then `'&8Ongoing servers'` | Inventory title shown at the top of the menu. |
| `SERVERS-MENU.SIZE` | `int` | `9`, `18`, `27`, `36`, `45`, `54` | `27` | Inventory size. Anything else falls back to `27` with a console warning. |
| `SERVERS-MENU.REFRESH-TICKS` | `int` | `10` or more | `40` | How often the open menu redraws, in ticks. Lower values are raised to `10` so the menu cannot redraw every tick. |
| `SERVERS-MENU.PLACEHOLDER-MATERIAL` | `str` | Any valid material name | `BLACK_STAINED_GLASS_PANE` | Fills every slot no server uses. An invalid name falls back to the default. |
| `SERVERS-MENU.SERVER_STATUS.SERVER_NAME` | `str` | Any string text | `SERVER_STATUS.NAME`, then `'&b%server%'` | Icon name template, applied to every server. |
| `SERVERS-MENU.SERVER_STATUS.LORE` | `list` | List of strings | Built-in six-line block | Icon lore template. An empty list restores the built-in block rather than leaving the lore blank. |
| `SERVERS-MENU.SERVER_STATUS.MATERIALS.ONLINE` | `str` | Any valid material name | `LIME_CONCRETE` | Icon material for a server that answered. Invalid names warn and fall back. |
| `SERVERS-MENU.SERVER_STATUS.MATERIALS.OFFLINE` | `str` | Any valid material name | `RED_CONCRETE` | Icon material for a server that did not answer. Invalid names warn and fall back. |
| `SERVERS-MENU.SERVERS.<ID>.SLOT` | `int` | `0` to `SIZE - 1` | - | Slot that server renders in. Out-of-range and duplicate slots are skipped with a console warning. |

`SERVER_NAME` and `LORE` both understand these placeholders:

| Placeholder | Replaced with |
| :--- | :--- |
| `%server%` | The server's display name from `network.yml` |
| `%status%` | `&aOnline` or `&cOffline` |
| `%players%` | Player count from the last successful check |
| `%software%` | The software label that server reported |
| `%performance%` | The performance label that server reported |
| `%latency%` | Round-trip time in milliseconds |

Server ids should match the keys under `NETWORK-STATUS.SERVERS` in `network.yml`. An id with no entry
there still draws, permanently offline, and clicking it answers that the server is not configured in
`network.yml`. Leave `SERVERS` out altogether and the menu places every server from `network.yml`
itself, filling the inner area of the inventory in the order they are listed. Deleting or renaming an
entry sticks, so the bundled `crystal` does not come back on the next start.

`/servers` needs three things on: `COMMANDS.SERVERS` in `config.yml`, the network status feature in
`network.yml`, and at least one server that resolves to a slot. Miss any of them and the command says
which.

### 3. Practical Setup Example

A four-server network on one row, with a shorter icon:

```yaml
SERVERS-MENU:
  TITLE: '&8Network'
  SIZE: 27
  REFRESH-TICKS: 20
  SERVER_STATUS:
    SERVER_NAME: '&b%server% &8(%latency%ms)'
    LORE:
    - '&bStatus: %status%'
    - '&aPlayers: &a%players% online'
    MATERIALS:
      ONLINE: LIME_CONCRETE
      OFFLINE: GRAY_CONCRETE
  SERVERS:
    survival:
      SLOT: 10
    creative:
      SLOT: 12
    skyblock:
      SLOT: 14
    events:
      SLOT: 16
```

---

## Section: `SPAWNER-MENUS`

The spawner GUIs, all six of them under one heading because they are one flow: the main menu for a
placed spawner, its storage list, the filter screen, the sell confirmation, and the two panel views
that list spawners across a world. Each sub-menu is its own block with its own title and size.

### 1. Commented Setup Code Example

```yaml
SPAWNER-MENUS:
  MAIN-MENU:
    TITLE: '{stack} {mob}'
    SIZE: 27
    FILLER-MATERIAL: GRAY_STAINED_GLASS_PANE
    STORAGE-BUTTON:
      SLOT: 11
      MATERIAL: CHEST
    MOB-HEAD-BUTTON:
      SLOT: 13
    COLLECT-XP-BUTTON:
      SLOT: 15
      MATERIAL: EXPERIENCE_BOTTLE
  STORAGE-MENU:
    TITLE: '&8{mob} Spawners - {page}/{max_page}'
    SIZE: 54
    # Clamped between 9 and SIZE minus 9, so the button row always survives.
    ITEMS-PER-PAGE: 45
    BACK-BUTTON:
      SLOT: 45
    COLLECT-ALL-BUTTON:
      SLOT: 49
    SELL-ALL-BUTTON:
      SLOT: 53
  FILTER-MENU:
    TITLE: '&8{mob} Filter Settings'
    SIZE: 27
  SELL-CONFIRM-MENU:
    TITLE: '&8Confirm Sell'
    SIZE: 27
  # Both panel views ship with a title and a size only.
  PANEL-MENU:
    TITLE: '&8Spawners'
    SIZE: 54
  WORLD-LIST-MENU:
    TITLE: '&8Spawners Panel'
    SIZE: 27
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `SPAWNER-MENUS.MAIN-MENU.TITLE` | `str` | Any string text | `'{stack} {mob}'` | Title of the menu a placed spawner opens. |
| `SPAWNER-MENUS.MAIN-MENU.SIZE` | `int` | `9` to `54` | `27` | Rounds up to the next multiple of nine and caps at `54`. |
| `SPAWNER-MENUS.MAIN-MENU.FILLER-MATERIAL` | `str` | Any valid material name | `GRAY_STAINED_GLASS_PANE` | Fills the unused slots. |
| `SPAWNER-MENUS.MAIN-MENU.STORAGE-BUTTON` | `section` | `SLOT`, `MATERIAL`, `TITLE`, `LORE` | slot `11` | Opens the storage list. |
| `SPAWNER-MENUS.MAIN-MENU.MOB-HEAD-BUTTON` | `section` | `SLOT`, `TITLE`, `LORE` | slot `13` | The spawner's own mob, shown as a head. |
| `SPAWNER-MENUS.MAIN-MENU.COLLECT-XP-BUTTON` | `section` | `SLOT`, `MATERIAL`, `TITLE`, `LORE` | slot `15` | Collects banked experience. |
| `SPAWNER-MENUS.STORAGE-MENU.TITLE` | `str` | Any string text | `'&8{mob} spawners - {page}/{max_page}'` | Title of the storage list. |
| `SPAWNER-MENUS.STORAGE-MENU.SIZE` | `int` | `9` to `54` | `54` | Rounds up to the next multiple of nine, capped at `54`. |
| `SPAWNER-MENUS.STORAGE-MENU.ITEMS-PER-PAGE` | `int` | `9` to `SIZE - 9` | `45` | Loot slots per page. Values outside the range are pulled into it, so the bottom button row can never be swallowed. |
| `SPAWNER-MENUS.STORAGE-MENU.ITEM-META` | `section` | `TITLE`, `LORE` | - | Template applied to each stored loot stack. |
| `SPAWNER-MENUS.STORAGE-MENU.BACK-BUTTON` | `section` | `SLOT`, `MATERIAL`, `TITLE`, `LORE` | slot `45` | Back to the main menu. |
| `SPAWNER-MENUS.STORAGE-MENU.FILTER-SETTINGS-BUTTON` | `section` | `SLOT`, `MATERIAL`, `TITLE`, `LORE` | - | Opens the filter menu. |
| `SPAWNER-MENUS.STORAGE-MENU.COLLECT-ALL-BUTTON` | `section` | `SLOT`, `MATERIAL`, `TITLE`, `LORE` | slot `49` | Takes everything stored. |
| `SPAWNER-MENUS.STORAGE-MENU.PREVIOUS-PAGE-BUTTON` | `section` | `SLOT`, `MATERIAL`, `TITLE`, `LORE` | - | Previous page of loot. |
| `SPAWNER-MENUS.STORAGE-MENU.NEXT-PAGE-BUTTON` | `section` | `SLOT`, `MATERIAL`, `TITLE`, `LORE` | - | Next page of loot. |
| `SPAWNER-MENUS.STORAGE-MENU.DROP-LOOT-BUTTON` | `section` | `SLOT`, `MATERIAL`, `TITLE`, `LORE` | - | Drops the stored loot on the floor. |
| `SPAWNER-MENUS.STORAGE-MENU.SELL-ALL-BUTTON` | `section` | `SLOT`, `MATERIAL`, `TITLE`, `LORE` | slot `53` | Sends the stored loot to the sell confirmation. |
| `SPAWNER-MENUS.FILTER-MENU.TITLE` | `str` | Any string text | `'&8{mob} filter settings'` | Title of the filter screen. |
| `SPAWNER-MENUS.FILTER-MENU.SIZE` | `int` | `9` to `54` | `27` | Size of the filter screen. |
| `SPAWNER-MENUS.FILTER-MENU.ENABLE-ALL-BUTTON` | `section` | `SLOT`, `MATERIAL`, `TITLE`, `LORE` | - | Turns every loot type on. |
| `SPAWNER-MENUS.FILTER-MENU.DISABLE-ALL-BUTTON` | `section` | `SLOT`, `MATERIAL`, `TITLE`, `LORE` | - | Turns every loot type off. |
| `SPAWNER-MENUS.SELL-CONFIRM-MENU.TITLE` | `str` | Any string text | `'&8Confirm sell'` | Title of the sell confirmation. |
| `SPAWNER-MENUS.SELL-CONFIRM-MENU.SIZE` | `int` | `9` to `54` | `27` | Size of the sell confirmation. |
| `SPAWNER-MENUS.PANEL-MENU.TITLE` | `str` | Any string text | `'&8Spawners'` | Title of the per-world spawner panel. |
| `SPAWNER-MENUS.PANEL-MENU.SIZE` | `int` | `9` to `54` | `54` | Size of that panel. |
| `SPAWNER-MENUS.WORLD-LIST-MENU.TITLE` | `str` | Any string text | `'&8Spawners panel'` | Title of the world picker. |
| `SPAWNER-MENUS.WORLD-LIST-MENU.SIZE` | `int` | `9` to `54` | `27` | Size of the world picker. |

Titles across these menus read the spawner they belong to:

| Placeholder | Replaced with |
| :--- | :--- |
| `{mob}` | The spawner's mob |
| `{stack}` | How many spawners are stacked there |
| `{page}`, `{max_page}` | Position in the storage list |
| `{price}`, `{item_count}` | Sell total and item count, on the sell confirmation |

Sizes here behave like the spawn and AFK menus rather than the rest of the file: a size that is not a
multiple of nine rounds **up** instead of falling back, so `30` becomes `36`.

One thing to know before editing anything: every title and size in this section has a second home.
`spawners.yml` still ships a `GUI` block with `MAIN_MENU`, `STORAGE`, `PANEL` and `WORLD_LIST`
entries, and the plugin only reads those when the matching `SPAWNER-MENUS` key is absent here. Since
`menus.yml` ships all of them, editing `spawners.yml` has no visible effect. Change them here.

`PANEL-MENU` and `WORLD-LIST-MENU` ship with a title and a size only; their contents are the spawners
and worlds themselves, laid out by the plugin, so there is nothing else to configure.

### 3. Practical Setup Example

A smaller storage list, which suits servers that cap spawner stacks low:

```yaml
SPAWNER-MENUS:
  MAIN-MENU:
    TITLE: '&8{stack}x {mob}'
    SIZE: 27
    FILLER-MATERIAL: BLACK_STAINED_GLASS_PANE
  STORAGE-MENU:
    TITLE: '&8{mob} &7({page}/{max_page})'
    SIZE: 36
    # 36 minus 9 leaves 27 as the ceiling here.
    ITEMS-PER-PAGE: 27
    BACK-BUTTON:
      SLOT: 27
    COLLECT-ALL-BUTTON:
      SLOT: 31
    SELL-ALL-BUTTON:
      SLOT: 35
```

Dropping `SIZE` to `36` moves the button row to slots 27 through 35, so the buttons have to move with
it. Asking for `ITEMS-PER-PAGE: 45` on a 36-slot menu would simply be clamped back to 27.

---


## Section: `VOICE-CHAT-CONSENT-MENU`

The consent prompt. It opens on its own when an undecided player joins, and `/voicechatconsent`
reopens it later. Clicking confirm lets the player transmit on Simple Voice Chat; clicking decline
records the refusal and leaves their microphone gated. Anything the player is meant to have read
before agreeing belongs in `INFO-BUTTON.LORE`, and the shipped wording is a starting point rather
than a policy anyone has cleared for your server.

### 1. Commented Setup Code Example

```yaml
VOICE-CHAT-CONSENT-MENU:
  TITLE: '&8Confirm Voice Chat'
  SIZE: 27
  INFO-BUTTON:
    DISPLAY-NAME: '&bVoice Chat Policy'
    MATERIAL: JUKEBOX
    SLOT: 13
    LORE:
    - '&7Your voice is recorded while you are'
    - '&7talking in a voice channel.'
    - ''
    - '&7Recordings are thrown away unless somebody'
    - '&7reports you. A reported recording is kept'
    - '&7as proof for a mute or a ban, and the'
    - '&7moderation team reviews it.'
    - ''
    - '&7You have to be 13 or older to talk.'
    - ''
    - '&7Changed your mind later? Run'
    - '&f/voicechatconsent revoke'
  CONFIRM-BUTTON:
    DISPLAY-NAME: '&aConfirm'
    MATERIAL: LIME_STAINED_GLASS_PANE
    SLOT: 11
    LORE:
    - '&fClick to turn voice chat on'
  DECLINE-BUTTON:
    DISPLAY-NAME: '&cDecline'
    MATERIAL: RED_STAINED_GLASS_PANE
    SLOT: 15
    LORE:
    - '&fVoice chat will stay disabled'
```

### 2. Key Options & Technical Breakdown

| Option / Key Path | Data Type | Allowed Values | Default | Technical Function & Setup Guide |
| :--- | :--- | :--- | :--- | :--- |
| `VOICE-CHAT-CONSENT-MENU.TITLE` | `str` | Any string text | `'&8Confirm Voice Chat'` | Inventory title of the consent prompt. |
| `VOICE-CHAT-CONSENT-MENU.SIZE` | `int` | Any valid integer number | `'27'` | Inventory size in slots. Keep it a multiple of nine and large enough for the three slots below. |
| `VOICE-CHAT-CONSENT-MENU.INFO-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&bVoice Chat Policy'` | Name of the item holding the policy. |
| `VOICE-CHAT-CONSENT-MENU.INFO-BUTTON.MATERIAL` | `str` | Any string text | `'JUKEBOX'` | Item shown for the policy. Any material name works. |
| `VOICE-CHAT-CONSENT-MENU.INFO-BUTTON.SLOT` | `int` | Any valid integer number | `'13'` | Slot the policy item sits in. Clicking it does nothing on purpose, so a misclick cannot answer for the player. |
| `VOICE-CHAT-CONSENT-MENU.INFO-BUTTON.LORE` | `list` | List of configured items/strings | See the example above | The policy itself. Write what your server actually records, how long it keeps it, and who reads it. Add a line pointing at your own privacy page if you have one. |
| `VOICE-CHAT-CONSENT-MENU.CONFIRM-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&aConfirm'` | Name of the accept button. |
| `VOICE-CHAT-CONSENT-MENU.CONFIRM-BUTTON.MATERIAL` | `str` | Any string text | `'LIME_STAINED_GLASS_PANE'` | Item used for the accept button. |
| `VOICE-CHAT-CONSENT-MENU.CONFIRM-BUTTON.SLOT` | `int` | Any valid integer number | `'11'` | Slot of the accept button. Clicking here records agreement and opens the microphone. |
| `VOICE-CHAT-CONSENT-MENU.CONFIRM-BUTTON.LORE` | `list` | List of configured items/strings | `['&fClick to turn voice chat on']` | Lore under the accept button. |
| `VOICE-CHAT-CONSENT-MENU.DECLINE-BUTTON.DISPLAY-NAME` | `str` | Any string text | `'&cDecline'` | Name of the decline button. |
| `VOICE-CHAT-CONSENT-MENU.DECLINE-BUTTON.MATERIAL` | `str` | Any string text | `'RED_STAINED_GLASS_PANE'` | Item used for the decline button. |
| `VOICE-CHAT-CONSENT-MENU.DECLINE-BUTTON.SLOT` | `int` | Any valid integer number | `'15'` | Slot of the decline button. Clicking here records the refusal, and the prompt stops appearing on later joins. |
| `VOICE-CHAT-CONSENT-MENU.DECLINE-BUTTON.LORE` | `list` | List of configured items/strings | `['&fVoice chat will stay disabled']` | Lore under the decline button. |

A player who closes the menu without clicking either button stays undecided, so the prompt comes
back the next time they join.

---
