package com.bx.ultimateDonutSmp.managers;

import com.bx.ultimateDonutSmp.UltimateDonutSmp;
import com.bx.ultimateDonutSmp.models.PlayerData;
import com.bx.ultimateDonutSmp.models.SellCategory;
import com.bx.ultimateDonutSmp.models.WorthResult;
import com.bx.ultimateDonutSmp.utils.ColorUtils;
import com.bx.ultimateDonutSmp.utils.NumberUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionType;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class WorthManager {

    private static final String NULL_LORE = "__NULL__";
    private static final String LORE_SEPARATOR = ";";
    private static final Set<Material> FISH_CATEGORY_OVERRIDES = EnumSet.of(
            Material.COD,
            Material.COOKED_COD,
            Material.SALMON,
            Material.COOKED_SALMON,
            Material.TROPICAL_FISH,
            Material.PUFFERFISH,
            Material.COD_BUCKET,
            Material.SALMON_BUCKET,
            Material.TROPICAL_FISH_BUCKET,
            Material.PUFFERFISH_BUCKET,
            Material.AXOLOTL_BUCKET,
            Material.TADPOLE_BUCKET,
            Material.FISHING_ROD,
            Material.NAME_TAG,
            Material.NAUTILUS_SHELL,
            Material.LILY_PAD,
            Material.HEART_OF_THE_SEA
    );
    private static final Set<Material> POTION_CATEGORY_OVERRIDES = EnumSet.of(
            Material.POTION,
            Material.SPLASH_POTION,
            Material.LINGERING_POTION,
            Material.TIPPED_ARROW,
            Material.BREWING_STAND,
            Material.BLAZE_POWDER,
            Material.BLAZE_ROD,
            Material.FERMENTED_SPIDER_EYE,
            Material.GLASS_BOTTLE,
            Material.GLISTERING_MELON_SLICE,
            Material.GHAST_TEAR,
            Material.MAGMA_CREAM,
            Material.RABBIT_FOOT,
            Material.SPIDER_EYE,
            Material.SUGAR,
            Material.GOLDEN_CARROT,
            Material.PHANTOM_MEMBRANE
    );

    public record WorthBrowserEntry(
            Material material,
            String categoryKey,
            double unitWorth,
            String sourceKey
    ) {}

    public record SellWorthEntry(
            Material material,
            int amount,
            double totalWorth,
            SellCategory category
    ) {}

    private record DirectWorthData(
            double worth,
            String sourceKey,
            String categoryKey,
            String resolutionType
    ) {}

    private final UltimateDonutSmp plugin;
    private final NamespacedKey worthDisplayAppliedKey;
    private final NamespacedKey worthDisplayOriginalLoreKey;

    private List<WorthBrowserEntry> browserEntriesCache = Collections.emptyList();
    private boolean browserEntriesLoaded;

    private final java.util.Map<WorthCacheKey, DirectWorthData> directWorthCache = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Map<String, Double> enchantmentWorthCache = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Map<WorthCacheKey, java.util.Optional<SellCategory>> sellCategoryCache = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Set<Material> blockedMaterialsCache = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private boolean blockedMaterialsLoaded = false;
    private volatile boolean packetDisplayActive = false;

    private static final DirectWorthData NULL_DIRECT_WORTH = new DirectWorthData(-1.0, "", "", "");

    private record WorthCacheKey(
            Material material,
            PotionType potionType,
            java.util.Map<Enchantment, java.lang.Integer> enchantments
    ) {
        public static WorthCacheKey of(ItemStack item) {
            if (item == null) {
                return new WorthCacheKey(null, null, java.util.Collections.emptyMap());
            }
            PotionType potionType = null;
            if (item.getItemMeta() instanceof PotionMeta meta) {
                potionType = meta.getBasePotionType();
            }
            java.util.Map<Enchantment, java.lang.Integer> enchants = java.util.Collections.emptyMap();
            if (item.getType() == Material.ENCHANTED_BOOK) {
                if (item.getItemMeta() instanceof EnchantmentStorageMeta meta) {
                    enchants = meta.getStoredEnchants();
                }
            } else {
                enchants = item.getEnchantments();
            }
            return new WorthCacheKey(item.getType(), potionType, enchants);
        }
    }

    public WorthManager(UltimateDonutSmp plugin) {
        this.plugin = plugin;
        this.worthDisplayAppliedKey = new NamespacedKey(plugin, "worth_display_applied");
        this.worthDisplayOriginalLoreKey = new NamespacedKey(plugin, "worth_display_original_lore");
    }

    public void reload() {
        browserEntriesCache = Collections.emptyList();
        browserEntriesLoaded = false;
        directWorthCache.clear();
        enchantmentWorthCache.clear();
        sellCategoryCache.clear();
        blockedMaterialsCache.clear();
        blockedMaterialsLoaded = false;
    }

    // flipping WORTH-LORE.ENABLED otherwise only reaches a player once they next touch an item,
    // so a config reload pushes the new answer out to everyone already on the server
    public void resyncOnlineWorthDisplays() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            syncWorthDisplay(player, true);
        }
    }

    // toggled on at startup when the packet display is active, so worth is rendered per packet only
    public void setPacketDisplayActive(boolean active) {
        this.packetDisplayActive = active;
    }

    public double getWorth(Material material) {
        if (material == null || material.isAir()) {
            return -1;
        }

        return getWorth(new ItemStack(material));
    }

    // the price before the farming meta multiplier, for callers that need to show both
    public double getBaseWorth(Material material) {
        if (material == null || material.isAir()) {
            return -1;
        }

        DirectWorthData data = resolveBaseDirectWorth(new ItemStack(material));
        return data == null ? -1 : data.worth();
    }

    public double getWorth(ItemStack item) {
        DirectWorthData data = resolveDirectWorth(item);
        return data == null ? -1 : data.worth();
    }

    public WorthResult resolveWorth(ItemStack item) {
        return resolveWorth(item, 0, true, new HashSet<>());
    }

    public List<SellWorthEntry> resolveSellWorthEntries(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return List.of();
        }

        List<SellWorthEntry> entries = new ArrayList<>();
        collectSellWorthEntries(item, 1, 0, true, new HashSet<>(), entries);
        return List.copyOf(entries);
    }

    public SellCategory getSellCategory(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return null;
        }
        if (isBlockedItem(item)) {
            return null;
        }

        WorthCacheKey cacheKey = WorthCacheKey.of(item);
        java.util.Optional<SellCategory> cached = sellCategoryCache.get(cacheKey);
        if (cached != null) {
            return cached.orElse(null);
        }

        SellCategory resolved = getSellCategoryNoCache(item);
        sellCategoryCache.put(cacheKey, java.util.Optional.ofNullable(resolved));
        return resolved;
    }

    private SellCategory getSellCategoryNoCache(ItemStack item) {
        Material material = item.getType();
        if (FISH_CATEGORY_OVERRIDES.contains(material)) {
            return SellCategory.FISH;
        }
        if (POTION_CATEGORY_OVERRIDES.contains(material)) {
            return SellCategory.POTIONS;
        }

        ConfigurationSection typedValues = plugin.getConfigManager().getWorth().getConfigurationSection("TYPE");
        if (typedValues == null) {
            return null;
        }

        for (SellCategory category : SellCategory.values()) {
            ConfigurationSection categorySection = typedValues.getConfigurationSection(category.getWorthSectionKey());
            if (categorySection == null) {
                continue;
            }
            DirectWorthData directWorth = findWorthRecursively(categorySection, item, category.getWorthSectionKey());
            if (directWorth != null) {
                return category;
            }
        }

        return null;
    }

    public List<WorthBrowserEntry> getBrowserEntries() {
        if (browserEntriesLoaded) {
            return browserEntriesCache;
        }

        FileConfiguration worthConfig = plugin.getConfigManager().getWorth();
        ConfigurationSection typedValues = worthConfig.getConfigurationSection("TYPE");
        if (typedValues == null) {
            browserEntriesCache = List.of();
            browserEntriesLoaded = true;
            return browserEntriesCache;
        }

        List<String> configuredOrder = worthConfig.getStringList("BROWSER.CATEGORY-SORT");
        List<String> categoryOrder = new ArrayList<>();
        if (!configuredOrder.isEmpty()) {
            categoryOrder.addAll(configuredOrder);
        }
        for (String categoryKey : typedValues.getKeys(false)) {
            if (!categoryOrder.contains(categoryKey)) {
                categoryOrder.add(categoryKey);
            }
        }

        List<WorthBrowserEntry> entries = new ArrayList<>();
        Set<Material> seenMaterials = new HashSet<>();
        for (String categoryKey : categoryOrder) {
            ConfigurationSection categorySection = typedValues.getConfigurationSection(categoryKey);
            if (categorySection == null) {
                continue;
            }

            for (String key : categorySection.getKeys(false)) {
                if (categorySection.isConfigurationSection(key) || key.contains(":")) {
                    continue;
                }

                Material material = matchMaterial(key);
                if (material == null || material.isAir() || isBlockedMaterial(material) || !seenMaterials.add(material)) {
                    continue;
                }

                double unitWorth = categorySection.getDouble(key, -1);
                if (unitWorth < 0) {
                    continue;
                }

                entries.add(new WorthBrowserEntry(
                        material,
                        categoryKey,
                        unitWorth * getMetaMultiplier(material),
                        key
                ));
            }
        }

        browserEntriesCache = List.copyOf(entries);
        browserEntriesLoaded = true;
        return browserEntriesCache;
    }

    public String getBrowserTitle() {
        return plugin.getConfigManager().getWorth().getString("BROWSER.TITLE", "&8item prices");
    }

    public int getBrowserSize() {
        int configured = plugin.getConfigManager().getWorth().getInt("BROWSER.SIZE", 54);
        if (configured < 18 || configured > 54 || configured % 9 != 0) {
            return 54;
        }
        return configured;
    }

    public int getBrowserItemsPerPage() {
        int inventorySize = getBrowserSize();
        int configured = plugin.getConfigManager().getWorth().getInt("BROWSER.ITEMS-PER-PAGE", inventorySize - 9);
        int maxAllowed = Math.max(9, inventorySize - 9);
        return Math.max(9, Math.min(maxAllowed, configured));
    }

    public void syncWorthDisplay(Player player) {
        syncWorthDisplay(player, false);
    }

    public void syncWorthDisplay(Player player, boolean forceUpdate) {
        boolean enabled = isWorthDisplayEnabled(player);

        syncInventoryWorthDisplay(player.getInventory(), enabled);

        ItemStack cursor = player.getItemOnCursor();
        ItemStack updatedCursor = updateWorthDisplay(cursor, enabled);
        if (updatedCursor != cursor) {
            player.setItemOnCursor(updatedCursor);
        }

        if (player.isOnline() && shouldUpdateInventory(player, forceUpdate)) {
            player.updateInventory();
        }
    }

    public void syncWorthDisplay(Player player, Inventory inventory) {
        syncWorthDisplay(player, inventory, false);
    }

    public void syncWorthDisplay(Player player, Inventory inventory, boolean forceUpdate) {
        if (player == null) {
            return;
        }

        syncInventoryWorthDisplay(inventory, isWorthDisplayEnabled(player));

        if (player.isOnline() && shouldUpdateInventory(player, forceUpdate)) {
            player.updateInventory();
        }
    }

    private boolean shouldUpdateInventory(Player player) {
        return shouldUpdateInventory(player, false);
    }

    private boolean shouldUpdateInventory(Player player, boolean forceUpdate) {
        if (player == null || !player.isOnline()) {
            return false;
        }

        Inventory topInventory = player.getOpenInventory().getTopInventory();
        if (topInventory == null) {
            return true;
        }

        InventoryType type = topInventory.getType();
        if (holdsClientState(type)) {
            return false;
        }

        if (forceUpdate) {
            return true;
        }

        return type != InventoryType.CRAFTING && type != InventoryType.CREATIVE;
    }

    // Resending the whole window is safe on a chest, but these screens carry state the server never
    // sent the client - the three enchantment offers, a half-typed anvil name, a picked recipe. A
    // resync drops it. Java quietly redraws, Geyser does not, so a Bedrock player watches the
    // enchantment offers vanish the moment the item lands in the slot. Kept as a switch rather than
    // a constant set so nothing here touches the InventoryType registry before the server is up.
    public static boolean holdsClientState(InventoryType type) {
        if (type == null) {
            return false;
        }

        switch (type) {
            case WORKBENCH:
            case ANVIL:
            case SMITHING:
            case GRINDSTONE:
            case STONECUTTER:
            case CARTOGRAPHY:
            case LOOM:
            case ENCHANTING:
            case MERCHANT:
            case BEACON:
                return true;
            default:
                return false;
        }
    }

    public boolean canResendOpenInventory(Player player) {
        return shouldUpdateInventory(player, true);
    }

    public ItemStack applyWorthDisplayForPlayer(Player player, ItemStack item) {
        if (player == null) {
            return item;
        }
        return updateWorthDisplay(item, isWorthDisplayEnabled(player));
    }

    // the server wide switch. off means nobody sees the line, whatever they picked in /settings
    public boolean isWorthLoreEnabled() {
        return plugin.getConfigManager().getConfig().getBoolean("WORTH-LORE.ENABLED", true);
    }

    public boolean isWorthDisplayEnabledFor(Player player) {
        return isWorthDisplayEnabled(player);
    }

    public ItemStack renderClientWorthDisplay(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return item;
        }
        if (isWorthDisplayExcluded(item)) {
            return item;
        }
        String loreLine = getWorthLoreLine(item);
        if (loreLine == null || loreLine.isBlank()) {
            return item;
        }
        ItemStack clone = item.clone();
        ItemMeta meta = clone.getItemMeta();
        if (meta == null) {
            return item;
        }
        List<String> base = stripExistingWorthLore(meta.getLore());
        List<String> desired = base == null ? new ArrayList<>() : new ArrayList<>(base);
        desired.add(ColorUtils.toComponent(loreLine));
        meta.setLore(desired);
        clone.setItemMeta(meta);
        return clone;
    }

    public boolean stripStorageWorthDisplayForNativePickup(Player player, ItemStack... contextItems) {
        if (player == null) {
            return false;
        }

        boolean modified = false;
        Inventory inventory = player.getInventory();
        ItemStack[] storage = inventory.getStorageContents();

        Set<Material> targetMaterials = new HashSet<>();
        if (contextItems != null) {
            for (ItemStack item : contextItems) {
                if (item != null && !item.getType().isAir()) {
                    targetMaterials.add(item.getType());
                }
            }
        }

        for (int slot = 0; slot < storage.length; slot++) {
            ItemStack current = storage[slot];
            if (current == null || current.getType().isAir()) {
                continue;
            }

            if (current.getMaxStackSize() <= 1) {
                continue;
            }

            if (!targetMaterials.isEmpty() && !targetMaterials.contains(current.getType())) {
                continue;
            }

            ItemStack stripped = stripWorthDisplay(current);
            if (stripped != current) {
                storage[slot] = stripped;
                inventory.setItem(slot, stripped);
                modified = true;
            }
        }
        return modified;
    }

    public void mergeStorageStacksForNativeBehavior(Player player) {
        Inventory inventory = player.getInventory();
        ItemStack[] storage = inventory.getStorageContents();

        for (int slot = 0; slot < storage.length; slot++) {
            ItemStack current = storage[slot];
            ItemStack stripped = stripWorthDisplay(current);
            if (stripped != current) {
                storage[slot] = stripped;
                inventory.setItem(slot, stripped);
            }
        }

        mergePlayerStorageStacks(player);
    }

    public void clearWorthDisplay(Player player) {
        Inventory inventory = player.getInventory();
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack current = inventory.getItem(slot);
            ItemStack stripped = stripWorthDisplay(current);
            if (stripped != current) {
                inventory.setItem(slot, stripped);
            }
        }

        ItemStack cursor = player.getItemOnCursor();
        ItemStack strippedCursor = stripWorthDisplay(cursor);
        if (strippedCursor != cursor) {
            player.setItemOnCursor(strippedCursor);
        }

        if (shouldUpdateInventory(player)) {
            player.updateInventory();
        }
    }

    public void sanitizeInventory(Inventory inventory) {
        if (inventory == null) {
            return;
        }

        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack current = inventory.getItem(slot);
            ItemStack stripped = stripWorthDisplay(current);
            if (stripped != current) {
                inventory.setItem(slot, stripped);
            }
        }
    }

    private void syncInventoryWorthDisplay(Inventory inventory, boolean enabled) {
        if (inventory == null) {
            return;
        }

        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack current = inventory.getItem(slot);
            ItemStack updated = updateWorthDisplay(current, enabled);
            if (updated != current) {
                inventory.setItem(slot, updated);
            }
        }
    }

    public boolean isSimilarIgnoringWorth(ItemStack a, ItemStack b) {
        if (a == null || b == null) {
            return a == b;
        }
        if (a.getType() != b.getType()) {
            return false;
        }
        ItemStack strippedA = stripWorthDisplay(a);
        ItemStack strippedB = stripWorthDisplay(b);
        return strippedA.isSimilar(strippedB);
    }

    public ItemStack stripWorthDisplay(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return item;
        }

        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        PersistentDataContainer container = meta.getPersistentDataContainer();
        boolean hasTag = container != null && container.has(worthDisplayAppliedKey, PersistentDataType.BYTE);
        List<String> currentLore = meta.getLore();
        List<String> strippedLore = stripExistingWorthLore(readOriginalLore(meta));

        if (!hasTag && (currentLore == null || Objects.equals(currentLore, strippedLore))) {
            return item;
        }

        ItemStack updated = item.clone();
        ItemMeta updatedMeta = updated.getItemMeta();
        if (updatedMeta == null) {
            return item;
        }

        PersistentDataContainer updatedContainer = updatedMeta.getPersistentDataContainer();
        if (updatedContainer != null) {
            updatedContainer.remove(worthDisplayAppliedKey);
            updatedContainer.remove(worthDisplayOriginalLoreKey);
        }
        updatedMeta.setLore(strippedLore == null || strippedLore.isEmpty() ? null : strippedLore);
        updated.setItemMeta(updatedMeta);
        return updated;
    }

    public String getWorthLoreLine(ItemStack item) {
        WorthResult worthResult = resolveWorth(item);
        if (!worthResult.sellable()) {
            return null;
        }

        String itemName = prettifyMaterial(item == null ? null : item.getType());
        double displayWorth = getDisplayWorth(worthResult);
        return replaceWorthPlaceholders(
                getWorthLoreFormat(),
                plugin.getCurrencyManager().formatCompactAmount(CurrencyManager.CurrencyType.MONEY, displayWorth),
                plugin.getCurrencyManager().formatCompactAmount(CurrencyManager.CurrencyType.MONEY, worthResult.unitWorth()),
                String.valueOf(item == null ? 0 : item.getAmount()),
                itemName,
                plugin.getCurrencyManager().formatMoney(displayWorth),
                plugin.getCurrencyManager().formatMoney(worthResult.unitWorth())
        );
    }

    public String prettifyMaterial(Material material) {
        if (material == null) {
            return "unknown";
        }

        String[] tokens = material.name().toLowerCase(Locale.US).split("_");
        StringBuilder builder = new StringBuilder();
        for (String token : tokens) {
            if (token.isEmpty()) {
                continue;
            }
            if (!builder.isEmpty()) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(token.charAt(0))).append(token.substring(1));
        }
        return builder.toString();
    }

    private WorthResult resolveWorth(ItemStack item, int depth, boolean allowNestedExpansion, Set<Integer> visitedContainers) {
        if (item == null || item.getType().isAir()) {
            return WorthResult.unsellable();
        }
        if (isBlockedItem(item)) {
            return WorthResult.unsellable();
        }
        if (isUnpricedFullContainer(item, depth, allowNestedExpansion)) {
            return WorthResult.unsellable();
        }

        DirectWorthData directWorth = resolveDirectWorth(item);
        if (isContainerWorthEnabled()
                && allowNestedExpansion
                && isSupportedContainer(item)
                && depth < getMaxContainerDepth()) {
            double contentsWorth = resolveContainerContentsWorth(item, depth + 1, allowNestedExpansion, visitedContainers);
            if (contentsWorth > 0) {
                double baseWorth = directWorth == null ? 0 : directWorth.worth();
                double totalUnitWorth = contentsWorth + (shouldIncludeContainerBasePrice() ? baseWorth : 0);
                if (totalUnitWorth > 0) {
                    return new WorthResult(
                            true,
                            true,
                            totalUnitWorth,
                            totalUnitWorth * item.getAmount(),
                            baseWorth,
                            contentsWorth,
                            "container",
                            item.getType().name(),
                            directWorth == null ? "" : directWorth.categoryKey()
                    );
                }
            }
        }

        if (directWorth == null) {
            return WorthResult.unsellable();
        }

        return new WorthResult(
                true,
                false,
                directWorth.worth(),
                directWorth.worth() * item.getAmount(),
                directWorth.worth(),
                0,
                directWorth.resolutionType(),
                directWorth.sourceKey(),
                directWorth.categoryKey()
        );
    }

    private double resolveContainerContentsWorth(
            ItemStack item,
            int depth,
            boolean allowNestedExpansion,
            Set<Integer> visitedContainers
    ) {
        if (!(item.getItemMeta() instanceof BlockStateMeta blockStateMeta)) {
            return 0;
        }

        BlockState blockState = blockStateMeta.getBlockState();
        if (!(blockState instanceof Container container)) {
            return 0;
        }

        int containerIdentity = buildContainerIdentity(item);
        if (!visitedContainers.add(containerIdentity)) {
            return 0;
        }

        try {
            double total = 0;
            for (ItemStack content : container.getInventory().getContents()) {
                if (content == null || content.getType().isAir()) {
                    continue;
                }

                WorthResult contentWorth = resolveWorth(
                        content,
                        depth,
                        allowNestedExpansion && allowNestedContainers(),
                        visitedContainers
                );
                if (contentWorth.sellable()) {
                    total += contentWorth.totalWorth();
                }
            }
            return total;
        } finally {
            visitedContainers.remove(containerIdentity);
        }
    }

    private void collectSellWorthEntries(
            ItemStack item,
            int amountMultiplier,
            int depth,
            boolean allowNestedExpansion,
            Set<Integer> visitedContainers,
            List<SellWorthEntry> entries
    ) {
        if (item == null || item.getType().isAir() || amountMultiplier <= 0) {
            return;
        }
        if (isBlockedItem(item)) {
            return;
        }
        if (isUnpricedFullContainer(item, depth, allowNestedExpansion)) {
            return;
        }

        boolean container = isSupportedContainer(item);
        DirectWorthData directWorth = resolveDirectWorth(item);
        if (directWorth != null
                && (!container || !isContainerWorthEnabled() || shouldIncludeContainerBasePrice())) {
            SellCategory category = resolveSellCategory(directWorth, item);
            if (category != null && directWorth.worth() > 0) {
                int amount = multiplyAmount(item.getAmount(), amountMultiplier);
                entries.add(new SellWorthEntry(
                        item.getType(),
                        amount,
                        directWorth.worth() * item.getAmount() * amountMultiplier,
                        category
                ));
            }
        }

        if (!isContainerWorthEnabled()
                || !container
                || !allowNestedExpansion
                || depth >= getMaxContainerDepth()) {
            return;
        }

        collectContainerSellWorthEntries(
                item,
                multiplyAmount(item.getAmount(), amountMultiplier),
                depth + 1,
                allowNestedExpansion && allowNestedContainers(),
                visitedContainers,
                entries
        );
    }

    private void collectContainerSellWorthEntries(
            ItemStack item,
            int amountMultiplier,
            int depth,
            boolean allowNestedExpansion,
            Set<Integer> visitedContainers,
            List<SellWorthEntry> entries
    ) {
        if (!(item.getItemMeta() instanceof BlockStateMeta blockStateMeta)) {
            return;
        }

        BlockState blockState = blockStateMeta.getBlockState();
        if (!(blockState instanceof Container container)) {
            return;
        }

        int containerIdentity = buildContainerIdentity(item);
        if (!visitedContainers.add(containerIdentity)) {
            return;
        }

        try {
            for (ItemStack content : container.getInventory().getContents()) {
                collectSellWorthEntries(content, amountMultiplier, depth, allowNestedExpansion, visitedContainers, entries);
            }
        } finally {
            visitedContainers.remove(containerIdentity);
        }
    }

    private SellCategory resolveSellCategory(DirectWorthData directWorth, ItemStack item) {
        if (directWorth != null && directWorth.categoryKey() != null && !directWorth.categoryKey().isBlank()) {
            return SellCategory.fromConfigKey(directWorth.categoryKey()).orElse(null);
        }
        return getSellCategory(item);
    }

    private int multiplyAmount(int amount, int multiplier) {
        long result = (long) amount * multiplier;
        return result > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) result;
    }

    private int buildContainerIdentity(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        return Objects.hash(item.getType(), meta == null ? null : meta.getAsString());
    }

    private boolean isSupportedContainer(ItemStack item) {
        return item != null
                && item.getItemMeta() instanceof BlockStateMeta blockStateMeta
                && blockStateMeta.getBlockState() instanceof Container;
    }

    /**
     * Whether this item is a container that still holds something the sale would not pay for.
     *
     * <p>A shulker is bought and sold as a single stack, so a sale that prices the box on its own
     * takes everything inside with it. That is what used to happen with CONTAINER.ENABLED off: the
     * box kept its own price from worth.yml, the contents were skipped, and the whole slot was
     * cleared for the price of an empty shulker. It went the same way for a container nested deeper
     * than MAX-CONTAINER-DEPTH, or for any container at all once ALLOW-NESTED-CONTAINERS closed the
     * expansion off.</p>
     *
     * <p>Treating it as unsellable is what stops that. The sell window puts back whatever it did not
     * take, so a full shulker comes home and an empty one still sells for its own price.</p>
     */
    private boolean isUnpricedFullContainer(ItemStack item, int depth, boolean allowNestedExpansion) {
        return isSupportedContainer(item)
                && !willPriceContainerContents(depth, allowNestedExpansion)
                && containerHasContents(item);
    }

    /** The same test the collectors use before they walk into a container. */
    boolean willPriceContainerContents(int depth, boolean allowNestedExpansion) {
        return isContainerWorthEnabled()
                && allowNestedExpansion
                && depth < getMaxContainerDepth();
    }

    private boolean containerHasContents(ItemStack item) {
        if (!(item.getItemMeta() instanceof BlockStateMeta blockStateMeta)
                || !(blockStateMeta.getBlockState() instanceof Container container)) {
            return false;
        }
        for (ItemStack content : container.getInventory().getContents()) {
            if (content != null && !content.getType().isAir()) {
                return true;
            }
        }
        return false;
    }

    private boolean isBlockedItem(ItemStack item) {
        return item != null && isBlockedMaterial(item.getType());
    }

    private boolean isBlockedMaterial(Material material) {
        if (material == null || material.isAir()) {
            return false;
        }

        if (!blockedMaterialsLoaded) {
            blockedMaterialsCache.clear();
            List<String> blockItems = plugin.getConfigManager().getWorth().getStringList("BLOCK-ITEMS");
            if (blockItems != null) {
                for (String rawMaterial : blockItems) {
                    if (rawMaterial == null || rawMaterial.isBlank()) {
                        continue;
                    }
                    try {
                        Material blocked = matchMaterial(rawMaterial.trim());
                        if (blocked != null) {
                            blockedMaterialsCache.add(blocked);
                        }
                    } catch (IllegalArgumentException ignored) {}
                }
            }
            blockedMaterialsLoaded = true;
        }

        return blockedMaterialsCache.contains(material);
    }

    private boolean isContainerWorthEnabled() {
        return plugin.getConfigManager().getWorth().getBoolean("CONTAINER.ENABLED", true);
    }

    private boolean shouldIncludeContainerBasePrice() {
        return plugin.getConfigManager().getWorth().getBoolean("CONTAINER.INCLUDE-CONTAINER-BASE-PRICE", true);
    }

    private boolean allowNestedContainers() {
        return plugin.getConfigManager().getWorth().getBoolean("CONTAINER.ALLOW-NESTED-CONTAINERS", false);
    }

    private int getMaxContainerDepth() {
        return Math.max(1, plugin.getConfigManager().getWorth().getInt("CONTAINER.MAX-CONTAINER-DEPTH", 1));
    }

    private DirectWorthData resolveDirectWorth(ItemStack item) {
        return applyMetaMultiplier(item == null ? null : item.getType(), resolveBaseDirectWorth(item));
    }

    // the cache holds base prices, so the meta multiplier is applied on the way out and a
    // rotation never leaves a stale price behind in it
    private DirectWorthData applyMetaMultiplier(Material material, DirectWorthData data) {
        if (data == null) {
            return null;
        }

        double multiplier = getMetaMultiplier(material);
        if (multiplier == 1.0D) {
            return data;
        }

        return new DirectWorthData(
                data.worth() * multiplier,
                data.sourceKey(),
                data.categoryKey(),
                data.resolutionType()
        );
    }

    private double getMetaMultiplier(Material material) {
        FarmingMetaManager farmingMetaManager = plugin.getFarmingMetaManager();
        return farmingMetaManager == null ? 1.0D : farmingMetaManager.getMultiplierFor(material);
    }

    private DirectWorthData resolveBaseDirectWorth(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return null;
        }
        if (isBlockedItem(item)) {
            return null;
        }

        WorthCacheKey cacheKey = WorthCacheKey.of(item);
        DirectWorthData cached = directWorthCache.get(cacheKey);
        if (cached != null) {
            return cached == NULL_DIRECT_WORTH ? null : cached;
        }

        DirectWorthData resolved = resolveDirectWorthNoCache(item);
        directWorthCache.put(cacheKey, resolved == null ? NULL_DIRECT_WORTH : resolved);
        return resolved;
    }

    private DirectWorthData resolveDirectWorthNoCache(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return null;
        }
        if (isBlockedItem(item)) {
            return null;
        }

        FileConfiguration worthConfig = plugin.getConfigManager().getWorth();
        ConfigurationSection typedValues = worthConfig.getConfigurationSection("TYPE");
        DirectWorthData resolved = null;
        if (typedValues != null) {
            for (String categoryKey : typedValues.getKeys(false)) {
                ConfigurationSection categorySection = typedValues.getConfigurationSection(categoryKey);
                DirectWorthData typedWorth = findWorthRecursively(categorySection, item, categoryKey);
                if (typedWorth != null) {
                    resolved = typedWorth;
                    break;
                }
            }
        }

        if (resolved == null) {
            resolved = findWorthRecursively(worthConfig, item, "");
        }

        return addEnchantmentWorthIfApplicable(item, resolved);
    }

    private DirectWorthData addEnchantmentWorthIfApplicable(ItemStack item, DirectWorthData baseData) {
        if (baseData == null || item == null) {
            return baseData;
        }

        if (item.getType() == Material.ENCHANTED_BOOK) {
            return baseData;
        }

        java.util.Map<Enchantment, Integer> enchantments = item.getEnchantments();
        if (enchantments.isEmpty()) {
            return baseData;
        }

        double extraWorth = 0;
        for (java.util.Map.Entry<Enchantment, Integer> entry : enchantments.entrySet()) {
            extraWorth += getEnchantmentWorth(entry.getKey(), entry.getValue());
        }

        if (extraWorth > 0) {
            return new DirectWorthData(
                    baseData.worth() + extraWorth,
                    baseData.sourceKey(),
                    baseData.categoryKey(),
                    baseData.resolutionType() + "_ENCHANTED"
            );
        }

        return baseData;
    }

    private double getEnchantmentWorth(Enchantment enchantment, int level) {
        String enchantmentKey = enchantment.getKey().getKey()
                .toUpperCase(Locale.US)
                .replace('-', '_');
        String lookupKey = "ENCHANTED_BOOK:" + enchantmentKey + ":" + level;

        Double cached = enchantmentWorthCache.get(lookupKey);
        if (cached != null) {
            return cached;
        }

        double resolved = getEnchantmentWorthNoCache(lookupKey);
        enchantmentWorthCache.put(lookupKey, resolved);
        return resolved;
    }

    private double getEnchantmentWorthNoCache(String lookupKey) {
        FileConfiguration worthConfig = plugin.getConfigManager().getWorth();
        if (worthConfig == null) {
            return 0;
        }

        double direct = worthConfig.getDouble("TYPE.BOOK." + lookupKey, -1);
        if (direct >= 0) {
            return direct;
        }

        return findEnchantmentWorthRecursively(worthConfig, lookupKey);
    }

    private double findEnchantmentWorthRecursively(ConfigurationSection section, String lookupKey) {
        if (section == null) {
            return 0;
        }
        if (section.contains(lookupKey) && !section.isConfigurationSection(lookupKey)) {
            return section.getDouble(lookupKey, 0);
        }
        for (String key : section.getKeys(false)) {
            if (section.isConfigurationSection(key)) {
                double worth = findEnchantmentWorthRecursively(section.getConfigurationSection(key), lookupKey);
                if (worth > 0) {
                    return worth;
                }
            }
        }
        return 0;
    }

    private DirectWorthData findWorthRecursively(ConfigurationSection section, ItemStack item, String categoryKey) {
        if (section == null || item == null || item.getType().isAir()) {
            return null;
        }

        DirectWorthData directWorth = getDirectWorth(section, item, categoryKey);
        if (directWorth != null) {
            return directWorth;
        }

        for (String key : section.getKeys(false)) {
            if (!section.isConfigurationSection(key)) {
                continue;
            }

            DirectWorthData nestedWorth = findWorthRecursively(
                    section.getConfigurationSection(key),
                    item,
                    categoryKey
            );
            if (nestedWorth != null) {
                return nestedWorth;
            }
        }

        return null;
    }

    private DirectWorthData getDirectWorth(ConfigurationSection section, ItemStack item, String categoryKey) {
        DirectWorthData specificWorth = resolveSpecificItemWorth(section, item, categoryKey);
        if (specificWorth != null) {
            return specificWorth;
        }

        String materialKey = item.getType().name();
        if (section.contains(materialKey) && !section.isConfigurationSection(materialKey)) {
            return new DirectWorthData(
                    section.getDouble(materialKey, -1),
                    materialKey,
                    categoryKey,
                    "DIRECT"
            );
        }
        return null;
    }

    private DirectWorthData resolveSpecificItemWorth(ConfigurationSection section, ItemStack item, String categoryKey) {
        if (item.getType() == Material.ENCHANTED_BOOK) {
            return resolveEnchantedBookWorth(section, item, categoryKey);
        }

        if (item.getItemMeta() instanceof PotionMeta meta) {
            return resolvePotionWorth(section, item.getType(), meta, categoryKey);
        }

        return null;
    }

    private DirectWorthData resolveEnchantedBookWorth(ConfigurationSection section, ItemStack item, String categoryKey) {
        if (!(item.getItemMeta() instanceof EnchantmentStorageMeta meta) || meta.getStoredEnchants().isEmpty()) {
            return null;
        }

        double total = 0;
        List<String> matchedKeys = new ArrayList<>();
        for (var enchantmentEntry : meta.getStoredEnchants().entrySet()) {
            Enchantment enchantment = enchantmentEntry.getKey();
            String enchantmentKey = enchantment.getKey().getKey()
                    .toUpperCase(Locale.US)
                    .replace('-', '_');
            String worthKey = item.getType().name() + ":" + enchantmentKey + ":" + enchantmentEntry.getValue();
            if (section.contains(worthKey) && !section.isConfigurationSection(worthKey)) {
                total += section.getDouble(worthKey, 0);
                matchedKeys.add(worthKey);
            }
        }

        if (matchedKeys.isEmpty()) {
            return null;
        }

        return new DirectWorthData(
                total,
                String.join(",", matchedKeys),
                categoryKey,
                "ENCHANTED_BOOK"
        );
    }

    private DirectWorthData resolvePotionWorth(
            ConfigurationSection section,
            Material material,
            PotionMeta meta,
            String categoryKey
    ) {
        PotionType potionType = meta.getBasePotionType();
        if (potionType == null) {
            return null;
        }

        String potionKey = buildPotionWorthKey(material, potionType);
        if (potionKey == null || !section.contains(potionKey) || section.isConfigurationSection(potionKey)) {
            return null;
        }

        return new DirectWorthData(
                section.getDouble(potionKey, -1),
                potionKey,
                categoryKey,
                "POTION"
        );
    }

    private String buildPotionWorthKey(Material material, PotionType potionType) {
        String potionName = potionType.name().toUpperCase(Locale.US);
        boolean upgraded = false;

        if (potionName.startsWith("STRONG_")) {
            potionName = potionName.substring("STRONG_".length());
            upgraded = true;
        } else if (potionName.startsWith("LONG_")) {
            potionName = potionName.substring("LONG_".length());
        }

        StringBuilder builder = new StringBuilder(material.name()).append(':').append(potionName);
        if (upgraded) {
            builder.append(":2");
        }
        return builder.toString();
    }

    private boolean isWorthDisplayEnabled(Player player) {
        if (!isWorthLoreEnabled()) {
            return false;
        }

        PlayerData data = plugin.getPlayerDataManager().get(player);
        return data != null && data.isWorthDisplayEnabled();
    }

    static double getDisplayWorth(WorthResult worthResult) {
        return worthResult.totalWorth();
    }

    public boolean mergePlayerStorageStacks(Player player) {
        ItemStack[] storage = player.getInventory().getStorageContents();
        boolean changed = false;

        for (int i = 0; i < storage.length; i++) {
            ItemStack base = storage[i];
            if (base == null || base.getType().isAir()) {
                continue;
            }

            int maxStackSize = base.getMaxStackSize();
            if (base.getAmount() >= maxStackSize) {
                continue;
            }

            ItemStack strippedBase = stripWorthDisplay(base);

            for (int j = i + 1; j < storage.length; j++) {
                ItemStack candidate = storage[j];
                if (candidate == null || candidate.getType().isAir()) {
                    continue;
                }

                ItemStack strippedCandidate = stripWorthDisplay(candidate);

                if (!strippedBase.isSimilar(strippedCandidate)) {
                    continue;
                }

                int transferable = Math.min(maxStackSize - strippedBase.getAmount(), strippedCandidate.getAmount());
                if (transferable <= 0) {
                    continue;
                }

                strippedBase.setAmount(strippedBase.getAmount() + transferable);
                strippedCandidate.setAmount(strippedCandidate.getAmount() - transferable);

                boolean enabled = isWorthDisplayEnabled(player);
                ItemStack newBase = updateWorthDisplay(strippedBase, enabled);
                ItemStack newCandidate = strippedCandidate.getAmount() <= 0 ? null : updateWorthDisplay(strippedCandidate, enabled);

                storage[i] = newBase;
                storage[j] = newCandidate;
                player.getInventory().setItem(i, newBase);
                player.getInventory().setItem(j, newCandidate);
                changed = true;

                base = newBase;
                strippedBase = stripWorthDisplay(base);
                if (strippedBase.getAmount() >= maxStackSize) {
                    break;
                }
            }
        }
        return changed;
    }

    private ItemStack updateWorthDisplay(ItemStack item, boolean enabled) {
        // the packet display renders worth client side, writing it into the real item breaks vanilla stacking
        if (packetDisplayActive) {
            return stripWorthDisplay(item);
        }

        if (item == null || item.getType().isAir()) {
            return item;
        }

        if (isWorthDisplayExcluded(item)) {
            return item;
        }

        String loreLine = enabled ? getWorthLoreLine(item) : null;
        if (loreLine == null || loreLine.isBlank()) {
            return stripWorthDisplay(item);
        }

        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        List<String> currentLore = meta.getLore();
        List<String> originalLore = readOriginalLore(meta);
        if (originalLore == null) {
            originalLore = currentLore;
        }
        originalLore = stripExistingWorthLore(originalLore);

        List<String> desiredLore = originalLore == null ? new ArrayList<>() : new ArrayList<>(originalLore);
        desiredLore.add(ColorUtils.toComponent(loreLine));

        PersistentDataContainer container = meta.getPersistentDataContainer();
        String serializedOriginalLore = serializeLore(originalLore);
        String storedOriginalLore = container == null ? null : container.get(worthDisplayOriginalLoreKey, PersistentDataType.STRING);
        boolean alreadyApplied = container != null && container.has(worthDisplayAppliedKey, PersistentDataType.BYTE);
        if (alreadyApplied
                && Objects.equals(storedOriginalLore, serializedOriginalLore)
                && Objects.equals(currentLore, desiredLore)) {
            return item;
        }

        ItemStack updated = item.clone();
        ItemMeta updatedMeta = updated.getItemMeta();
        if (updatedMeta == null) {
            return item;
        }

        PersistentDataContainer updatedContainer = updatedMeta.getPersistentDataContainer();
        if (updatedContainer != null) {
            updatedContainer.set(worthDisplayAppliedKey, PersistentDataType.BYTE, (byte) 1);
            updatedContainer.set(worthDisplayOriginalLoreKey, PersistentDataType.STRING, serializedOriginalLore);
        }
        updatedMeta.setLore(desiredLore);
        updated.setItemMeta(updatedMeta);
        return updated;
    }

    private boolean isWorthDisplayExcluded(ItemStack item) {
        return item != null && plugin.getAmethystToolsManager().isAmethystTool(item);
    }

    private List<String> readOriginalLore(ItemMeta meta) {
        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (container == null) {
            return meta.getLore();
        }
        String stored = container.get(worthDisplayOriginalLoreKey, PersistentDataType.STRING);
        if (stored != null) {
            return deserializeLore(stored);
        }

        if (!container.has(worthDisplayAppliedKey, PersistentDataType.BYTE)) {
            return meta.getLore();
        }

        List<String> currentLore = meta.getLore();
        if (currentLore == null || currentLore.isEmpty()) {
            return null;
        }

        return new ArrayList<>(currentLore.subList(0, currentLore.size() - 1));
    }

    private String serializeLore(List<String> lore) {
        if (lore == null) {
            return NULL_LORE;
        }
        if (lore.isEmpty()) {
            return "";
        }

        List<String> encoded = new ArrayList<>();
        for (String line : lore) {
            encoded.add(Base64.getEncoder().encodeToString((line == null ? "" : line).getBytes(StandardCharsets.UTF_8)));
        }
        return String.join(LORE_SEPARATOR, encoded);
    }

    private List<String> deserializeLore(String serialized) {
        if (serialized == null) {
            return null;
        }
        if (NULL_LORE.equals(serialized)) {
            return null;
        }
        if (serialized.isEmpty()) {
            return new ArrayList<>();
        }

        List<String> lore = new ArrayList<>();
        for (String token : serialized.split(LORE_SEPARATOR, -1)) {
            lore.add(new String(Base64.getDecoder().decode(token), StandardCharsets.UTF_8));
        }
        return lore;
    }

    private List<String> stripExistingWorthLore(List<String> lore) {
        if (lore == null || lore.isEmpty()) {
            return lore;
        }

        Pattern worthLorePattern = buildWorthLorePattern();
        List<String> sanitized = new ArrayList<>();
        boolean changed = false;
        for (String line : lore) {
            if (isWorthLoreLine(line, worthLorePattern)) {
                changed = true;
                continue;
            }
            sanitized.add(line);
        }
        return changed ? sanitized : lore;
    }

    private boolean isWorthLoreLine(String line, Pattern worthLorePattern) {
        String plain = ColorUtils.strip(line);
        if (containsBrokenWorthPlaceholder(plain)) {
            return true;
        }

        return worthLorePattern.matcher(plain).matches();
    }

    private boolean containsBrokenWorthPlaceholder(String plain) {
        return plain.contains("${price}")
                || plain.contains("%price%")
                || plain.contains("{price}")
                || plain.contains("${unit_price}")
                || plain.contains("%unit_price%")
                || plain.contains("{unit_price}");
    }

    private String replaceWorthPlaceholders(
            String format,
            String totalPrice,
            String unitPrice,
            String amount,
            String itemName,
            String totalPriceFormatted,
            String unitPriceFormatted
    ) {
        String resolved = replacePlaceholderVariants(format, "price", totalPrice);
        resolved = replacePlaceholderVariants(resolved, "price_formatted", totalPriceFormatted);
        resolved = replacePlaceholderVariants(resolved, "unit_price", unitPrice);
        resolved = replacePlaceholderVariants(resolved, "unit_price_formatted", unitPriceFormatted);
        resolved = replacePlaceholderVariants(resolved, "amount", amount);
        return replacePlaceholderVariants(resolved, "item", itemName);
    }

    private String replacePlaceholderVariants(String text, String key, String value) {
        return text
                .replace("%" + key + "%", value)
                .replace("${" + key + "}", value)
                .replace("{" + key + "}", value);
    }

    private String getWorthLoreFormat() {
        FileConfiguration worthConfig = plugin.getConfigManager().getWorth();
        String format = firstNonBlank(
                worthConfig.getString("WORTH-LORE.FORMAT"),
                worthConfig.getString("DISPLAY.FORMAT"),
                worthConfig.getString("FORMAT")
        );
        if (format != null) {
            return normalizeWorthLoreFormat(format);
        }

        return normalizeWorthLoreFormat(
                plugin.getConfigManager().getConfig()
                        .getString("WORTH-LORE.FORMAT", "&7worth: &a{price_formatted}")
        );
    }

    private String firstNonBlank(String... candidates) {
        for (String candidate : candidates) {
            if (candidate != null && !candidate.isBlank()) {
                return candidate;
            }
        }
        return null;
    }

    private String normalizeWorthLoreFormat(String format) {
        if (format == null || format.isBlank()) {
            return "&7worth: &a{price_formatted}";
        }

        return format;
    }

    private Pattern buildWorthLorePattern() {
        String format = stripColorCodes(getWorthLoreFormat());
        List<String> placeholders = List.of(
                "%unit_price%", "${unit_price}", "{unit_price}",
                "%unit_price_formatted%", "${unit_price_formatted}", "{unit_price_formatted}",
                "%price%", "${price}", "{price}",
                "%price_formatted%", "${price_formatted}", "{price_formatted}",
                "%amount%", "${amount}", "{amount}",
                "%item%", "${item}", "{item}"
        );

        StringBuilder regex = new StringBuilder("^");
        int index = 0;
        while (index < format.length()) {
            int nextPlaceholderIndex = -1;
            String nextPlaceholder = null;
            for (String placeholder : placeholders) {
                int candidateIndex = format.indexOf(placeholder, index);
                if (candidateIndex < 0) {
                    continue;
                }
                if (nextPlaceholderIndex < 0 || candidateIndex < nextPlaceholderIndex) {
                    nextPlaceholderIndex = candidateIndex;
                    nextPlaceholder = placeholder;
                }
            }

            if (nextPlaceholderIndex < 0) {
                regex.append(Pattern.quote(format.substring(index)));
                break;
            }

            String staticPart = format.substring(index, nextPlaceholderIndex);
            if (isPricePlaceholder(nextPlaceholder) && staticPart.endsWith("$")) {
                staticPart = staticPart.substring(0, staticPart.length() - 1);
                regex.append(Pattern.quote(staticPart));
                regex.append("\\$?");
            } else {
                regex.append(Pattern.quote(staticPart));
            }

            regex.append(".+?");
            index = nextPlaceholderIndex + nextPlaceholder.length();
        }

        regex.append("$");
        try {
            return Pattern.compile(regex.toString());
        } catch (PatternSyntaxException exception) {
            return Pattern.compile("^$");
        }
    }

    private String stripColorCodes(String text) {
        return text
                .replaceAll("(?i)&#[0-9a-f]{6}", "")
                .replaceAll("(?i)&[0-9a-fk-or]", "");
    }

    private boolean isPricePlaceholder(String placeholder) {
        return placeholder.contains("price");
    }

    public Material matchMaterial(String key) {
        if (key == null || key.isBlank()) {
            return null;
        }
        Material material = Material.matchMaterial(key);
        if (material != null) {
            return material;
        }
        return Registry.MATERIAL.get(NamespacedKey.minecraft(key.toLowerCase(Locale.US)));
    }

    public Material findMaterial(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }

        String clean = input.trim();
        Material direct = matchMaterial(clean);
        if (direct != null) {
            return direct;
        }

        Material withUnderscores = matchMaterial(clean.replace(" ", "_"));
        if (withUnderscores != null) {
            return withUnderscores;
        }

        Material withSpaces = matchMaterial(clean.replace("_", " "));
        if (withSpaces != null) {
            return withSpaces;
        }

        String normalizedClean = clean.replaceAll("[ _-]", "").toLowerCase(Locale.US);

        for (WorthBrowserEntry entry : getBrowserEntries()) {
            Material mat = entry.material();
            if (mat == null) continue;
            if (mat.name().replaceAll("[ _-]", "").toLowerCase(Locale.US).equals(normalizedClean)) {
                return mat;
            }
            if (prettifyMaterial(mat).replaceAll("[ _-]", "").toLowerCase(Locale.US).equals(normalizedClean)) {
                return mat;
            }
        }

        for (Material mat : Material.values()) {
            if (mat.isAir()) continue;
            if (mat.name().replaceAll("[ _-]", "").toLowerCase(Locale.US).equals(normalizedClean)) {
                return mat;
            }
        }

        return null;
    }
}
