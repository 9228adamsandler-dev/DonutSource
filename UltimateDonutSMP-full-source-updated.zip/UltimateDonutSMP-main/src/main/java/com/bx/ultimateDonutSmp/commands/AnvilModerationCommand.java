package com.bx.ultimateDonutSmp.commands;

import com.bx.ultimateDonutSmp.UltimateDonutSmp;
import com.bx.ultimateDonutSmp.utils.ColorUtils;
import com.bx.ultimateDonutSmp.utils.PermissionUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class AnvilModerationCommand implements CommandExecutor, TabCompleter {

    private final UltimateDonutSmp plugin;

    public AnvilModerationCommand(UltimateDonutSmp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!PermissionUtils.has(sender, "anvilmod.admin")) {
            sender.sendMessage(ColorUtils.toComponent(
                    plugin.getLanguageManager().text("MESSAGES.ANVILMOD.NO-PERMISSION", "&cYou do not have permission.")
            ));
            return true;
        }

        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("add")) {
            if (args.length < 2) {
                sendUsage(sender);
                return true;
            }

            String word = args[1];
            boolean success = plugin.getAnvilModerationManager().addBannedWord(word);
            if (success) {
                sender.sendMessage(ColorUtils.toComponent(
                        plugin.getLanguageManager().text("MESSAGES.ANVILMOD.ADDED", "&aSuccessfully added '&e{word}&a' to banned words.", "{word}", word)
                ));
            } else {
                sender.sendMessage(ColorUtils.toComponent(
                        plugin.getLanguageManager().text("MESSAGES.ANVILMOD.ALREADY-EXISTS", "&cThat word is already in the banned list.")
                ));
            }
            return true;
        } else if (sub.equals("reload")) {
            plugin.getAnvilModerationManager().load();
            sender.sendMessage(ColorUtils.toComponent(
                    plugin.getLanguageManager().text("MESSAGES.ANVILMOD.RELOADED", "&aAnvil moderation config reloaded.")
            ));
            return true;
        }

        sendUsage(sender);
        return true;
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ColorUtils.toComponent(
                plugin.getLanguageManager().text("MESSAGES.ANVILMOD.USAGE", "&cUsage: /amod <add|reload> [word]")
        ));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (!PermissionUtils.has(sender, "anvilmod.admin")) {
            return Collections.emptyList();
        }

        if (args.length == 1) {
            List<String> suggestions = new ArrayList<>();
            String input = args[0].toLowerCase(Locale.ROOT);
            if ("add".startsWith(input)) suggestions.add("add");
            if ("reload".startsWith(input)) suggestions.add("reload");
            return suggestions;
        }

        return Collections.emptyList();
    }
}
